# RPA Cloud Design

#### rpa_workspace_terraform :-
This document describes the architecture for an implementation of Robotic Process Automation (RPA) on Amazon Web Services (AWS) in Terraform.
Contain ``Terraform`` Files such as :-

- orchestrator.tf
- elk.tf
- rds.tf
- sg.tf
- variable.tf
- vpc_rpa.tf
- config.tf

## orchestrator :-

In this file we have created an orchestrator which will work as a server for UI PATH, we have used ec2-instance module.

##### Example Usage :-
```
module "Orchestrator-instance" {
   source               = "../modules/terraform-ec2-instance/"
   vpc_id               = "${module.rpavpc.vpc_id}"
   #subnet_id            = "${element(module.rpavpc.application_subnet_ids, 0)}"
   subnet_id            = "${element(module.rpavpc.private_subnet_ids, 0)}"
   subnet_type          = "private"
   number_of_instances  = 1
   appname              = "${var.rpa-appname}"
   ZONE                 = "${var.ZONE}"
   owner                = "abcd@sogeti.nl"
   key_name             = "${var.rpa_key}"
   customer             = "${var.customer}"
   OTAP                 = "${var.OTAP}"
   #ami                 = "${var.ami}"
   role                 = "testrole"
   amid                 = "${var.uipath-ami}"
   ami_type             = "custom"
   instance_type        = "${var.instance_type}"
   application          = "${var.application}"
   security_group_ids   = "${module.rpasecuritygroup_orch.sg_id}"
   envr                 = "${var.envr}"
   #sdcheck             = "false"
   root_block_device    = "${var.rootdevice}"
}
```

## elk :-

In this file we have used an elastic search which will communicate with kibana and provide the log-report of application UIPATH.

##### Example Usage :-
```
module "elk" {
  source = "../modules/terraform-elk/"
  domain = "${var.domain}"
  elk_sg  = "${module.rpasecuritygroup_elk.sg_id}"
  kms_key_name = "${var.kms-elk}"
  subnet_ids = "${element(module.rpavpc.subnet_ids, 0)}"

## RDS :-

RDS database used for storing application data. For this, we are using`RDS MSSQL` engine.

##### Example Usage:-
```
module "rds" {

  source = "../modules/terraform-rds-sqlserver/"
  vpc_sgroup = "${module.rpasecuritygroup_rds.sg_id}"
  subnet_ids = "postnl-rdssubnet-rpa-${var.rpaenv}"
  rds_instance_identifier = "postnl-rds-mssql-inst01-rpa-${var.rpaenv}"
  rds_engine_type         = "${var.rds_engine_type}"
  rds_engine_version      = "${var.rds_engine_version}"
  rds_instance_class      = "${var.rds_instance_class}"
  license_model           = "license-included"
  rds_allocated_storage   = "${var.rds_allocated_storage}"
  #database_name           = "postnl_rds_mysql_db_rpa_t"
  database_user           = "${var.dbuser}"
  database_password       = "${var.dbpass}"
  database_port           = "${var.dbport}"
  backup_window           = "${var.dbbackupwindow}"
  backup_retention_period = "${var.dbreten}"
  kms_key_name             = "${var.kmsname}"
  parameter_group_name    = "postnl-rdsparams-rpa-${var.rpaenv}"
  db_parameter_group      = "sqlserver-se-13.0"
  maintenance_window      = "${var.maintenance_window}"
}
 
 
***Below files will support the above configuration to make it work successfully.

## sg - Security Group, to restrict and allow ports and IP's.
## vpc - It's used to isolate the network.
## variables - Are used as a reference.  
