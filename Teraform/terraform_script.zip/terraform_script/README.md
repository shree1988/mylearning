FOLDER STRUCTURE:

ss_account_terraform:
Contains Terraform files which creates VPC (incl Subnets, Security Groups, IGW, NAT etc), Bastion host, ADDS, WAP under Shared Services Account for Testing and Production AWS account

workspace_account_terraform:
Contains Terraform files which creates W01, W02, W03 VPC (incl Subnets, Security Groups, IGW, NAT etc) under Workspace Account for Testing, Acceptance and Production AWS account

modules:
Contains modules which are to be used for creating any AWS services instead of directly calling terraform resource function. Their can be specific cases (e.g: When adding Security Group Rules) when we can directly call terraform resource function, but for most of services its preferred to use modules when creating/using new AWS services under any accounts. If module is not present for any AWS service, contact AWS Landing Zone team to create a module which can be call'd from Workspace / Application terraform template.

Modules present for : VPC, EC2, S3, RDS, IAM, ELB, ASG, Lambda, Cloudfront, API Gateway

global_peering_terraform:
Contains terraform templates to create VPC peering between Shared Services VPC to Workspace VPC. There is a reason for keeping this seperate to avoid accidental change to Peering connections

cpp_workspace_terraform:
Contains Terraform template for CPP application infra deployment




GENERAL SETUP:
All folders will have 'provision.sh' executable which is to be call'd from VSTS Relase pipeline.
(provision.sh basically calls terraform command with required inputs to handle multiple AWS environments which was not possible using VSTS Terraform plugin)

e.g: To deploy under Testing environment of CPP, go to "cpp_workspace_terraform" folder and run below -

```
provision.sh plan test
provision.sh apply test
```

Format : provision.sh $action $environment
provision.sh takes parameters present inside "/config/" folder for "test, acc, prod" environment files to deploy into multiple AWS accounts.
