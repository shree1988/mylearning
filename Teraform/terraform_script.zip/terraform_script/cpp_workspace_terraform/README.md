# CPP Cloud Design

#### cpp_workspace_terraform :- 
This document describes the architecture for an implementation of CheckPoint Partijenpost (CPP) on Amazon Web Services (AWS) in Terraform.
Contain ``Terraform`` Files such as :-

- api.tf
- cloudfront.tf
- iam.tf
- lambda.tf
- rds.tf
- s3.tf
- sg.tf
-  cwatch.tf
- variables.tf

## api :-
In this Five ``API`` are created using modules and associated with individual ``LAMBDA`` function.
##### Example Usage :-
```
module "cppalgorithm" {
source = "../modules/terraform-api"
account_id = "${var.aws_account_id}"
apiname = "postnl-api-cppalgorithm-${var.cppenv}"
description = "API that exposes the CPP Algorithm functionality"
lambdaarn = "${module.postnl-lmb-cppalgorithm-a.arn}"
}
```
## cloudfront :-
``Cloudfront`` is getting created and attaching to ``S3`` bucket 
``WAF`` getting created infront of Cloudfront
Module returns three outputs:- `cf-domain_name` , `s3_canonical_user_id` , and `cfrontoai`
##### Example usage
```
module "cloudfront" {
  source      = "../modules/terraform-cloudfront"
  bucket_name = "${var.cfbucket}"
  OTAP        = "${var.OTAP}"
  application = "${var.application}"
  cloudfrontaliases  = "${var.cfaliases}"
  wafip       = "${var.wafip}"
  cppenv      = "${var.cppenv}"
}

```

## IAM:-
Creating three`iam` role with specific extra policy attached.
##### Example usage
```
module "pnl-lambdacppkeepalive-role" {
  source    = "../modules/terraform-iam-instance-profile"
  role_name = "CPP-LAMBDA-KEEPALIVE"
  description = "Specify the policy that allow access to the other CPP Lambdas for execution"
  assume_role_policy = "${file("${path.module}/policies/assume-role-policy.json")}"
  role_policy              = "${file("${path.module}/policies/cpplambdakeepalive.json")}"
  number_of_extra_policies = 0
  extra_policies = []
} 
```
## Lambda :-
Creating Seven `Lambda` Function within subnet and attaching to RDS endpoint 

##### Example Usage:-
```
module "postnl-lmb-cppproduct-a" {
source = "../modules/terraform-lambda/"
functionname = "postnl-lmb-cppproduct-${var.cppenv}"
account_id = "${var.aws_account_id}"
subnet_id1 = "${var.bk_subnet_id1}"
subnet_id2 = "${var.bk_subnet_id2}"
security_group_ids = "${module.securitygroup.sg_id}"
rds_endpoint       = "${module.rds.rdsendpoint}"
lambda_role        = "${module.pnl-lambdacppgeneric-role.arn}"
OTAP        = "${var.OTAP}"
application = "${var.application}"
Name        = "postnl-lmb-cppproduct-${var.cppenv}"
}
```
## RDS :-
RDS database used for storing application data. For now, we use `RDS MySQL` engine.
##### Example Usage:-
```
module "rds" {
  source = "../modules/terraform-rds/"
  vpc_sgroup = "${module.rdssecuritygroup.sg_id}"
  rds_instance_identifier = "postnl-rds-mysql-inst01-cpp-${var.cppenv}"
  rds_engine_type         = "${var.rds_engine_type}"
  rds_engine_version      = "${var.rds_engine_version}"
  rds_instance_class      = "${var.rds_instance_class}"
  rds_allocated_storage   = "${var.rds_allocated_storage}"
  database_name           = "postnl_rds_mysql_inst01_cpp_${var.cppenv}"
  database_user           = "${var.dbuser}"
  database_password       = "${var.dbpass}"
  database_port           = "${var.dbport}"
  backup_window           = "${var.dbbackupwindow}"
  backup_retention_period = "${var.dbreten}"
  OTAP                    = "${var.OTAP}"
  application             = "${var.application}"
  Name                    = "postnl-rds-mysql-inst01-cpp-${var.cppenv}"
  ssm_param               = "postnl-param-cpp-dbpwd-${var.cppenv}"
  parameter_group_name     = "postnl-rdsparams-cpp-${var.cppenv}"
  kms_key_name             = "${var.kmsname}"
}
```
## S3
Two `s3` bucket is created using modules.
One is used to stored the data and other is used for cloudfront.
##### Example Usage:-
```
module "cpp_a02_cldsvc_net" {
  source      = "../modules/terraform-s3"
  identifiers = "${module.cloudfront.cfrontoai}"
  bucket_name = "${var.cfbucket}"
  OTAP        = "${var.OTAP}"
  application = "${var.application}"
  Name        = "${var.cfbucket}"
}
```
## CLOUDWATCH :-
Cloudwatch is used to trigger `Lambda` functions at specific schedule.

###### ExampleUsage
```
module "cloudwatch" {
  source = "../modules/terraform-cloudwatch/"
customer = "${var.customer}"
envr     = "${var.envr}"
ZONE     = "${var.ZONE}"
cronexp  = "cron(0/5 7-19 ? * MON-FRI *)"
watchfor = "keepalivelambda"
}
```



