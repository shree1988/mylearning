#!groovy

//env.Branch_Name = params.Branch_Name
//env.Apigee_Env_Name = params.Apigee_Env_Name
//env.Org_Type = params.Org_Type
node {

  deleteDir()

  // ANSI color codes
  green='\u001B[32m'
  red='\u001B[31m'
  bold='\u001B[1m'
  reset='\u001B[0m'

  properties([ parameters([
    string(name: 'Branch_Name', defaultValue:env.Branch_Name, description: 'Branch Name e.g: stream16'),
    choice(name: 'Apigee_Env_Name', choices: "stream1-dev\nstream1-qa\nstream1-uat\nstream4-qa\nstream4-uat\nstream13-dev\nstream13-qa\nstream13-uat\nstream16-qa\nstream16-uat\n", description: 'Select the Apigee environment name'),
    choice(name: 'Org_Type', choices: "helios-renault-nonprod\ndigitaslbi-temp-cps\n", description: 'Select the Apigee organization' )])
  ])

  stage('Checkout') {
  checkout changelog: false, poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/${Branch_Name}']],
  doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'CloneOption', depth: 1, noTags: true, reference: '', shallow: true, timeout: 30]],
  submoduleCfg: [], userRemoteConfigs: [[credentialsId: '', url: '']]]
  }

  stage('Zipping the config folders') {
        sh '''
          set +x
          cd helios-parent/helios-apigee/deployment/src/main/apiproxy/${Org_Type}/
          echo "Zipping the config folder for the environment ${Apigee_Env_Name} and the branch name is ${Branch_Name}"
          zip -r ${WORKSPACE}/${Apigee_Env_Name}.zip ${Apigee_Env_Name}
        '''
   }
   stage('Upload to S3') {
      wrap([$class: 'AnsiColorBuildWrapper']) {
      withCredentials([[$class: 'AmazonWebServicesCredentialsBinding', accessKeyVariable: 'AWS_ACCESS_KEY_ID',
      credentialsId: "", secretKeyVariable: 'AWS_SECRET_ACCESS_KEY']]) {
        withAWS(region:'us-east-1') {
          def createS3 = s3Upload(file:"${WORKSPACE}/${Apigee_Env_Name}.zip", bucket:'s3-renault-uat-nonprod-isconfig',
          path:"${env.Apigee_Env_Name}.zip")
        }
      }
    }
  }

  step([$class: 'WsCleanup'])
  deleteDir()
}
