#!groovy

env.Version_ID = params.Version_ID
env.Chef_ENV = params.Chef_ENV
env.App_Name = params.App_Name

properties([
  parameters([
    string(name: 'Version_ID', defaultValue: env.Version_ID, description: 'Please specify the cookbook version'),
    choice(name: 'Chef_ENV', choices: env.Chef_ENV, description: 'Which environment should be deploy. It should be our chef environment e.g: use1dev1-bae'),
    choice(name: 'App_Name', choices: env.App_Name, description: 'Please select the cookbook')
  ])
])


node {

  def prod_users = [
      'omiladi','abhatt'
  ]

  deleteDir()

  wrap([$class: 'BuildUser']) {
    def user_id = env.BUILD_USER_ID
    build_user = env.BUILD_USER
    build_user_email = env.BUILD_USER_EMAIL
    if ( !(user_id in prod_users) && env.Chef_ENV =~ /prod/){
      wrap([$class: 'AnsiColorBuildWrapper']) {
        println "${red}You are not authorized to run this job!${reset}"
        error()
      }
    }
  }

  stage('Checkout') {
    // Checkout configuration repository
    checkout changelog: false, poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']],
    doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'WipeWorkspace']], submoduleCfg: [],
    userRemoteConfigs: [[credentialsId: '97c54a1a-01f7-44f1-88b8-b88740cd3d1a', url: 'https://gitlab.helios-aws.com/helios/ops/configuration.git']]]
  }

  stage('Install Bundles and Update Databag') {
    withEnv(["PATH=/var/lib/jenkins/.rbenv/shims:/var/lib/jenkins/.rbenv/bin:/var/lib/jenkins/.rbenv/plugins/ruby_build/bin:/usr/local/bin:/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/sbin"]) {
      sh '''
        set +x
        cd chef-server
        BUNDLE_GEMFILE=Gemfile_for_knife_pipeline bundle install --path /var/lib/jenkins/pipelines-bundle-path
        rbenv rehash
      '''
    }
  }

  stage('Update version') {
    withEnv(["PATH=/var/lib/jenkins/.rbenv/shims:/var/lib/jenkins/.rbenv/bin:/var/lib/jenkins/.rbenv/plugins/ruby_build/bin:/usr/local/bin:/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/sbin"]) {
      dir('chef') {
        // running converge (dispatcher_cache_clearing) on node through pushy job
        sh '''
          set +x
          BUNDLE_GEMFILE=../chef-server/Gemfile_for_knife_pipeline bundle exec knife environment show ${Chef_ENV} -F json  > environments/${Chef_ENV}.json
          exitcode=$?
          if [ "$exitcode" -ne "0" ] ; then
            exit 1
          fi
          jq --arg v "$Version_ID" --arg name "$App_Name" '.cookbook_versions."\\($name)"="= \\($v)"' environments/${Chef_ENV}.json > /tmp/${Chef_ENV}-${BUILD_NUMBER}.json
          BUNDLE_GEMFILE=../chef-server/Gemfile_for_knife_pipeline bundle exec knife environment from file /tmp/${Chef_ENV}-${BUILD_NUMBER}.json
          rm -rf /tmp/${Chef_ENV}-${BUILD_NUMBER}.json
        '''
      }


      withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: '97c54a1a-01f7-44f1-88b8-b88740cd3d1a',
      usernameVariable: 'GIT_USERNAME', passwordVariable: 'GIT_PASSWORD']]) {
        sh '''
          set +x
          git checkout master
          cd chef
          echo 'Git status is :'
          git status --porcelain
          if [[ `git status --porcelain` ]]; then
            echo 'Pushing environment changes to master'
            git remote add central https://${GIT_USERNAME}:${GIT_PASSWORD}@gitlab.helios-aws.com/helios/ops/configuration.git
            git config --global user.name "Helios Pipeline"
            git config --global user.email dev.ops@heliosalliance.net
            git add environments/${Chef_ENV}.json
            git commit -m "Version bump to ${App_Name}:${Version_ID} ${Chef_ENV}"
            git pull
            git push origin master
          fi
        '''
      }


    }
  }

}
