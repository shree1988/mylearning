//
// Check the health of all the nodes in a LB pool
// if one or more nodes is not 'active' the job will fail
//

properties([
  parameters([
    choice( name: 'load_balancer', choices: 'ih01.apt.heliosrenault.net\nih01.eu.heliosrenault.net\nih01.np.eu.heliosrenault.net\nih01.np.heliosalliance.net\nih01.np.load.heliosrenault.net\nih01.np.use.heliosrenault.net\nih01.use.heliosrenault.net', description: 'Which LB ?'),
    string( name: 'pool', defaultValue: 'sbox-auth', description: 'Which new pool name?')
  ])
])

node{

  //******** Configuration ********
  // ANSI color codes
  green='\u001B[32m'
  red='\u001B[31m'
  bold='\u001B[1m'
  reset='\u001B[0m'

  brocade_url_suffix=':9070/api/tm/3.9/'
  brocade_url_suffix_pools=brocade_url_suffix+'config/active/pools/'
  brocade_url_suffix_nodestate=brocade_url_suffix+'status/local_tm/statistics/nodes/per_pool_node/'
  withCredentials([usernameColonPassword(credentialsId: '', variable: 'Brocade_Secrets')]) {
    brocade_credentials = Brocade_Secrets
  }


  // Get names from : http://pipeline.clcm.heliosalliance.net/asynchPeople/
  prod_users = [
      // CAP -- add the list of names for the LB pool state
  ]

  if ( env.BUILD_NUMBER == '1' ) {
    description = "Job initialisation"
    echo description
    currentBuild.description = description
    currentBuild.result = 'SUCCESS'
    return
  }

  stage('Processing parameters'){
    wrap([$class: 'AnsiColorBuildWrapper']){
      currentBuild.description = "${env.load_balancer} ⇨ ${env.pool}"
      build_userid = get_build_user().getUserId()

      // Only allowing specific users to run the job
      wrap([$class: 'BuildUser']) {
        def user_id = env.BUILD_USER_ID
        if ( ! (user_id in prod_users) ){
          echo "${bold}${red}User ${build_userid} not allowed to run this job${reset}"
          error('')
        }
      }
    }
  }

  stage ('Test connectivity'){
    wrap([$class: 'AnsiColorBuildWrapper']){
      test_connectivity = sh (
        script:  '#!/bin/sh +x\n' + "curl --max-time 10 -k -u ${brocade_credentials} https://${env.load_balancer}${brocade_url_suffix} 2>&1 || true",
        returnStdout: true
      ).trim()

      if ( test_connectivity.contains('children') ) {
        echo "Connectivity to ${env.load_balancer} : OK"
      } else {
        if ( test_connectivity.contains('Failed connect') || test_connectivity.contains('Connection timed out')  ) {
          echo "${bold}${red}Timeout while trying to connect to ${env.load_balancer}${reset}"
          error('')
        } else if  ( test_connectivity.contains('User name or password was invalid') ) {
          echo "${bold}${red}Brocade user has to be created on ${env.load_balancer}${reset}"
          error('')
        } else {
          echo "${bold}${red}Unknown error on ${env.load_balancer} : ${test_connectivity}${reset}"
          error('')
        }
      }
    }
  }

  stage ('Check list of pools'){
    wrap([$class: 'AnsiColorBuildWrapper']){

      poolslist_curl = sh (
        script:  '#!/bin/sh +x\n' + "curl -s --fail -k -u ${brocade_credentials} https://${env.load_balancer}${brocade_url_suffix_pools}",
        returnStdout: true
      ).trim()

      poolslist_json = readJSON text: poolslist_curl

      if ( ! poolslist_json['children'].collect { pool == it['name'] }.contains(true) ) {
        echo "${bold}${red}Pool ${env.pool} not found on ${env.load_balancer}${reset}"
        error('')
      }
    }
  }

  stage ('Check pool state'){
    wrap([$class: 'AnsiColorBuildWrapper']){

      pool_curl = sh (
        script:  '#!/bin/sh +x\n' + "curl -s --fail -k -u ${brocade_credentials} https://${env.load_balancer}${brocade_url_suffix_pools}${env.pool}",
        returnStdout: true
      ).trim()

      pool_json = readJSON text: pool_curl

      if ( pool_json['properties']['basic']['nodes_table'].size() < 1 ) {
        echo "${bold}${red}Node Pool ${env.pool} doesn't have any nodes"
        error('')
      }

      pool_json['properties']['basic']['nodes_table'].each{

        echo "${bold}${it['node']} 'node state' : ${it['state']}${reset}"

        if ( it['state'] != 'active' ) {
          echo "${bold}${red}Node Pool ${env.pool} got the node ${it['node']} in 'node state' ${it['state']} while we expect it to be 'active'"
          error('')
        }

        // the health state of each node in a pool isn't in the pool json itself but under statistics/nodes/per_pool_node
        nodestate_curl = sh (
          script:  '#!/bin/sh +x\n' + "curl -s --fail -k -u ${brocade_credentials} https://${env.load_balancer}${brocade_url_suffix_nodestate}${env.pool}-${it['node']}",
          returnStdout: true
        ).trim()
        nodestate_json = readJSON text: nodestate_curl

        echo "${bold}${it['node']} 'health state' : ${nodestate_json['statistics']['state']}"

        if ( nodestate_json['statistics']['state'] != 'alive' ) {
          echo "${bold}{red}Node Pool ${env.pool} got the node ${it['node']} in 'health state' ${nodestate_json['statistics']['state']} while we expect it to be 'alive'"
          error('')
        }

      }

      echo "${green}${bold}Pool ${env.pool}'s nodes are all active & alive on ${env.load_balancer}${reset}"

    }
  }
}
