#!groovy

env.Version_ID = params.Version_ID
env.Build_ID = params.Build_ID
env.Client = params.Client
env.BillingJIRA = BillingJIRA
env.Sub_Deployment = params.Sub_Deployment
env.BaseEnv_ID = params.BaseEnv_ID

node {
  // Wipe the workspace so we are building completely clean
  deleteDir()

  // ANSI color codes
  green='\u001B[32m'
  red='\u001B[31m'
  bold='\u001B[1m'
  reset='\u001B[0m'

  // List of users
  def prod_users = [
    'omiladi','abhatt'
  ]

  if (env.BaseEnv_ID == "prod") {
    BillingWorkstreamName = "Production"
  } else if (env.BaseEnv_ID == "stg") {
    BillingWorkstreamName = "Staging"
  } else if (env.BaseEnv_ID == "uat") {
    BillingWorkstreamName = "Integration"
  } else {
    println "${red}prod/uat/stg autho value for BaseEnv_ID${reset}"
    error()
  }

  wrap([$class: 'BuildUser']) {
    def user_id = env.BUILD_USER_ID
    build_user = env.BUILD_USER
    build_user_email = env.BUILD_USER_EMAIL
    if ( !(user_id in prod_users)  && env.BaseEnv_ID == "prod"){
      wrap([$class: 'AnsiColorBuildWrapper']) {
        println "${red}You are not authorized to run this job!${reset}"
        error()
      }
    }
  }

  if ( !(params.Version_ID) || !(params.Build_ID) || !(params.Client) || !(params.BillingJIRA) || !(params.BaseEnv_ID) ) {
    wrap([$class: 'AnsiColorBuildWrapper']) {
      println "${red}Please specify all the parameters!${reset}"
      error()
    }
  }

  // Set build description
  currentBuild.description = "${Version_ID}-${Build_ID}${Sub_Deployment} ⇨ ${Client}"

  // Publisher vars
  env.App_Name = 'Publisher'
  env.Data_Bag = 'publish'
  if ( Client == "Renault" ) {
    client_key = 'ren'
    bucket_name = "ren-helios-pipeline-cloudformation-bucket"
    // environments = ['use1renprod', 'euw1renprod', 'apn1renprod']
    aws_credentialsId = '	AWS-dlbihelioshostingrenault'
  } else if ( Client == "Nissan" ) {
    client_key = 'nis'
    bucket_name = "nissan-helios-pipeline-cloudformation-bucket"
    // environments = ['use1nisprod', 'euw1nisprod', 'apn1nisprod']
    aws_credentialsId = ''
  } else {
    println "${red}Wrong Client${reset}"
    error()
  }

  def environments = []
  for ( regionOn in [ "US_NumberOfPublishers", "EU_NumberOfPublishers", "APAC_NumberOfPublishers" ] ) {
    if ( US_NumberOfPublishers  != '0' || US_NumberOfPublishers_NNA != "0" ) {
      if ( regionOn == 'US_NumberOfPublishers' ) { environments +=  "use1"+client_key+BaseEnv_ID  }
    }
    if ( EU_NumberOfPublishers  != '0' ) {
      if ( regionOn == 'EU_NumberOfPublishers' ) { environments +=  "euw1"+client_key+BaseEnv_ID  }
    }
    if ( APAC_NumberOfPublishers  != '0' ) {
      if ( regionOn == 'APAC_NumberOfPublishers' ) { environments +=  "apn1"+client_key+BaseEnv_ID  }
    }
  }

  wrap([$class: 'AnsiColorBuildWrapper']) {
    println "${bold}Build Version:${green} ${Version_ID}-${Build_ID}${Sub_Deployment}${reset}"
    println "${bold}Billing Client:${green} ${Client}${reset}"
    println "${bold}Billing JIRA:${green} ${BillingJIRA}${reset}"
    println "${bold}Sub Deployment:${green} ${Sub_Deployment}${reset}"

    for (environment in environments) {
      println "${bold}Environment:${green}--------- ${environment} ${reset}"
      if ( environment =~ /^use1/ ){
        NumberOfPublishers = "${US_NumberOfPublishers}"
        println "${bold}NumberOfPublishers in US Region:${green} ${NumberOfPublishers}${reset}"
        if ( US_NumberOfPublishers_NNA != "0" ) {
          println "${bold}NumberOfPublishers in US Region - NNA:${green} ${US_NumberOfPublishers_NNA}${reset}"
        }
      } else if ( environment =~ /^euw1/ ) {
        NumberOfPublishers = "${EU_NumberOfPublishers}"
        println "${bold}NumberOfPublishers in EU Region:${green} ${NumberOfPublishers}${reset}"
      } else if ( environment =~ /^apn1/ ) {
        NumberOfPublishers = "${APAC_NumberOfPublishers}"
        println "${bold}NumberOfPublishers in APAN Region:${green} ${NumberOfPublishers}${reset}"
      }
    }
    println "${bold}Stack Created/Updated By:${green} ${build_user} - ${build_user_email}${reset}"
  }

  // Check if build exist in Nexus
  stage('Check Build on Nexus') {
    wrap([$class: 'AnsiColorBuildWrapper']) {
      println "${bold}Check Build on Nexus: ${green}Checking the Nexus for build ${Version_ID}-${Build_ID} ${reset}"
      sh '''
        set +x
        if [[ "${App_Name}" == "Publisher" ]] && ! [[ `wget -S --spider --http-user=configurationmanagement --http-password=TNaF204XeQu08g8 "https://nexus-cm.helios-aws.com/service/local/artifact/maven/redirect?r=public&g=com.digitaslbi.helios&a=helios-id-aem&v=build-${BUILD_ID}-${Version_ID}&p=zip" 2>&1 | grep 'HTTP/1.1 200 OK'` ]]; then
          echo "\u001B[31m --- The ${Version_ID} #${BUILD_ID} doesn't exist in Nexus --- \u001B[0m"
          exit 1
        elif [[ "${App_Name}" == "Publisher" ]] && ! [[ `wget -S --spider --http-user=configurationmanagement --http-password=TNaF204XeQu08g8 "https://nexus-cm.helios-aws.com/service/local/artifact/maven/redirect?r=public&g=com.digitaslbi.helios&a=helios-website&v=build-${BUILD_ID}-${Version_ID}&p=zip" 2>&1 | grep 'HTTP/1.1 200 OK'` ]]; then
          echo "\u001B[31m --- The ${Version_ID} #${BUILD_ID} doesn't exist in Nexus --- \u001B[0m"
          exit 1
        fi
      '''
    }
  }

  stage('Checkout configuration Repo') {
    wrap([$class: 'AnsiColorBuildWrapper']) {
      println "${bold}Checkout: ${green}Checkout the configuration repository ${reset}"
      // Checkout configuration repository
      checkout changelog: false, poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']],
      doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'WipeWorkspace']], submoduleCfg: [],
      userRemoteConfigs: [[credentialsId: '	97c54a1a-01f7-44f1-88b8-b88740cd3d1a', url: 'https://gitlab.helios-aws.com/helios/ops/configuration.git']]]
    }
  }

  stage('Install Bundles and Update Databag') {
    withEnv(["PATH=/var/lib/jenkins/.rbenv/shims:/var/lib/jenkins/.rbenv/bin:/var/lib/jenkins/.rbenv/plugins/ruby_build/bin:/usr/local/bin:/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/sbin"]) {
      wrap([$class: 'AnsiColorBuildWrapper']) {
        println "${bold}Install Bundles and Update Databag: ${green}Installing Chef bundles ${reset}"
        sh '''
          set +x
          cd chef-server
          BUNDLE_GEMFILE=Gemfile_for_knife_pipeline bundle install --path /var/lib/jenkins/pipelines-bundle-path
          rbenv rehash
        '''

        for (environment in environments) {
          // Push databag changes to chef server
          println "${bold}Install Bundles and Update Databag: ${green}Updating the Chef server ${environment} Databag with build ${Version_ID}-${Build_ID} ${reset}"
          sh '#!/bin/sh +x\n' + 'cd chef-server\n' + "BUNDLE_GEMFILE=Gemfile_for_knife_pipeline bundle exec knife exec ../helios-pipeline/set_packages_data_bag.rb ${Data_Bag} ${environment} ${Version_ID} ${BUILD_ID} || exit 1"

          // Commit and Push "version_id and build_id" change to databag in git configuration repo
          println "${bold}Install Bundles and Update Databag: ${green}Downloading the ${environment} Databags changes from Chef server ${reset}"
          sh '#!/bin/sh +x\n' + 'cd chef\n' + "BUNDLE_GEMFILE=../chef-server/Gemfile_for_knife_pipeline bundle exec knife download data_bags/${environment}/${Data_Bag}.json --chef-repo-path ."
        }

        println "${bold}Install Bundles and Update Databag: ${green}Commit and Push Databags changes to configuration repository ${reset}"
        withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: '97c54a1a-01f7-44f1-88b8-b88740cd3d1a',
        usernameVariable: 'GIT_USERNAME', passwordVariable: 'GIT_PASSWORD']]) {
          sh '''
            set +x
            git checkout master
            cd chef
            echo 'Git status is :'
            git status --porcelain
            if [[ `git status --porcelain` ]]; then
              echo 'Pushing data bags changes to master'
              git remote add central https://${GIT_USERNAME}:${GIT_PASSWORD}@gitlab.helios-aws.com/helios/ops/configuration.git
              git config --global user.name "Helios Pipeline"
              git config --global user.email dev.ops@heliosalliance.net
            fi
          '''
          for (environment in environments) {
            sh '#!/bin/sh +x\n' + "cd chef\n" + "if [[ `git status --porcelain` ]]; then\n" + "git add data_bags/${environment}/${Data_Bag}.json\n" +
            "git commit -m 'Version bump to ${Version_ID}-${BUILD_ID} on ${environment} ${Data_Bag} - ${build_user}'\n" + "fi"
          }
          sh '''
            set +x
            cd chef
            git pull
            git push origin master
          '''
        }
      }
    }
  }

  stage('Upload CF to S3 Bucket') {
    // Checkout AWS repository
    checkout changelog: false, poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']],
    doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'WipeWorkspace'],
    [$class: 'RelativeTargetDirectory', relativeTargetDir: 'aws-repo']], submoduleCfg: [],
    userRemoteConfigs: [[credentialsId: '97c54a1a-01f7-44f1-88b8-b88740cd3d1a', url: 'https://gitlab.helios-aws.com/helios/ops/aws.git']]]

    wrap([$class: 'AnsiColorBuildWrapper']) {
      println "${bold}Upload CF to S3 Bucket:${green} Uploading latest CloudFormation template to S3 bucket ${reset}"
    }

    withCredentials([[$class: 'AmazonWebServicesCredentialsBinding', accessKeyVariable: 'AWS_ACCESS_KEY_ID',
    credentialsId: "${aws_credentialsId}", secretKeyVariable: 'AWS_SECRET_ACCESS_KEY']]) {
      withAWS(region:'us-east-1') {
        def createS3 = s3Upload(file:'aws-repo/EC2/Alliance/cfn-Helios-Alliance-AEM.template', bucket:"${bucket_name}",
        path:"${BaseEnv_ID}/cfn-Helios-Alliance-AEM.template")
      }
    }
  }

  stage('Create Stack and Deploy') {
    wrap([$class: 'AnsiColorBuildWrapper']) {
      def stacks = [:]

      DataDogKey = 'https://app.datadoghq.com/intake/webhook/sns?api_key=476951905d37207f4aaddd096884995d'
      IAMProfileName = 'heliosPlatformEC2'
      OperatingSystem = 'CENTOS7'
      CreateAEMAuthor = 'false'
      CreateAEMAuthorDispatchers = 'false'
      CreateAEMDarkPublishers = 'false'
      UsePublishBalancer = 'false'
      CreateAEMPublishers = 'EBS'
      NumberOfAEMAuthorDispatchers = '0'
      NumberOfDarkPublishers = '0'
      DarkPublisherTarMKSnapshot = ''
      AuthorBlobSnapshot = ''
      AuthorTarMKSnapshot = ''
      BillingEndDate = '2018-12-31'
      BillingNotes = ''
      BillingJobCode = ''

      for (environment in environments) {
        def Region = ""
        def CF_Environment = ""
        def NumberOfPublishers = ""
        def PublisherTarMKSnapshot = ""
        def SubEnvironment = ""
        def SubEnvironment_NNA = ""
        env.GlobalEnv = "true"
        env.EnableNNAEnv  = "false"
        env.GlobalKeyName = ""

        if ( environment =~ /^use1/ ){
          Region = 'us-east-1'
          CF_Environment = "${environment}"
          NumberOfPublishers = "${US_NumberOfPublishers}"
          PublisherTarMKSnapshot = "${US_PublisherTarMKSnapshot}"

          if ( Client == "Nissan" ) {
            if ( CF_Environment =~ /use1nisprod/ && US_NumberOfPublishers != "0" ) {
              GlobalKeyName = "-Global"
            } else {
              GlobalEnv = "false"
            }

            if ( CF_Environment =~ /use1nisprod/ && US_NumberOfPublishers_NNA != "0" ) {
              EnableNNAEnv = "true"
              SubEnvironment_NNA = "-nna"
              US_NumberOfPublishers_NNA = "${US_NumberOfPublishers_NNA}"
            }
          }
        } else if ( environment =~ /^euw1/ ) {
          Region = 'eu-west-1'
          CF_Environment = "${environment}"
          NumberOfPublishers = "${EU_NumberOfPublishers}"
          PublisherTarMKSnapshot = "${EU_PublisherTarMKSnapshot}"
        } else if ( environment =~ /^apn1/ ) {
          Region = 'ap-northeast-1'
          CF_Environment = "${environment}"
          NumberOfPublishers = "${APAC_NumberOfPublishers}"
          PublisherTarMKSnapshot = "${APAC_PublisherTarMKSnapshot}"
        }
        stacks["${environment}"] = {
          sver = "${Version_ID}".replaceAll("\\.", "-")
          withCredentials([[$class: 'AmazonWebServicesCredentialsBinding', accessKeyVariable: 'AWS_ACCESS_KEY_ID',
          credentialsId: "${aws_credentialsId}", secretKeyVariable: 'AWS_SECRET_ACCESS_KEY']]) {
            withAWS(region:"${Region}") {
              if ( GlobalEnv == "true" ) {
                println "${bold}Create Stack and Deploy:${green} Creating CloudFormation stack ${CF_Environment}-AEMPublisher-${sver}-${Build_ID}${GlobalKeyName}${Sub_Deployment} ${reset}"
                def outputs = cfnUpdate(stack:"${CF_Environment}-AEMPublisher-${sver}-${Build_ID}${GlobalKeyName}${Sub_Deployment}", url:"https://s3.amazonaws.com/${bucket_name}/${BaseEnv_ID}/cfn-Helios-Alliance-AEM.template",
                params:["CreatedUpdatedBy=${build_user_email}", "Client=${Client}", "BillingEndDate=${BillingEndDate}", "BillingNotes=${BillingNotes}",
                "DataDogKey=${DataDogKey}", "Environment=${CF_Environment}", "IAMProfileName=${IAMProfileName}", "NumberOfPublishers=${NumberOfPublishers}",
                "BillingWorkstreamName=${BillingWorkstreamName}", "BillingJIRA=${BillingJIRA}", "BillingJobCode=${BillingJobCode}", "NumberOfDarkPublishers=${NumberOfDarkPublishers}",
                "OperatingSystem=${OperatingSystem}", "SubEnvironment=${SubEnvironment}", "UsePublishBalancer=${UsePublishBalancer}", "AuthorBlobSnapshot=${AuthorBlobSnapshot}",
                "NumberOfAEMAuthorDispatchers=${NumberOfAEMAuthorDispatchers}", "DarkPublisherTarMKSnapshot=${DarkPublisherTarMKSnapshot}", "AuthorTarMKSnapshot=${AuthorTarMKSnapshot}",
                "buildNumber=${Build_ID}", "version=${sver}", "PublisherTarMKSnapshot=${PublisherTarMKSnapshot}", "CreateAEMPublishers=${CreateAEMPublishers}"],
                pollInterval:1000,timeoutInMinutes: 60)
                println "${bold}Create Stack and Deploy:${green} CloudFormation stack ${CF_Environment}-AEMPublisher-${sver}-${Build_ID}${GlobalKeyName}${Sub_Deployment} has been created${reset}"
              }

              if ( EnableNNAEnv == "true" ) {
                println "${bold}Create Stack and Deploy:${green} Creating CloudFormation stack ${CF_Environment}-AEMPublisher-${sver}-${Build_ID}-NNA${Sub_Deployment} ${reset}"
                // def nna_outputs = cfnUpdate(stack:"${CF_Environment}-AEMPublisher-${sver}-${Build_ID}-NNA${Sub_Deployment}", url:"https://s3.amazonaws.com/${bucket_name}/${BaseEnv_ID}/cfn-Helios-Alliance-AEM.template",
                // params:["CreatedUpdatedBy=${build_user_email}", "Client=${Client}", "BillingEndDate=${BillingEndDate}", "BillingNotes=${BillingNotes}",
                // "DataDogKey=${DataDogKey}", "Environment=${CF_Environment}", "IAMProfileName=${IAMProfileName}", "NumberOfPublishers=${US_NumberOfPublishers_NNA}",
                // "BillingWorkstreamName=${BillingWorkstreamName}", "BillingJIRA=${BillingJIRA}", "BillingJobCode=${BillingJobCode}", "NumberOfDarkPublishers=${NumberOfDarkPublishers}",
                // "OperatingSystem=${OperatingSystem}", "SubEnvironment=${SubEnvironment_NNA}", "UsePublishBalancer=${UsePublishBalancer}", "AuthorBlobSnapshot=${AuthorBlobSnapshot}",
                // "NumberOfAEMAuthorDispatchers=${NumberOfAEMAuthorDispatchers}", "DarkPublisherTarMKSnapshot=${DarkPublisherTarMKSnapshot}", "AuthorTarMKSnapshot=${AuthorTarMKSnapshot}",
                // "buildNumber=${Build_ID}", "version=${sver}", "PublisherTarMKSnapshot=${PublisherTarMKSnapshot}", "CreateAEMPublishers=${CreateAEMPublishers}"],
                // pollInterval:1000)
                println "${bold}Create Stack and Deploy:${green} CloudFormation stack ${CF_Environment}-AEMPublisher-${sver}-${Build_ID}-NNA${Sub_Deployment} has been created${reset}"
              }
            }
          }
        }
      }
      parallel stacks
    }
  }

  // Metadata
  sver = "${Version_ID}".replaceAll("\\.", "-")
  def Metadata = "Metadata.txt"
  writeFile file: "${Metadata}",
  text: """Generated by Helios Pipeline\r\nBuild Version: ${Version_ID}-${Build_ID}${Sub_Deployment}\r\nBilling Client: ${Client}\r\nBilling JIRA: ${BillingJIRA}\r\n""" +
  """Billing Work Stream Name: ${BillingWorkstreamName}\r\nDataDogKey: ${DataDogKey}\r\nIAMProfileName: ${IAMProfileName}\r\nOperatingSystem: ${OperatingSystem}\r\n""" +
  """UsePublishBalancer: ${UsePublishBalancer}\r\nStack Created/Updated By: ${build_user} - ${build_user_email}"""

  for (environment in environments) {
    def M_Region = ""
    def M_CF_Environment = ""
    def Stack_Describe = ""
    NumberOfPublishers = ""
    PublisherTarMKSnapshot = ""

    if ( environment =~ /^use1/ ){
      M_CF_Environment = "${environment}"
      M_Region = 'us-east-1'
      NumberOfPublishers = "${US_NumberOfPublishers}"
      PublisherTarMKSnapshot = "${US_PublisherTarMKSnapshot}"
    } else if ( environment =~ /^euw1/ ) {
      M_CF_Environment = "${environment}"
      M_Region = 'eu-west-1'
      NumberOfPublishers = "${EU_NumberOfPublishers}"
      PublisherTarMKSnapshot = "${EU_PublisherTarMKSnapshot}"
    } else if ( environment =~ /^apn1/ ) {
      M_CF_Environment = "${environment}"
      M_Region = 'ap-northeast-1'
      NumberOfPublishers = "${APAC_NumberOfPublishers}"
      PublisherTarMKSnapshot = "${APAC_PublisherTarMKSnapshot}"
    }

    if ( GlobalEnv == "true" ) {
      MetaContent  = readFile "${Metadata}"
      Stack_Node_Hostnames = get_stack_node_hostname(M_Region,M_CF_Environment)
      writeFile file: "${Metadata}",
      text: MetaContent+"""\r\n--- Environment: ${M_CF_Environment}\r\nStack Name: ${M_CF_Environment}-AEMPublisher-${sver}-${Build_ID}${GlobalKeyName}${Sub_Deployment}\r\nPublisherTarMKSnapshot: ${PublisherTarMKSnapshot}\r\n""" +
      """NumberOfPublishers in ${M_Region} Region: ${NumberOfPublishers}"""

      "${Stack_Node_Hostnames}".split(",").each { HostName ->
        Instance_IP = get_node_ip_by_hostname(M_Region,HostName)
        MetaContent  = readFile "${Metadata}"
        writeFile file: "${Metadata}", text: MetaContent+"\r\nHost Name: ${HostName} - ${Instance_IP}"
      }
    }

    if ( EnableNNAEnv == "true" ) {
      MetaContent  = readFile "${Metadata}"
      Stack_Node_Hostnames_nna = get_stack_node_hostname_nna(M_Region,M_CF_Environment)
      writeFile file: "${Metadata}",
      text: MetaContent+"""\r\n--- Environment: ${M_CF_Environment}-nna\r\nStack Name: ${M_CF_Environment}-AEMPublisher-${sver}-${Build_ID}-NNA${Sub_Deployment}\r\nPublisherTarMKSnapshot: ${PublisherTarMKSnapshot}\r\n""" +
      """NumberOfPublishers in ${M_Region} Region: ${US_NumberOfPublishers_NNA}"""

      "${Stack_Node_Hostnames_nna}".split(",").each { HostName ->
        Instance_IP = get_node_ip_by_hostname(M_Region,HostName)
        MetaContent  = readFile "${Metadata}"
        writeFile file: "${Metadata}", text: MetaContent+"\r\nHost Name: ${HostName} - ${Instance_IP}"
      }
    }
  }

  stage('Pipeline Metadata') {
    wrap([$class: 'AnsiColorBuildWrapper']) {
      def FileContent  = readFile "${Metadata}"
      println "${bold}${FileContent}${reset}"
    }
  }

  step([$class: 'WsCleanup'])
  deleteDir()
}

//
def get_node_ip_by_hostname(Region,HostName){
  withCredentials([[$class: 'AmazonWebServicesCredentialsBinding', accessKeyVariable: 'AWS_ACCESS_KEY_ID',
  credentialsId: "${aws_credentialsId}", secretKeyVariable: 'AWS_SECRET_ACCESS_KEY']]) {
    withAWS(region:"${Region}") {
      def Instance_IP = sh(
      script: '#!/bin/sh +x\n' + "aws ec2 describe-instances --filters 'Name=tag:Hostname,Values=${HostName}' 'Name=instance-state-name,Values=running' --query 'Reservations[].Instances[].[PrivateIpAddress]' --output text 2>/dev/null | tr -d '\r'",
      returnStdout: true).trim()
      instance_ip = "${Instance_IP}"
    }
  }
  instance_ip
}

def get_stack_node_hostname(Region,CF_Environment){
  sver = "${Version_ID}".replaceAll("\\.", "-")
  withCredentials([[$class: 'AmazonWebServicesCredentialsBinding', accessKeyVariable: 'AWS_ACCESS_KEY_ID',
  credentialsId: "${aws_credentialsId}", secretKeyVariable: 'AWS_SECRET_ACCESS_KEY']]) {
    withAWS(region:"${Region}") {
      def Instances_Hostnames = sh(
      script: '#!/bin/sh +x\n' + "aws ec2 describe-instances --filters 'Name=tag:aws:cloudformation:stack-name,Values=${CF_Environment}-AEMPublisher-${sver}-${BUILD_ID}${GlobalKeyName}${Sub_Deployment}' 'Name=instance-state-name,Values=running' --query 'Reservations[].Instances[].[Tags[?Key==`Hostname`].Value]' --output text 2>/dev/null | tr -d '\r'",
      returnStdout: true).trim()
      Instances_Hostnames = "${Instances_Hostnames}".replaceAll("\n", ",")
      stack_node_hostnames = "${Instances_Hostnames}"
    }
  }
  stack_node_hostnames
}

def get_stack_node_hostname_nna(Region,CF_Environment){
  sver = "${Version_ID}".replaceAll("\\.", "-")
  withCredentials([[$class: 'AmazonWebServicesCredentialsBinding', accessKeyVariable: 'AWS_ACCESS_KEY_ID',
  credentialsId: "${aws_credentialsId}", secretKeyVariable: 'AWS_SECRET_ACCESS_KEY']]) {
    withAWS(region:"${Region}") {
      def Instances_Hostnames = sh(
      script: '#!/bin/sh +x\n' + "aws ec2 describe-instances --filters 'Name=tag:aws:cloudformation:stack-name,Values=${CF_Environment}-AEMPublisher-${sver}-${BUILD_ID}-NNA${Sub_Deployment}' 'Name=instance-state-name,Values=running' --query 'Reservations[].Instances[].[Tags[?Key==`Hostname`].Value]' --output text 2>/dev/null | tr -d '\r'",
      returnStdout: true).trim()
      Instances_Hostnames = "${Instances_Hostnames}".replaceAll("\n", ",")
      stack_node_hostnames = "${Instances_Hostnames}"
    }
  }
  stack_node_hostnames
}
