//
// Change Author maintenance page state in LB, for Nissan or Renault
//
// Renault Virtual Server :
// - https://ih01.eu.heliosrenault.net:9090/apps/zxtm/index.fcgi?name=prod-auth&section=Virtual%20Servers%3AEdit%3ARules
// Renault rule :
// - https://ih01.eu.heliosrenault.net:9090/apps/zxtm/?name=Author_maintenance_page&section=Rules%3AEdit
// Nissan Virtual Server :
// - https://ih01.use.heliosnissan.net:9090/apps/zxtm/index.fcgi?name=prod-auth&section=Virtual%20Servers%3AEdit%3ARules
// Nissan rule :
// - https://ih01.use.heliosnissan.net:9090/apps/zxtm/?name=Author_maintenance_page&section=Rules%3AEdit

properties([
  parameters([
    choice( name: 'brand', choices: 'Renault\nNissan', description: 'Which brand ?'),
    choice( name: 'status', choices: 'Live\nMaintenance', description: 'Set the author to Live or Maintenance ?')
  ])
])

node{

  //******** Configuration ********
  // ANSI color codes
  green='\u001B[32m'
  red='\u001B[31m'
  bold='\u001B[1m'
  reset='\u001B[0m'


  brocade_url_suffix=':9070/api/tm/3.11/'
  brocade_url_suffix_virtual_servers=brocade_url_suffix+'config/active/virtual_servers/'
  withCredentials([usernameColonPassword(credentialsId: '', variable: 'Brocade_Secrets')]) {
    brocade_credentials = Brocade_Secrets
  }

  maintenance_rule_name='Author_maintenance_page'
  virtual_server='prod-auth'

  // Get names from : http://pipeline.clcm.heliosalliance.net/asynchPeople/
  prod_users = [
    // CAP -- add the list of names for the LB author maintaince
  ]

  if ( env.BUILD_NUMBER == '1' ) {
    description = "Job initialisation"
    echo description
    currentBuild.description = description
    currentBuild.result = 'SUCCESS'
    return
  }

  stage ('Processing parameters') {
    wrap([$class: 'AnsiColorBuildWrapper']){
      currentBuild.description = "${env.brand} ⇨ ${env.status}"

      // Only allowing specific users to run the job
      wrap([$class: 'BuildUser']) {
        def user_id = env.BUILD_USER_ID
        build_user = env.BUILD_USER
        build_user_email = env.BUILD_USER_EMAIL
        if ( ! (user_id in prod_users) ){
          println "${red}You are not authorized to run this job!${reset}"
          error()
        }
      }

      if ( env.brand == 'Renault' ) {
        load_balancer = 'ih01.eu.heliosrenault.net'
      } else if ( env.brand == 'Nissan' ) {
        load_balancer = 'ih01.use.heliosnissan.net'
      } else {
        error('wrong brand')
      }

      echo "Load balancer : ${load_balancer}"

    }
  }

  stage ('Test connectivity') {
    wrap([$class: 'AnsiColorBuildWrapper']){
      test_connectivity = sh (
        script:  '#!/bin/sh +x\n' + "curl --max-time 10 -k -u ${brocade_credentials} https://${load_balancer}${brocade_url_suffix} 2>&1 || true",
        returnStdout: true
      ).trim()

      if ( test_connectivity.contains('children') ) {
        echo "Connectivity to ${load_balancer} : OK"
      } else {
        if ( test_connectivity.contains('Failed connect') || test_connectivity.contains('Connection timed out')  ) {
          echo "${red}Timeout while trying to connect to ${load_balancer}${reset}"
          error('')
        } else if  ( test_connectivity.contains('User name or password was invalid') ) {
          echo "${red}Brocade user has to be created on ${load_balancer}${reset}"
          error('')
        } else {
          echo "${red}Unknown error on ${load_balancer} : ${test_connectivity}${reset}"
          error('')
        }
      }
    }
  }

  stage ('Check exiting state') {
    wrap([$class: 'AnsiColorBuildWrapper']){

      all_virtual_servers_command = "curl  --fail -k -u ${brocade_credentials} https://${load_balancer}${brocade_url_suffix_virtual_servers}"

      all_virtual_servers_curl = sh (
        script:  '#!/bin/sh +x\n' + all_virtual_servers_command,
        returnStdout: true
      ).trim()

      all_virtual_servers_json = readJSON text: all_virtual_servers_curl

      if ( ! all_virtual_servers_json['children'].collect { virtual_server == it['name'] }.contains(true) ) {
        echo "${red}${bold}Virtual Server ${virtual_server} doesn't exists on ${load_balancer}${reset}"
        error('')
      }

      my_virtual_servers_command = "curl  --fail -k -u ${brocade_credentials} https://${load_balancer}${brocade_url_suffix_virtual_servers}${virtual_server}"

      my_virtual_servers_curl = sh (
        script:  '#!/bin/sh +x\n' + my_virtual_servers_command,
        returnStdout: true
      ).trim()

      my_virtual_servers_json = readJSON text: my_virtual_servers_curl
      pre_update_rules = my_virtual_servers_json['properties']['basic']['request_rules']

      echo "rules before changes = ${pre_update_rules}"

      // converting pre_update_rules from a JSONArray to an ArrayList
      // in order to use the method 'indexOf' without RejectedAccessException
      pre_update_rules_arraylist=[]
      for (int i=0;i<pre_update_rules.size();i++){
        pre_update_rules_arraylist.add(pre_update_rules.getString(i));
      }
      pre_update_rules = pre_update_rules_arraylist

      if ( ! ( pre_update_rules.contains(maintenance_rule_name) || pre_update_rules.contains('/'+maintenance_rule_name) ) ) {
        echo "${red}${bold}Rule ${maintenance_rule_name} isn't in the Virtual Server ${virtual_server} on ${load_balancer}${reset}"
        error('')
      }

      if ( env.status == 'Maintenance' ) {
        if ( pre_update_rules.contains(maintenance_rule_name) ) {
          echo "${red}${bold}Rule ${maintenance_rule_name} is already enabled in the Virtual Server ${virtual_server} on ${load_balancer}${reset}"
          error('')
          } else {
          echo "Rule ${maintenance_rule_name} will be enabled in the Virtual Server ${virtual_server} on ${load_balancer}"
          pre_update_rules.set( pre_update_rules.indexOf('/'+maintenance_rule_name), maintenance_rule_name );
        }
      }

      if ( env.status == 'Live' ) {
        if ( pre_update_rules.contains('/'+maintenance_rule_name) ) {
          echo "${red}${bold}Rule ${maintenance_rule_name} is already disabled in the Virtual Server ${virtual_server} on ${load_balancer}${reset}"
          error('')
        } else {
          echo "Rule ${maintenance_rule_name} will be disabled in the Virtual Server ${virtual_server} on ${load_balancer}"
          pre_update_rules.set( pre_update_rules.indexOf(maintenance_rule_name), '/'+maintenance_rule_name );
        }
      }

      echo "rules to apply = ${pre_update_rules}"

    }
  }


  stage ('Updates rules') {
    wrap([$class: 'AnsiColorBuildWrapper']){

      command = "curl --fail -k -u ${brocade_credentials} https://${load_balancer}${brocade_url_suffix_virtual_servers}${virtual_server} -X PUT -H 'Content-type: application/json' -d '{\"properties\": {\"basic\":{\"request_rules\":["
      pre_update_rules.each{
        command += "\"${it}\","
      }
      command=command[0..-2]
      command+="]}}}'"

      update_rules_curl = sh (
        script:  '#!/bin/sh +x\n' + command,
        returnStdout: true
      ).trim()

    }

  }

  stage ('Check new state') {
    wrap([$class: 'AnsiColorBuildWrapper']){

      my_virtual_servers_command = "curl  --fail -k -u ${brocade_credentials} https://${load_balancer}${brocade_url_suffix_virtual_servers}${virtual_server}"

      post_update_virtual_servers_curl = sh (
        script:  '#!/bin/sh +x\n' + my_virtual_servers_command,
        returnStdout: true
      ).trim()

      post_update_virtual_servers_json = readJSON text: post_update_virtual_servers_curl
      post_update_rules = post_update_virtual_servers_json['properties']['basic']['request_rules']

      echo "rules after change = ${post_update_rules}"

      if ( env.status == 'Maintenance' ) {
        if ( post_update_rules.contains(maintenance_rule_name) ) {
          echo "${green}${bold}Rule ${maintenance_rule_name} is now enabled in the Virtual Server ${virtual_server} on ${load_balancer}${reset}"
        } else {
          echo "${red}${bold}Rule ${maintenance_rule_name} hasn't been enabled properly in the Virtual Server ${virtual_server} on ${load_balancer}${reset}"
          error('')
        }
      }

      if ( env.status == 'Live' ) {
        if ( post_update_rules.contains('/'+maintenance_rule_name) ) {
          echo "${green}${bold}Rule ${maintenance_rule_name} is now disabled in the Virtual Server ${virtual_server} on ${load_balancer}${reset}"
        } else {
          echo "${red}${bold}Rule ${maintenance_rule_name} hasn't been disabled properly in the Virtual Server ${virtual_server} on ${load_balancer}${reset}"
          error('')
        }
      }

    }
  }

}
