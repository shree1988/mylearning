#!groovy

env.Version_ID = params.Version_ID
env.Build_ID = params.Build_ID
env.Client = params.Client
env.BillingJIRA = BillingJIRA
env.Sub_Deployment = params.Sub_Deployment
env.BaseEnv_ID = params.BaseEnv_ID

node {
  // Wipe the workspace so we are building completely clean
  deleteDir()

  brocade_url_suffix=':9070/api/tm/5.1/'
  brocade_url_suffix_nodestate=brocade_url_suffix+'status/local_tm/statistics/nodes/per_pool_node/'
  brocade_url_suffix_pools=brocade_url_suffix+'config/active/pools/'
  brocade_url_suffix_rules=brocade_url_suffix+'config/active/rules/'
  bluegreen_rule_name = 'blue_green_tomcat_rule'
  pool_monitor='Simple HTTP'

  // ANSI color codes
  green='\u001B[32m'
  red='\u001B[31m'
  bold='\u001B[1m'
  reset='\u001B[0m'

  // List of users
  def prod_users = [
      'omiladi','abhatt'
  ]

  if (env.BaseEnv_ID == "prod") {
    BillingWorkstreamName = "Production"
  } else if (env.BaseEnv_ID == "stg") {
    BillingWorkstreamName = "Staging"
  } else if (env.BaseEnv_ID == "uat") {
    BillingWorkstreamName = "Integration"
  } else {
    println "${red}prod/uat/stg autho value for BaseEnv_ID${reset}"
    error()
  }

  wrap([$class: 'BuildUser']) {
    def user_id = env.BUILD_USER_ID
    build_user = env.BUILD_USER
    build_user_email = env.BUILD_USER_EMAIL
    if ( !(user_id in prod_users)  && env.BaseEnv_ID == "prod"){
      wrap([$class: 'AnsiColorBuildWrapper']) {
        println "${red}You are not authorized to run this job!${reset}"
        error()
      }
    }
  }

  if ( !(params.Version_ID) || !(params.Build_ID) || !(params.Client) || !(params.BillingJIRA) || !(params.BaseEnv_ID) ) {
    wrap([$class: 'AnsiColorBuildWrapper']) {
      println "${red}Please specify all the parameters!${reset}"
      error()
    }
  }

  // Set build description
  currentBuild.description = "${Version_ID}${Sub_Deployment}-${Build_ID} ⇨ ${Client}"

  // Tomcat vars
  env.App_Name = 'Helios-API'
  env.Data_Bag = 'helios-api'
  if ( Client == "Renault" ) {
    client_key = 'ren'
    bucket_name = "ren-helios-pipeline-cloudformation-bucket"
    // environments = ['use1renprod', 'euw1renprod', 'apn1renprod']
    aws_credentialsId = 'AWS-dlbihelioshostingrenault'
    // load_balancers = [
    // // 'use1' : 'ih01.np.heliosalliance.net'  // FOR TESTS
    //   'use1' : 'ih01.use.heliosrenault.net',
    //   'euw1' : 'ih01.eu.heliosrenault.net',
    //   'apn1' : 'ih01.apt.heliosrenault.net'
    // ]
    load_balancers = [:]
    for ( regionOnNiss in [ "US_NumberOfApiServers", "EU_NumberOfApiServers", "APAC_NumberOfApiServers" ] ) {
      if ( US_NumberOfApiServers  != '0' ) {
        if ( regionOnNiss == 'US_NumberOfApiServers' ) { load_balancers['use1'] = 'ih01.use.heliosrenault.net' }
      }
      if ( EU_NumberOfApiServers  != '0' ) {
        if ( regionOnNiss == 'EU_NumberOfApiServers' ) { load_balancers['euw1'] = 'ih01.eu.heliosrenault.net' }
      }
      if ( APAC_NumberOfApiServers  != '0' ) {
        if ( regionOnNiss == 'APAC_NumberOfApiServers' ) { load_balancers['apn1'] = 'ih01.apt.heliosrenault.net' }
      }
    }
  } else if ( Client == "Nissan" ) {
    client_key = 'nis'
    bucket_name = "nissan-helios-pipeline-cloudformation-bucket"
    // environments = ['use1nisprod', 'euw1nisprod', 'apn1nisprod']
    aws_credentialsId = ''
    // load_balancers = [
    //   'use1' : '',
    //   'euw1' : '',
    //   'apn1' : ''
    // ]

    load_balancers = [:]
    for ( regionOnNiss in [ "US_NumberOfApiServers", "EU_NumberOfApiServers", "APAC_NumberOfApiServers" ] ) {
      if ( US_NumberOfApiServers  != '0' ) {
        if ( regionOnNiss == 'US_NumberOfApiServers' ) { load_balancers['use1'] = 'ih01.use.heliosnissan.net' }
      }
      if ( EU_NumberOfApiServers  != '0' ) {
        if ( regionOnNiss == 'EU_NumberOfApiServers' ) { load_balancers['euw1'] = 'ih01.eu.heliosnissan.net' }
      }
      if ( APAC_NumberOfApiServers  != '0' ) {
        if ( regionOnNiss == 'APAC_NumberOfApiServers' ) { load_balancers['apn1'] = 'ih01.apt.heliosnissan.net' }
      }
    }

  } else {
    println "${red}Wrong Client${reset}"
    error()
  }

  def environments = []
  for ( regionOn in [ "US_NumberOfApiServers", "EU_NumberOfApiServers", "APAC_NumberOfApiServers" ] ) {
    if ( US_NumberOfApiServers  != '0' ) {
      if ( regionOn == 'US_NumberOfApiServers' ) { environments +=  "use1"+client_key+BaseEnv_ID }
    }
    if ( EU_NumberOfApiServers  != '0' ) {
      if ( regionOn == 'EU_NumberOfApiServers' ) { environments +=  "euw1"+client_key+BaseEnv_ID  }
    }
    if ( APAC_NumberOfApiServers  != '0' ) {
      if ( regionOn == 'APAC_NumberOfApiServers' ) { environments +=  "apn1"+client_key+BaseEnv_ID  }
    }
  }

  pool_name_suffix = "${client_key}${BaseEnv_ID}-servicetomcat-${Version_ID}${Sub_Deployment}-${Build_ID}${Sub_Deployment}"

  wrap([$class: 'AnsiColorBuildWrapper']) {
    println "${bold}Build Version:${green} ${Version_ID}${Sub_Deployment}-${Build_ID}${reset}"
    println "${bold}Billing Client:${green} ${Client}${reset}"
    println "${bold}Billing JIRA:${green} ${BillingJIRA}${reset}"
    println "${bold}Sub Deployment:${green} ${Sub_Deployment}${reset}"

    for (environment in environments) {
      println "${bold}Environment:${green}--------- ${environment} ${reset}"
      if ( environment =~ /^use1/ ){
        NumberOfApiServers = "${US_NumberOfApiServers}"
        println "${bold}NumberOfApiServers in US Region:${green} ${NumberOfApiServers}${reset}"
      } else if ( environment =~ /^euw1/ ) {
        NumberOfApiServers = "${EU_NumberOfApiServers}"
        println "${bold}NumberOfApiServers in EU Region:${green} ${NumberOfApiServers}${reset}"
      } else if ( environment =~ /^apn1/ ) {
        NumberOfApiServers = "${APAC_NumberOfApiServers}"
        println "${bold}NumberOfApiServers in APAN Region:${green} ${NumberOfApiServers}${reset}"
      }
    }
    println "${bold}Stack Created/Updated By:${green} ${build_user} - ${build_user_email}${reset}"
  }

  // Check if build exist in Nexus
  stage('Check Build on Nexus') {
    wrap([$class: 'AnsiColorBuildWrapper']) {
      println "${bold}Check Build on Nexus: ${green}Checking the Nexus for build ${Version_ID}-${Build_ID} ${reset}"
      sh '''
        set +x
        if [[ "${App_Name}" == "Helios-API" ]] && ! [[ `wget -S --spider --http-user=configurationmanagement --http-password=TNaF204XeQu08g8 "https://nexus-cm.helios-aws.com/service/local/artifact/maven/redirect?r=public&g=com.digitaslbi.helios&a=helios-api-authorisation&v=build-${BUILD_ID}-${Version_ID}&p=war" 2>&1 | grep 'HTTP/1.1 200 OK'` ]]; then
          echo "\u001B[31m --- The ${Version_ID} #${BUILD_ID} helios-api-authorisation doesn't exist in Nexus --- \u001B[0m"
          echo "\u001B[1m --- Repo URL:\u001B[0m https://nexus-cm.helios-aws.com/service/local/artifact/maven/redirect?r=public&g=com.digitaslbi.helios&a=helios-api-authorisation&v=build-${BUILD_ID}-${Version_ID}&p=war"
          exit 1
        elif [[ "${App_Name}" == "Helios-API" ]] && ! [[ `wget -S --spider --http-user=configurationmanagement --http-password=TNaF204XeQu08g8 "https://nexus-cm.helios-aws.com/service/local/artifact/maven/redirect?r=public&g=com.digitaslbi.helios&a=helios-api-bundle&v=build-${BUILD_ID}-${Version_ID}&p=war" 2>&1 | grep 'HTTP/1.1 200 OK'` ]]; then
        echo "\u001B[31m --- The ${Version_ID} #${BUILD_ID} helios-api-bundle doesn't exist in Nexus --- \u001B[0m"
        echo "\u001B[1m --- Repo URL:\u001B[0m https://nexus-cm.helios-aws.com/service/local/artifact/maven/redirect?r=public&g=com.digitaslbi.helios&a=helios-api-bundle&v=build-${BUILD_ID}-${Version_ID}&p=war"
          exit 1
        fi
      '''
    }
  }

  stage('Checkout configuration Repo') {
    wrap([$class: 'AnsiColorBuildWrapper']) {
      println "${bold}Checkout: ${green}Checkout the configuration repository ${reset}"
      // Checkout configuration repository
      checkout changelog: false, poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']],
      doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'WipeWorkspace']], submoduleCfg: [],
      userRemoteConfigs: [[credentialsId: '97c54a1a-01f7-44f1-88b8-b88740cd3d1a', url: 'https://gitlab.helios-aws.com/helios/ops/configuration.git']]]
    }
  }

  stage('Install Bundles and Update Databag') {
    withEnv(["PATH=/var/lib/jenkins/.rbenv/shims:/var/lib/jenkins/.rbenv/bin:/var/lib/jenkins/.rbenv/plugins/ruby_build/bin:/usr/local/bin:/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/sbin"]) {
      wrap([$class: 'AnsiColorBuildWrapper']) {
        println "${bold}Install Bundles and Update Databag: ${green}Installing Chef bundles ${reset}"
        sh '''
          set +x
          cd chef-server
          BUNDLE_GEMFILE=Gemfile_for_knife_pipeline bundle install --path /var/lib/jenkins/pipelines-bundle-path
          rbenv rehash
        '''

        for (environment in environments) {
          // Push databag changes to chef server
          println "${bold}Install Bundles and Update Databag: ${green}Updating the Chef server ${environment} Databag with build ${Version_ID}-${Build_ID} ${reset}"
          sh '#!/bin/sh +x\n' + 'cd chef-server\n' + "BUNDLE_GEMFILE=Gemfile_for_knife_pipeline bundle exec knife exec ../helios-pipeline/set_packages_data_bag.rb ${Data_Bag} ${environment} ${Version_ID} ${BUILD_ID} || exit 1"

          // Commit and Push "version_id and build_id" change to databag in git configuration repo
          println "${bold}Install Bundles and Update Databag: ${green}Downloading the ${environment} Databags changes from Chef server ${reset}"
          sh '#!/bin/sh +x\n' + 'cd chef\n' + "BUNDLE_GEMFILE=../chef-server/Gemfile_for_knife_pipeline bundle exec knife download data_bags/${environment}/${Data_Bag}.json --chef-repo-path ."
        }

        println "${bold}Install Bundles and Update Databag: ${green}Commit and Push Databags changes to configuration repository ${reset}"
        withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: '97c54a1a-01f7-44f1-88b8-b88740cd3d1a',
        usernameVariable: 'GIT_USERNAME', passwordVariable: 'GIT_PASSWORD']]) {
          sh '''
            set +x
            git checkout master
            cd chef
            echo 'Git status is :'
            git status --porcelain
            if [[ `git status --porcelain` ]]; then
              echo 'Pushing data bags changes to master'
              git remote add central https://${GIT_USERNAME}:${GIT_PASSWORD}@gitlab.helios-aws.com/helios/ops/configuration.git
              git config --global user.name "Helios Pipeline"
              git config --global user.email dev.ops@heliosalliance.net
            fi
          '''
          for (environment in environments) {
            sh '#!/bin/sh +x\n' + "cd chef\n" + "if [[ `git status --porcelain` ]]; then\n" + "git add data_bags/${environment}/${Data_Bag}.json\n" +
            "git commit -m 'Version bump to ${Version_ID}-${BUILD_ID} on ${environment} ${Data_Bag} - ${build_user}'\n" + "fi"
          }
          sh '''
            set +x
            cd chef
            git pull
            git push origin master
          '''
        }
      }
    }
  }

  stage('Upload CF to S3 Bucket') {
    // Checkout AWS repository
    checkout changelog: false, poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']],
    doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'WipeWorkspace'],
    [$class: 'RelativeTargetDirectory', relativeTargetDir: 'aws-repo']], submoduleCfg: [],
    userRemoteConfigs: [[credentialsId: '97c54a1a-01f7-44f1-88b8-b88740cd3d1a', url: 'https://gitlab.helios-aws.com/helios/ops/aws.git']]]

    wrap([$class: 'AnsiColorBuildWrapper']) {
      println "${bold}Upload CF to S3 Bucket:${green} Uploading latest CloudFormation template to S3 bucket ${reset}"
    }

    withCredentials([[$class: 'AmazonWebServicesCredentialsBinding', accessKeyVariable: 'AWS_ACCESS_KEY_ID',
    credentialsId: "${aws_credentialsId}", secretKeyVariable: 'AWS_SECRET_ACCESS_KEY']]) {
      withAWS(region:'us-east-1') {
        def createS3 = s3Upload(file:'aws-repo/EC2/Alliance/cfn-Helios-Alliance-ServicesTierTomcat.template', bucket:"${bucket_name}",
        path:"${BaseEnv_ID}/cfn-Helios-Alliance-ServicesTierTomcat.template")
      }
    }
  }

  stage('Create Stack and Deploy') {
    wrap([$class: 'AnsiColorBuildWrapper']) {
      def stacks = [:]

      DataDogKey = 'https://app.datadoghq.com/intake/webhook/sns?api_key=476951905d37207f4aaddd096884995d'
      IAMProfileName = 'heliosPlatformEC2'
      OperatingSystem = 'CENTOS7'
      OperatorEmail = 'oussama.miladi@capgemini.com'
      UseTomcatBalancer = 'true'
      SubEnvironment = ''
      BillingEndDate = ''
      BillingNotes = ''
      BillingJobCode = ''

      for (environment in environments) {
        def Region = ""
        def CF_Environment = ""
        def NumberOfApiServers = ""

        if ( environment =~ /^use1/ ){
          Region = 'us-east-1'
          CF_Environment = "${environment}"
          NumberOfApiServers = "${US_NumberOfApiServers}"
        } else if ( environment =~ /^euw1/ ) {
          Region = 'eu-west-1'
          CF_Environment = "${environment}"
          NumberOfApiServers = "${EU_NumberOfApiServers}"
        } else if ( environment =~ /^apn1/ ) {
          Region = 'ap-northeast-1'
          CF_Environment = "${environment}"
          NumberOfApiServers = "${APAC_NumberOfApiServers}"
        }
        stacks["${environment}"] = {
          sver = "${Version_ID}".replaceAll("\\.", "-")
          withCredentials([[$class: 'AmazonWebServicesCredentialsBinding', accessKeyVariable: 'AWS_ACCESS_KEY_ID',
          credentialsId: "${aws_credentialsId}", secretKeyVariable: 'AWS_SECRET_ACCESS_KEY']]) {
            withAWS(region:"${Region}") {
              println "${bold}Create Stack and Deploy:${green} Creating CloudFormation stack ${CF_Environment}-ServicesTomcatStack-${sver}-${Build_ID}${Sub_Deployment} ${reset}"
              def outputs = cfnUpdate(stack:"${CF_Environment}-ServicesTomcatStack-${sver}-${Build_ID}${Sub_Deployment}", url:"https://s3.amazonaws.com/${bucket_name}/${BaseEnv_ID}/cfn-Helios-Alliance-ServicesTierTomcat.template",
              params:["CreatedUpdatedBy=${build_user_email}", "Client=${Client}", "BillingEndDate=${BillingEndDate}", "BillingNotes=${BillingNotes}",
              "DataDogKey=${DataDogKey}", "Environment=${CF_Environment}", "IAMProfileName=${IAMProfileName}", "NumberOfApiServers=${NumberOfApiServers}",
              "BillingWorkstreamName=${BillingWorkstreamName}", "BillingJIRA=${BillingJIRA}", "BillingJobCode=${BillingJobCode}",
              "OperatingSystem=${OperatingSystem}", "OperatorEmail=${OperatorEmail}", "SubEnvironment=${SubEnvironment}",
              "UseTomcatBalancer=${UseTomcatBalancer}", "buildNumber=${Build_ID}", "version=${sver}", "SubDeployment=${Sub_Deployment}"],
              pollInterval:1000,timeoutInMinutes: 60)
              println "${bold}Create Stack and Deploy:${green} CloudFormation stack ${CF_Environment}-ServicesTomcatStack-${sver}-${Build_ID}${Sub_Deployment} has been created${reset}"
            }
          }
        }
      }
      parallel stacks
    }
  }

  stage('Apps Smoke Test') {
    wrap([$class: 'AnsiColorBuildWrapper']) {
      def smokes = [:]

      for (environment in environments) {
        def AP_Region = ""
        def AP_CF_Environment = ""

        if ( environment =~ /^use1/ ){
          AP_CF_Environment = "${environment}"
          AP_Region = 'us-east-1'
        } else if ( environment =~ /^euw1/ ) {
          AP_CF_Environment = "${environment}"
          AP_Region = 'eu-west-1'
        } else if ( environment =~ /^apn1/ ) {
          AP_CF_Environment = "${environment}"
          AP_Region = 'ap-northeast-1'
        }

        smokes["${environment}"] = {
          stack_node_hostnames = get_stack_node_hostname(AP_Region,AP_CF_Environment)
          "${stack_node_hostnames}".split(",").each { HostName ->
            env.HostName = "${HostName}"
            env.AP_CF_Environment = "${AP_CF_Environment}"
            println "${bold}Host Name: ${green}${HostName}${reset}"
            println "${bold}Waiting until Tomcat service is up...${reset}"
            get_app_state(HostName)
            withCredentials([file(credentialsId: 'd1098693-4514-4e42-b52f-cb97075d3a10', variable: 'SECRET_FILE'),
            string(credentialsId: 'd2931848-5fbb-4a2a-adee-232ebc4524f5', variable: 'SECRET_USER')]) {
              sh '''
                set +x
                data_bag_items=$(knife exec helios-pipeline/get_databag_items.rb ${AP_CF_Environment} helios-api "name")
                while read itemname; do
                  if ! [[ $itemname == "helios-api-offers-dma" ]]; then
                    healthcheck=$(knife ssh -a ipaddress -i ${SECRET_FILE} -x ${SECRET_USER} "name:${HostName}" "curl -s http://localhost:8080/$itemname/healthcheck && echo")
                    if ! [[ $healthcheck =~ ${Version_ID}.build-${BUILD_ID} ]]; then
                      echo "\u001B[31m --- $itemname: No property match with the Version and Build ID \u001B[0m"
                      #### exit 1
                    else
                      echo "\u001B[32m --- $itemname: The package ${Version_ID}-${BUILD_ID} has been deployed \u001B[0m"
                    fi
                  fi
                done <<< "$data_bag_items"
              '''
            }
          }
        }
      }
      parallel smokes
    }
  }

  stage('AWS LoadBalancer HealthCheck') {
    wrap([$class: 'AnsiColorBuildWrapper']) {
      def albs = [:]

      for (environment in environments) {
        def LB_Region = ""
        def LB_CF_Environment = ""

        if ( environment =~ /^use1/ ){
          LB_CF_Environment = "${environment}"
          LB_Region = 'us-east-1'
        } else if ( environment =~ /^euw1/ ) {
          LB_CF_Environment = "${environment}"
          LB_Region = 'eu-west-1'
        } else if ( environment =~ /^apn1/ ) {
          LB_CF_Environment = "${environment}"
          LB_Region = 'ap-northeast-1'
        }

        albs["${environment}"] = {
          println "${bold}Instances Health Check: ${green}${LB_CF_Environment}${reset}"
          get_instance_health(LB_Region,LB_CF_Environment)
        }
      }
      parallel albs
    }
  }

  sver = "${Version_ID}".replaceAll("\\.", "-")
  def Metadata = "Metadata.txt"
  writeFile file: "${Metadata}",
  text: """Generated by Helios Pipeline\r\nBuild Version: ${Version_ID}${Sub_Deployment}-${Build_ID}\r\nBilling Client: ${Client}\r\nBilling JIRA: ${BillingJIRA}\r\n""" +
  """Billing Work Stream Name: ${BillingWorkstreamName}\r\nDataDogKey: ${DataDogKey}\r\nIAMProfileName: ${IAMProfileName}\r\nOperatingSystem: ${OperatingSystem}""" +
  """OperatorEmail: ${OperatorEmail}\r\nUseTomcatBalancer: ${UseTomcatBalancer}\r\nStack Created/Updated By: ${build_user} - ${build_user_email}"""

  for (environment in environments) {
    def M_Region = ""
    def M_CF_Environment = ""
    def Stack_Describe = ""

    if ( environment =~ /^use1/ ){
      M_CF_Environment = "${environment}"
      M_Region = 'us-east-1'
    } else if ( environment =~ /^euw1/ ) {
      M_CF_Environment = "${environment}"
      M_Region = 'eu-west-1'
    } else if ( environment =~ /^apn1/ ) {
      M_CF_Environment = "${environment}"
      M_Region = 'ap-northeast-1'
    }
    Stack_Node_Hostnames = get_stack_node_hostname(M_Region,M_CF_Environment)
    withCredentials([[$class: 'AmazonWebServicesCredentialsBinding', accessKeyVariable: 'AWS_ACCESS_KEY_ID',
    credentialsId: "${aws_credentialsId}", secretKeyVariable: 'AWS_SECRET_ACCESS_KEY']]) {
      withAWS(region:"${M_Region}") {
        Stack_Describe = cfnDescribe(stack:"${M_CF_Environment}-ServicesTomcatStack-${sver}-${Build_ID}${Sub_Deployment}")
      }
    }
    Stack_Describe = "${Stack_Describe}".replaceFirst('\\[BalancerHostname:','')
    Stack_Describe = "${Stack_Describe}".replaceAll('\\.]','')

    MetaContent  = readFile "${Metadata}"

    writeFile file: "${Metadata}",
    text: MetaContent+"""\r\n--- Environment: ${M_CF_Environment}\r\nStack Name: ${M_CF_Environment}-ServicesTomcatStack-${sver}-${Build_ID}${Sub_Deployment}\r\n""" +
    """Balancer Hostname: ${Stack_Describe}\r\nNumberOfApiServers in ${M_Region} Region: ${US_NumberOfApiServers}"""


    "${Stack_Node_Hostnames}".split(",").each { HostName ->
      Instance_IP = get_node_ip_by_hostname(M_Region,HostName)
      MetaContent  = readFile "${Metadata}"
      writeFile file: "${Metadata}", text: MetaContent+"\r\nHost Name: ${HostName} - ${Instance_IP}"
    }

    if ( environment =~ /^use1/ ){
      US_Stack_Describe = "${Stack_Describe}"
    } else if ( environment =~ /^euw1/ ) {
      EU_Stack_Describe = "${Stack_Describe}"
    } else if ( environment =~ /^apn1/ ) {
      AP_Stack_Describe = "${Stack_Describe}"
    }
  }


  stage('Pipeline Metadata') {
    wrap([$class: 'AnsiColorBuildWrapper']) {
      def FileContent  = readFile "${Metadata}"
      println "${bold}${FileContent}${reset}"
    }
  }

  step([$class: 'WsCleanup'])
  deleteDir()
}

// @NonCPS
def get_stack_node_ip(Region,CF_Environment){
  sver = "${Version_ID}".replaceAll("\\.", "-")
  withCredentials([[$class: 'AmazonWebServicesCredentialsBinding', accessKeyVariable: 'AWS_ACCESS_KEY_ID',
  credentialsId: "${aws_credentialsId}", secretKeyVariable: 'AWS_SECRET_ACCESS_KEY']]) {
    withAWS(region:"${Region}") {
      def Instances_IP = sh(
      script: '#!/bin/sh +x\n' + "aws ec2 describe-instances --filters 'Name=tag:aws:cloudformation:stack-name,Values=${CF_Environment}-ServicesTomcatStack-${sver}-${BUILD_ID}${Sub_Deployment}' 'Name=instance-state-name,Values=running' --query 'Reservations[].Instances[].[PrivateIpAddress]' --output text 2>/dev/null | tr -d '\r'",
      returnStdout: true).trim()
      stack_node_ips = "${Instances_IP}"
    }
  }
  stack_node_ips
}

def get_node_ip_by_hostname(Region,HostName){
  withCredentials([[$class: 'AmazonWebServicesCredentialsBinding', accessKeyVariable: 'AWS_ACCESS_KEY_ID',
  credentialsId: "${aws_credentialsId}", secretKeyVariable: 'AWS_SECRET_ACCESS_KEY']]) {
    withAWS(region:"${Region}") {
      def Instance_IP = sh(
      script: '#!/bin/sh +x\n' + "aws ec2 describe-instances --filters 'Name=tag:Hostname,Values=${HostName}' 'Name=instance-state-name,Values=running' --query 'Reservations[].Instances[].[PrivateIpAddress]' --output text 2>/dev/null | tr -d '\r'",
      returnStdout: true).trim()
      instance_ip = "${Instance_IP}"
    }
  }
  instance_ip
}

def get_stack_node_hostname(Region,CF_Environment){
  sver = "${Version_ID}".replaceAll("\\.", "-")
  withCredentials([[$class: 'AmazonWebServicesCredentialsBinding', accessKeyVariable: 'AWS_ACCESS_KEY_ID',
  credentialsId: "${aws_credentialsId}", secretKeyVariable: 'AWS_SECRET_ACCESS_KEY']]) {
    withAWS(region:"${Region}") {
      def Instances_Hostnames = sh(
      script: '#!/bin/sh +x\n' + "aws ec2 describe-instances --filters 'Name=tag:aws:cloudformation:stack-name,Values=${CF_Environment}-ServicesTomcatStack-${sver}-${BUILD_ID}${Sub_Deployment}' 'Name=instance-state-name,Values=running' --query 'Reservations[].Instances[].[Tags[?Key==`Hostname`].Value]' --output text 2>/dev/null | tr -d '\r'",
      returnStdout: true).trim()
      Instances_Hostnames = "${Instances_Hostnames}".replaceAll("\n", ",")
      stack_node_hostnames = "${Instances_Hostnames}"
    }
  }
  stack_node_hostnames
}

def get_app_state(HostName){
  withCredentials([file(credentialsId: 'd1098693-4514-4e42-b52f-cb97075d3a10', variable: 'SECRET_FILE'),
  string(credentialsId: 'd2931848-5fbb-4a2a-adee-232ebc4524f5', variable: 'SECRET_USER')]) {
    def Wait_For_State = sh(
    script: "#!/bin/sh +x\n" + 'knife ssh -a ipaddress -i ${SECRET_FILE} -x ${SECRET_USER} "name:${HostName}" \'while [[ "$(curl -s -o /dev/null -w "%{http_code}" http://localhost:8080/helios-api-bundle/healthcheck)" != "200" ]]; do sleep 10; done\'',
    returnStdout: true).trim()
  }
}

def get_instance_health(Region,CF_Environment){
  wrap([$class: 'AnsiColorBuildWrapper']) {
    def TomcatTargetGroup_Arn = ""
    def Instances_Id = ""
    def Instances_Health = ""
    sver = "${Version_ID}".replaceAll("\\.", "-")
    withCredentials([[$class: 'AmazonWebServicesCredentialsBinding', accessKeyVariable: 'AWS_ACCESS_KEY_ID',
    credentialsId: "${aws_credentialsId}", secretKeyVariable: 'AWS_SECRET_ACCESS_KEY']]) {
      withAWS(region:"${Region}") {
        TomcatTargetGroup_Arn = sh(
        script: '#!/bin/sh +x\n' + "aws cloudformation describe-stack-resource --stack-name ${CF_Environment}-ServicesTomcatStack-${sver}-${BUILD_ID}${Sub_Deployment} --logical-resource-id TomcatTargetGroup --query 'StackResourceDetail.PhysicalResourceId' --output text 2>/dev/null | tr -d '\r'",
        returnStdout: true).trim()

        Instances_Id = sh(
        script: '#!/bin/sh +x\n' + "aws elbv2 describe-target-health --target-group-arn ${TomcatTargetGroup_Arn} --query 'TargetHealthDescriptions[].Target.Id' --output text 2>/dev/null",
        returnStdout: true).trim()
        Instances_Id = "${Instances_Id}".replaceAll("\t", ",")

        "${Instances_Id}".split(",").each { InstanceId ->
          Instances_Health = sh(
          script: '#!/bin/sh +x\n' + "aws elbv2 describe-target-health --target-group-arn ${TomcatTargetGroup_Arn} --targets Id=${InstanceId} --query 'TargetHealthDescriptions[].TargetHealth.State' --output text 2>/dev/null",
          returnStdout: true).trim()
          println "${bold}Instance: ${InstanceId} State is: ${green}${Instances_Health}${reset}"
        }
      }
    }
  }
}
