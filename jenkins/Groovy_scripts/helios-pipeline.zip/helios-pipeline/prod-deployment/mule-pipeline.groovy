#!groovy

env.Version_ID = params.Version_ID
env.Build_ID = params.Build_ID
env.Client = params.Client
env.BaseEnv_ID = params.BaseEnv_ID

node {
  // Wipe the workspace so we are building completely clean
  deleteDir()

  // ANSI color codes
  green='\u001B[32m'
  red='\u001B[31m'
  bold='\u001B[1m'
  reset='\u001B[0m'

  // List of users
  def prod_users = [
      'omiladi','abhatt'
  ]

  wrap([$class: 'BuildUser']) {
    def user_id = env.BUILD_USER_ID
    build_user = env.BUILD_USER
    build_user_email = env.BUILD_USER_EMAIL
    if ( !(user_id in prod_users)  && env.BaseEnv_ID == "prod"){
      wrap([$class: 'AnsiColorBuildWrapper']) {
        println "${red}you are not authorized to run this job!${reset}"
        error()
      }
    }
  }

  if ( !(params.Version_ID) || !(params.Build_ID) || !(params.Client) ) {
    wrap([$class: 'AnsiColorBuildWrapper']) {
      println "${red}Please specify all the parameters!${reset}"
      error()
    }
  }

  // Set build description
  currentBuild.description = "${Version_ID}-${Build_ID} ⇨ ${Client}"

  // Mule vars
  env.App_Name = 'Mule'
  env.Data_Bag = 'mule-esb'
  env.Chef_ENV = 'use1ren' + env.BaseEnv_ID
  env.Chef_Node_Search = 'chef_environment:' + env.Chef_ENV + ' AND recipes:*esb*'

  wrap([$class: 'AnsiColorBuildWrapper']) {
    println "${bold}Build Version:${green} ${Version_ID}-${Build_ID}${reset}"
    println "${bold}Client:${green} ${Client}${reset}"
    println "${bold}Environment:${green} ${Chef_ENV}${reset}"
    println "${bold}Databag:${green} ${Data_Bag}${reset}"
    println "${bold}Run By:${green} ${build_user} - ${build_user_email} ${reset}"
  }

  // Check if build exist in Nexus
  stage('Check Build on Nexus') {

    wrap([$class: 'AnsiColorBuildWrapper']) {
      println "${bold}Check Build on Nexus: ${green}Checking the Nexus for build ${Version_ID}-${BUILD_ID} ${reset}"
      sh '''
        set +x
        if [[ "${App_Name}" == "Mule" ]] && ! [[ `wget -S --spider --http-user=configurationmanagement --http-password=TNaF204XeQu08g8 "https://nexus-cm.helios-aws.com/service/local/artifact/maven/redirect?r=public&g=com.digitaslbi.helios&a=helios-mule-accessories&v=build-${BUILD_ID}-${Version_ID}&p=zip" 2>&1 | grep 'HTTP/1.1 200 OK'` ]]; then
          echo "\u001B[31m --- The ${Version_ID} #${BUILD_ID} doesn't exist in Nexus --- \u001B[0m"
          exit 1
        elif [[ "${App_Name}" == "Mule" ]] && ! [[ `wget -S --spider --http-user=configurationmanagement --http-password=TNaF204XeQu08g8 "https://nexus-cm.helios-aws.com/service/local/artifact/maven/redirect?r=public&g=com.digitaslbi.helios&a=helios-mule-specs&v=build-${BUILD_ID}-${Version_ID}&p=zip" 2>&1 | grep 'HTTP/1.1 200 OK'` ]]; then
          echo "\u001B[31m --- The ${Version_ID} #${BUILD_ID} doesn't exist in Nexus --- \u001B[0m"
          exit 1
        fi
      '''
    }
  }

  stage('Checkout') {
    wrap([$class: 'AnsiColorBuildWrapper']) {
      println "${bold}Checkout: ${green}Checkout the configuration repository ${reset}"
      // Checkout configuration repository
      checkout changelog: false, poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']],
      doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'WipeWorkspace']], submoduleCfg: [],
      userRemoteConfigs: [[credentialsId: '	97c54a1a-01f7-44f1-88b8-b88740cd3d1a', url: 'https://gitlab.helios-aws.com/helios/ops/configuration.git']]]
    }
  }

  stage('Install Bundles and Update Databag') {
    withEnv(["PATH=/var/lib/jenkins/.rbenv/shims:/var/lib/jenkins/.rbenv/bin:/var/lib/jenkins/.rbenv/plugins/ruby_build/bin:/usr/local/bin:/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/sbin"]) {
      wrap([$class: 'AnsiColorBuildWrapper']) {
        println "${bold}Install Bundles and Update Databag: ${green}Installing Chef bundles ${reset}"
        sh '''
          set +x
          cd chef-server
          BUNDLE_GEMFILE=Gemfile_for_knife_pipeline bundle install --path /var/lib/jenkins/pipelines-bundle-path
          rbenv rehash
        '''

        // Push databag changes to chef server
        println "${bold}Install Bundles and Update Databag: ${green}Updating the Chef server ${Chef_ENV} Databag with build ${Version_ID}-${BUILD_ID} ${reset}"
        sh '''
          set +x
          cd chef-server
          BUNDLE_GEMFILE=Gemfile_for_knife_pipeline bundle exec knife exec ../helios-pipeline/set_packages_data_bag.rb ${Data_Bag} ${Chef_ENV} ${Version_ID} ${BUILD_ID} || exit 1
        '''

        // Commit and Push "version_id and build_id" change to databag in git configuration repo
        println "${bold}Install Bundles and Update Databag: ${green}Downloading the ${Chef_ENV} Databags changes from Chef server ${reset}"
        sh '''
          set +x
          cd chef
          BUNDLE_GEMFILE=../chef-server/Gemfile_for_knife_pipeline bundle exec knife download data_bags/${Chef_ENV}/${Data_Bag}.json --chef-repo-path .
        '''

        println "${bold}Install Bundles and Update Databag: ${green}Commit and Push Databags changes to configuration repository ${reset}"
        withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: '97c54a1a-01f7-44f1-88b8-b88740cd3d1a',
        usernameVariable: 'GIT_USERNAME', passwordVariable: 'GIT_PASSWORD']]) {
          sh '''
            set +x
            git checkout master
            cd chef
            echo 'Git status is :'
            git status --porcelain
            if [[ `git status --porcelain` ]]; then
              echo 'Pushing data bags changes to master'
              git remote add central https://${GIT_USERNAME}:${GIT_PASSWORD}@gitlab.helios-aws.com/helios/ops/configuration.git
              git config --global user.name "Helios Pipeline"
              git config --global user.email dev.ops@heliosalliance.net
              git add data_bags/${Chef_ENV}/${Data_Bag}.json
              git commit -m "Version bump to ${Version_ID} build ${BUILD_ID} on ${Chef_ENV} ${App_Name} - ${build_user}"
              git pull
              git push origin master
            fi
          '''
        }
      }
    }
  }

  stage('Deploying Code') {
    withEnv(["PATH=/var/lib/jenkins/.rbenv/shims:/var/lib/jenkins/.rbenv/bin:/var/lib/jenkins/.rbenv/plugins/ruby_build/bin:/usr/local/bin:/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/sbin"]) {
      dir('chef-server') {
        wrap([$class: 'AnsiColorBuildWrapper']) {
          // running converge (chef-client) on node through pushy job
          println "${bold}Deploying Code: ${green}Deploying build ${Version_ID}-${BUILD_ID} on ${App_Name} ${reset}"
          sh '#!/bin/sh +x\n' + 'BUNDLE_GEMFILE=Gemfile_for_knife_pipeline bundle exec knife job start chef-client -s "${Chef_Node_Search}"'

          // restarting mule on node through pushy job
          if ( env.App_Name == 'Mule' ) {
            println "${bold}Deploying Code: ${green}Restarting Mule service${reset}"
            sh '#!/bin/sh +x\n' + 'BUNDLE_GEMFILE=Gemfile_for_knife_pipeline bundle exec knife job start restart-mule -s "${Chef_Node_Search}"'
          }
        }
      }
    }
  }

  stage('Smoke Test') {
    withEnv(["PATH=/var/lib/jenkins/.rbenv/shims:/var/lib/jenkins/.rbenv/bin:/var/lib/jenkins/.rbenv/plugins/ruby_build/bin:/usr/local/bin:/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/sbin"]) {
      if ( env.App_Name == 'Mule' ) {
        wrap([$class: 'AnsiColorBuildWrapper']) {
          sleep time: 2, unit: 'MINUTES'
          withCredentials([file(credentialsId: 'd1098693-4514-4e42-b52f-cb97075d3a10', variable: 'SECRET_FILE'),
          string(credentialsId: 'd2931848-5fbb-4a2a-adee-232ebc4524f5', variable: 'SECRET_USER')]) {
            sh '''
              set +x
              nodename=$(knife ssh -a ipaddress -i ${SECRET_FILE} -x ${SECRET_USER} "${Chef_Node_Search}" "hostname")
              data_bag_items=$(knife exec helios-pipeline/get_databag_items.rb ${Chef_ENV} ${Data_Bag} "name")

              echo "\u001B[1m\nSmoke Test:\u001B[32m Checking Apps for version ${Version_ID}-${BUILD_ID} on Mule \u001B[0m"

              echo "\u001B[1m\nSmoke Test:\u001B[32m Node Name: $nodename\u001B[0m"
              while read itemname; do
                output=$(knife ssh -a ipaddress -i ${SECRET_FILE} -x ${SECRET_USER} "${Chef_Node_Search}" "grep -r '${Version_ID}.build-${BUILD_ID}' /opt/mule/apps/$itemname" | cut -d = -f2)

                if ! [[ $output =~ ^${Version_ID}.build-${BUILD_ID} ]]; then
                  echo "\u001B[31m --- $itemname: The Build doesn't match with Version and Build ID --- \u001B[0m"
                  #### exit 1
                else
                  echo "\u001B[32m --- $itemname: The package ${Version_ID} - ${BUILD_ID} has deployed --- \u001B[0m"
                fi
              done <<< "$data_bag_items"
            '''
          }
        }
      }
    }
  }

  // for test
  step([$class: 'WsCleanup'])
  deleteDir()
}
