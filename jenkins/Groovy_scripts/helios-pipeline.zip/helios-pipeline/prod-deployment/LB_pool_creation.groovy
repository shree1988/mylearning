//
// Creates LB pool from a list of nodes
//

properties([
  parameters([
    choice( name: 'load_balancer', choices: 'ih01.apt.heliosrenault.net\nih01.eu.heliosrenault.net\nih01.np.eu.heliosrenault.net\nih01.np.heliosalliance.net\nih01.np.load.heliosrenault.net\nih01.np.use.heliosrenault.net\nih01.use.heliosrenault.net', description: 'Which LB ?'),
    string( name: 'pool', defaultValue: 'sbox-test-pool', description: 'Which new pool name?'),
    text (  name: 'nodes',defaultValue: '1.2.3.4:4502\n5.6.7.8:4502\n', description: 'Which node:port ?\nOne line for each node:port, no blank lines!')
  ])
])

node{

  //******** Configuration ********
  // ANSI color codes
  green='\u001B[32m'
  red='\u001B[31m'
  bold='\u001B[1m'
  reset='\u001B[0m'

  brocade_url_suffix=':9070/api/tm/3.9/'
  brocade_url_suffix_pools=brocade_url_suffix+'config/active/pools/'
  withCredentials([usernameColonPassword(credentialsId: '', variable: 'Brocade_Secrets')]) {
    brocade_credentials = Brocade_Secrets
  }


  // Get names from : http://pipeline.clcm.heliosalliance.net/asynchPeople/
  prod_users = [
    // CAP -- add the list of names who can create the LB pool
  ]

  if ( env.BUILD_NUMBER == '1' ) {
    description = "Job initialisation"
    echo description
    currentBuild.description = description
    currentBuild.result = 'SUCCESS'
    return
  }

  stage('Processing parameters'){
    wrap([$class: 'AnsiColorBuildWrapper']){
      currentBuild.description = "${env.load_balancer} ⇨ ${env.pool}"
      build_userid = get_build_user().getUserId()

      // Only allowing specific users to run the job
      wrap([$class: 'BuildUser']) {
        def user_id = env.BUILD_USER_ID
        if ( ! (user_id in prod_users) ){
          echo "${bold}${red}User ${build_userid} not allowed to run this job${reset}"
          error('')
        }
      }

      if ( params.nodes.trim() == '') {
        echo "${bold}${red}At least one node needed${reset}"
        error('')
      }

      nodes_list = []
      params.nodes.split("\n").each { node ->
        echo "Node : ${node}"
        nodes_list << node
      }
    }
  }

  stage ('Test connectivity'){
    wrap([$class: 'AnsiColorBuildWrapper']){
      test_connectivity = sh (
        script:  '#!/bin/sh +x\n' + "curl --max-time 10 -k -u ${brocade_credentials} https://${env.load_balancer}${brocade_url_suffix} 2>&1 || true",
        returnStdout: true
      ).trim()

      if ( test_connectivity.contains('children') ) {
        echo "Connectivity to ${env.load_balancer} : OK"
      } else {
        if ( test_connectivity.contains('Failed connect') || test_connectivity.contains('Connection timed out')  ) {
          echo "${red}Timeout while trying to connect to ${env.load_balancer}${reset}"
          error('')
        } else if  ( test_connectivity.contains('User name or password was invalid') ) {
          echo "${red}Brocade user has to be created on ${env.load_balancer}${reset}"
          error('')
        } else {
          echo "${red}Unknown error on ${env.load_balancer} : ${test_connectivity}${reset}"
          error('')
        }
      }
    }
  }

  stage ('Check list of pools before'){
    wrap([$class: 'AnsiColorBuildWrapper']){

      before_poolslist_curl = sh (
        script:  '#!/bin/sh +x\n' + "curl -s --fail -k -u ${brocade_credentials} https://${env.load_balancer}${brocade_url_suffix_pools}",
        returnStdout: true
      ).trim()

      before_poolslist_json = readJSON text: before_poolslist_curl

      if ( before_poolslist_json['children'].collect { pool == it['name'] }.contains(true) ) {
        echo "${red}Pool ${env.pool} already exists on ${env.load_balancer}${reset}"
        error('')
      } else {
        echo "${green}${bold}Pool ${env.pool} doesn't exists on ${env.load_balancer}${reset}"
      }
    }
  }

  stage ('Creates pool'){
    wrap([$class: 'AnsiColorBuildWrapper']){


      command ="curl -s --fail -k -u ${brocade_credentials} https://${env.load_balancer}${brocade_url_suffix_pools}${env.pool}/ -X PUT -H 'Content-type: application/json' -d '{\"properties\":{\"basic\":{ \"nodes_table\":["
      nodes_list.each{ node ->
        command += "{\"node\":\"${node}\",\"state\":\"active\"},"
      }
      command = command[0..-2]
      command += "]}}}'"

      creation_curl = sh (
        script:  '#!/bin/sh +x\n' + command,
        returnStdout: true
      ).trim()

    }
  }

  stage ('Check list of pools after'){
    wrap([$class: 'AnsiColorBuildWrapper']){


      after_poolslist_curl = sh (
        script:  '#!/bin/sh +x\n' + "curl -s --fail -k -u ${brocade_credentials} https://${env.load_balancer}${brocade_url_suffix_pools}",
        returnStdout: true
      ).trim()

      after_poolslist_json = readJSON text: after_poolslist_curl

      if ( ! after_poolslist_json['children'].collect { pool == it['name'] }.contains(true) ) {
        echo "${red}Pool ${env.pool} didn't get created on ${env.load_balancer}${reset}"
        error('')
      } else {
        echo "${green}${bold}Pool ${env.pool} has been created on ${env.load_balancer}${reset}"
      }

    }
  }

}
