//
// Change rule state in LB
//

properties([
  parameters([
    choice( name: 'load_balancer', choices: 'ih01.apt.heliosrenault.net\nih01.eu.heliosrenault.net\nih01.np.eu.heliosrenault.net\nih01.np.heliosalliance.net\nih01.np.load.heliosrenault.net\nih01.np.use.heliosrenault.net\nih01.use.heliosrenault.net', defaultValue: 'ih01.np.heliosalliance.net', description: 'Which LB ?'),
    string( name: 'virtual_server', defaultValue: 'aem-author', description: 'Which Virtual Server name?'),
    string( name: 'rule', defaultValue: 'dummy_rule', description: 'Which rule to change?'),
    choice( name: 'status', choices: 'enabled\ndisabled', description: 'Set rule to enabled or disabled')
  ])
])

node{

  //******** Configuration ********
  // ANSI color codes
  green='\u001B[32m'
  red='\u001B[31m'
  bold='\u001B[1m'
  reset='\u001B[0m'


  brocade_url_suffix=':9070/api/tm/3.9/'
  brocade_url_suffix_virtual_servers=brocade_url_suffix+'config/active/virtual_servers/'
  withCredentials([usernameColonPassword(credentialsId: '', variable: 'Brocade_Secrets')]) {
    brocade_credentials = Brocade_Secrets
  }

  // Get names from : http://pipeline.clcm.heliosalliance.net/asynchPeople/
  prod_users = [
    // CAP -- add the list of names who can change the LB rules
  ]

  if ( env.BUILD_NUMBER == '1' ) {
    description = "Job initialisation"
    echo description
    currentBuild.description = description
    currentBuild.result = 'SUCCESS'
    return
  }

  stage ('Processing parameters') {
    wrap([$class: 'AnsiColorBuildWrapper']){
      currentBuild.description = "${env.load_balancer} ⇨ ${env.virtual_server} ${env.rule}=${env.status}"
      build_userid = get_build_user().getUserId()

      // Only allowing specific users to run the job
      wrap([$class: 'BuildUser']) {
        def user_id = env.BUILD_USER_ID
        if ( ! (user_id in prod_users) ){
          echo "${bold}${red}User ${build_userid} not allowed to run this job${reset}"
          error('')
        }
      }
    }
  }

  stage ('Test connectivity') {
    wrap([$class: 'AnsiColorBuildWrapper']){
      test_connectivity = sh (
        script:  '#!/bin/sh +x\n' + "curl --max-time 10 -k -u ${brocade_credentials} https://${env.load_balancer}${brocade_url_suffix} 2>&1 || true",
        returnStdout: true
      ).trim()

      if ( test_connectivity.contains('children') ) {
        echo "Connectivity to ${env.load_balancer} : OK"
      } else {
        if ( test_connectivity.contains('Failed connect') || test_connectivity.contains('Connection timed out')  ) {
          echo "${red}Timeout while trying to connect to ${env.load_balancer}${reset}"
          error('')
        } else if  ( test_connectivity.contains('User name or password was invalid') ) {
          echo "${red}Brocade user has to be created on ${env.load_balancer}${reset}"
          error('')
        } else {
          echo "${red}Unknown error on ${env.load_balancer} : ${test_connectivity}${reset}"
          error('')
        }
      }
    }
  }

  stage ('Check exiting state') {
    wrap([$class: 'AnsiColorBuildWrapper']){

      all_virtual_servers_command = "curl  --fail -k -u ${brocade_credentials} https://${env.load_balancer}${brocade_url_suffix_virtual_servers}"

      all_virtual_servers_curl = sh (
        script:  '#!/bin/sh +x\n' + all_virtual_servers_command,
        returnStdout: true
      ).trim()

      all_virtual_servers_json = readJSON text: all_virtual_servers_curl

      if ( ! all_virtual_servers_json['children'].collect { env.virtual_server == it['name'] }.contains(true) ) {
        echo "${red}${bold}Virtual Server ${env.virtual_server} doesn't exists on ${env.load_balancer}${reset}"
        error('')
      }


      my_virtual_servers_command = "curl  --fail -k -u ${brocade_credentials} https://${env.load_balancer}${brocade_url_suffix_virtual_servers}${env.virtual_server}"

      my_virtual_servers_curl = sh (
        script:  '#!/bin/sh +x\n' + my_virtual_servers_command,
        returnStdout: true
      ).trim()

      my_virtual_servers_json = readJSON text: my_virtual_servers_curl
      pre_update_rules = my_virtual_servers_json['properties']['basic']['request_rules']

      if ( ! ( pre_update_rules.contains(env.rule) || rules.contains('/'+env.rule) ) ) {
        echo "${red}${bold}Rule ${env.rule} isn't in the Virtual Server ${env.virtual_server} on ${env.load_balancer}${reset}"
        error('')
      }

      // echo "${pre_update_rules}"

      if ( env.status == 'enabled' ) {
        if ( pre_update_rules.contains(env.rule) ) {
          echo "${red}${bold}Rule ${env.rule} is already enabled in the Virtual Server ${env.virtual_server} on ${env.load_balancer}${reset}"
          error('')
          } else {
          echo "Rule ${env.rule} will be enabled in the Virtual Server ${env.virtual_server} on ${env.load_balancer}"
          pre_update_rules.set( pre_update_rules.indexOf('/'+env.rule), env.rule );
        }
      }

      if ( env.status == 'disabled' ) {
        if ( pre_update_rules.contains('/'+env.rule) ) {
          echo "${red}${bold}Rule ${env.rule} is already disabled in the Virtual Server ${env.virtual_server} on ${env.load_balancer}${reset}"
          error('')
        } else {
          echo "Rule ${env.rule} will be disabled in the Virtual Server ${env.virtual_server} on ${env.load_balancer}"
          pre_update_rules.set( pre_update_rules.indexOf(env.rule), '/'+env.rule );
        }
      }
    }
  }


  stage ('Updates rules') {
    wrap([$class: 'AnsiColorBuildWrapper']){


      // echo "${pre_update_rules}"

      command = "curl --fail -k -u ${brocade_credentials} https://${env.load_balancer}${brocade_url_suffix_virtual_servers}${env.virtual_server} -X PUT -H 'Content-type: application/json' -d '{\"properties\": {\"basic\":{\"request_rules\":["
      pre_update_rules.each{
        command += "\"${it}\","
      }
      command=command[0..-2]
      command+="]}}}'"

      update_rules_curl = sh (
        script:  '#!/bin/sh +x\n' + command,
        returnStdout: true
      ).trim()

    }

  }

  stage ('Check new state') {
    wrap([$class: 'AnsiColorBuildWrapper']){

      post_update_virtual_servers_curl = sh (
        script:  '#!/bin/sh +x\n' + my_virtual_servers_command,
        returnStdout: true
      ).trim()

      post_update_virtual_servers_json = readJSON text: post_update_virtual_servers_curl
      post_update_rules = post_update_virtual_servers_json['properties']['basic']['request_rules']

      // echo "${post_update_rules}"

      if ( env.status == 'enabled' ) {
        if ( post_update_rules.contains(env.rule) ) {
          echo "${green}${bold}Rule ${env.rule} is now enabled in the Virtual Server ${env.virtual_server} on ${env.load_balancer}${reset}"
        } else {
          echo "${red}${bold}Rule ${env.rule} hasn't been enabled properly in the Virtual Server ${env.virtual_server} on ${env.load_balancer}${reset}"
          error('')
        }
      }

      if ( env.status == 'disabled' ) {
        if ( post_update_rules.contains('/'+env.rule) ) {
          echo "${green}${bold}Rule ${env.rule} is now disabled in the Virtual Server ${env.virtual_server} on ${env.load_balancer}${reset}"
        } else {
          echo "${red}${bold}Rule ${env.rule} hasn't been disabled properly in the Virtual Server ${env.virtual_server} on ${env.load_balancer}${reset}"
          error('')
        }
      }

    }
  }

}
