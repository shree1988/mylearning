//
// Enable or disable all replication queues on prod authors
//

properties([
  parameters([
   choice(choices: 'Production\nStaging', description: 'Which author ?', name: 'site'),
   choice(choices: 'Disable\nEnable', description: 'Disable or Enable all replication queues?', name: 'action')
   ])
])

node{

  //******** Configuration ********
  // ANSI color codes
  green='\u001B[32m'
  red='\u001B[31m'
  bold='\u001B[1m'
  reset='\u001B[0m'
  // Default port of AEM Authors
  server_port='4502'
  // All Authors will use that user to create/upload packages
  aem_username='admin'
  // Chef search string, in order to find the single AEM Author for a specific environment
  author_search='AND ( role:*aem-author* OR role:aem-stack-tarmk* ) NOT role:aem-author-dispatcher*'
  // List of users allowed to pull content from production
  // Get names from : http://pipeline.clcm.heliosalliance.net/asynchPeople/
  prod_users = [
    'omiladi','abhatt'
  ]
  // Any request for a folder starting by that prefix will be blocked
  illegal_folder = '/content/dam'
  // AEM admin password if in Vault
  aem_password_in_vault = 'inVault'
  // Ignoring these queues
  blacklisted_queues_names = [
    ':jcr:created',
    ':jcr:primaryType',
    'jcr:content',
    'jcr:created',
    'jcr:createdBy',
    'jcr:primaryType',
    'author_dispatcher_flush_agent_0', // use a regex ?
    'author_dispatcher_flush_agent_1',
    'author_dispatcher_flush_agent_2',
    'author_dispatcher_flush_agent_3',
    'dynamic_media_replication',
    'flush',
    'offloading_outbox',
    'publish',
    'publish_reverse',
    'static',
    'test_and_target',
    'prod_publish0',
    'prod_publish1',
    'prod_publish2',
    'prod_publish3',
    'prod_publish4',
    'prod_publish5',
    'prod_publish6',
    'prod_publish7',
    'prod_publish8',
    'prod_publish9',
    'prod_publish10',
    'prod_publish11',
    'prod_publish13',
    'dark_publish0'
  ]

  stage('Processing parameters'){
    wrap([$class: 'AnsiColorBuildWrapper']){

      currentBuild.description = "${env.site } ⇨ ${env.action} queues"


      if ( env.site == 'Production' ) {
        environment = 'euw1renprod'
      } else if ( env.site  == 'Staging' ) {
        environment = 'euw1renstg'
      } else {
        echo "Incorrect site ${env.site}"
        error('')
      }
      echo "Environment ${environment} queues will be be set to : ${env.action}"

      // Only allowing specific users to run the job
      wrap([$class: 'BuildUser']) {
        def user_id = env.BUILD_USER_ID
        if ( ! (user_id in prod_users) ){
          echo "${bold}${red}User ${user_id} not allowed to run this job${reset}"
          error('')
        }
      }

      author_ip = get_author_ip(environment)
      aem_password = get_aem_password(environment)

    }
  }

  stage ('Check pre-change queues status '){
    wrap([$class: 'AnsiColorBuildWrapper']){

      // Getting the status of all queues
      curl_out = sh (
        script:  '#!/bin/sh +x\n' + "curl --fail -u ${aem_username}:${aem_password} http://${author_ip}:${server_port}/crx/server/crx.default/jcr%3aroot/etc/replication/agents.author.json",
        returnStdout: true
      ).trim()
      prechange_queues_states = readJSON text: curl_out

      // Array with only the names of all queues
      all_queues_names = prechange_queues_states.keySet()


      // Array with only the names of useful queues, not the ones in the blacklist
      useful_queues_names = []
      all_queues_names.each {
        if ( ! ( it in blacklisted_queues_names )  ) {
          useful_queues_names.push(it)
        }
      }

      // Checking if these queues state are disabled before we enabled them, and the other way around
      useful_queues_names.each{
        _status_enabled = prechange_queues_states[it].'jcr:content'.'enabled'
        if ( env.action == 'Enable' && _status_enabled == 'true' ) {
          echo "${bold}Queue ${it} can't be enabled as it's already set to ${red}${_status_enabled}${reset}"
          error('')
        }
        if ( env.action == 'Disable' && _status_enabled == 'false' ) {
          echo "${bold}Queue ${it} can't be disabled as it's already set to ${red}${_status_enabled}${reset}"
          error('')
        }
        echo "${bold}${it} enabled status is : ${green}${_status_enabled}${reset}"
      }
    }
  }

  stage ('Change queues status '){
    wrap([$class: 'AnsiColorBuildWrapper']){
      useful_queues_names.each{
        echo "${it} to set to : ${env.action}"
        if ( env.action == 'Enable' ) {
          desired_status = 'true'
        }
        if ( env.action == 'Disable' ) {
          desired_status = 'false'
        }

        // Curl command to change the queue status
        switch_status_output = sh (
          script:  '#!/bin/sh +x\n' + "curl --fail -F'enabled=${desired_status}' -u ${aem_username}:${aem_password} http://${author_ip}:${server_port}/etc/replication/agents.author/${it}/jcr:content",
          returnStdout: true
        ).trim()

        // Checking the output of the curl command for 'Content modified', indicating a success
        if ( switch_status_output.contains('Content modified') ) {
          echo "${bold}Setting queue ${it} to enabled=${desired_status} ${green}worked${reset}"
        } else {
          echo "${bold}${red}Setting queue ${it} to enabled=${desired_status} failed${reset}"
          error('')
        }
      }
    }
  }

  stage ('Check post-change queues status '){
    wrap([$class: 'AnsiColorBuildWrapper']){

      // Getting the status of all queues
      curl_out = sh (
        script:  '#!/bin/sh +x\n' + "curl --fail -u ${aem_username}:${aem_password} http://${author_ip}:${server_port}/crx/server/crx.default/jcr%3aroot/etc/replication/agents.author.json",
        returnStdout: true
      ).trim()
      postchange_queues_states = readJSON text: curl_out

      // Reusing the previous array with the names of useful queues, found in the pre-change step
      useful_queues_names.each{
        _status_enabled = postchange_queues_states[it].'jcr:content'.'enabled'
        if ( env.action == 'Enable' && _status_enabled != 'true' ) {
          echo "${bold}${red}Queue ${it} didn't get enabled${reset}"
          error('')
        } else if ( env.action == 'Enable' && _status_enabled == 'true' ){
          echo "${bold}Queue ${it} has been ${green}enabled${reset}"
        }
        if ( env.action == 'Disable' && _status_enabled != 'false' ) {
          echo "${bold}${red}Queue ${it} didn't get disabled${reset}"
          error('')
        } else if ( env.action == 'Disable' && _status_enabled == 'false' ){
          echo "${bold}Queue ${it} has been ${green}disabled${reset}"
        }
      }
    }
  }
}


// Methods

def get_author_ip(environment){
  author_ip = sh (
    script: '#!/bin/sh +x\n' + "knife search 'chef_environment:${environment} ${author_search}' -F json -a ipaddress|grep ipaddress|sed 's/.*ipaddress\": \"//'|sed 's/\"//'",
    returnStdout: true
  ).trim()
  if ( author_ip == '' ){
    echo "${bold}${red}AEM Author IP for ${environment} can't be found${reset}"
    error('')
  } else if ( ! author_ip.matches("\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}") ) {
    echo "${bold}AEM Author IP for ${environment} is incorrect : ${red}${author_ip}${reset}"
    error('')
  } else {
    echo "${bold}AEM Author IP for ${environment} : ${green}${author_ip}${reset}"
    author_ip
  }
}

def get_aem_password(environment){
  aem_credentials = sh (
    script: '#!/bin/sh +x\n' + "knife data bag show ${environment} aem_credentials -F json",
    returnStdout: true
  ).trim()

  json_object = readJSON text: aem_credentials
  aem_password = json_object.admin.password

  if ( aem_password == 'null' ) {
    echo "${bold}${red}AEM password not found${reset}"
    error('')
  }
  aem_password
}
