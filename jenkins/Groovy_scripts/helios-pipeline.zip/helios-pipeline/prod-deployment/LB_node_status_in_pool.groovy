//
// Enable or disable all nodes in a LB Pool
//

properties([
  parameters([
    choice( name: 'load_balancer', choices: 'ih01.apt.heliosrenault.net\nih01.eu.heliosrenault.net\nih01.np.eu.heliosrenault.net\nih01.np.heliosalliance.net\nih01.np.load.heliosrenault.net\nih01.np.use.heliosrenault.net\nih01.use.heliosrenault.net', description: 'Which LB ?'),
    string( name: 'pool', defaultValue: 'sbox-ti-tar-auth', description: 'Which pool?'),
    choice( name: 'status', choices: 'active\ndisabled', description: 'Set nodes to active or disabled')
  ])
])

node{

  //******** Configuration ********
  // ANSI color codes
  green='\u001B[32m'
  red='\u001B[31m'
  bold='\u001B[1m'
  reset='\u001B[0m'

  brocade_url_suffix=':9070/api/tm/3.9/'
  brocade_url_suffix_pools=brocade_url_suffix+'config/active/pools/'
  withCredentials([usernameColonPassword(credentialsId: '', variable: 'Brocade_Secrets')]) {
    brocade_credentials = Brocade_Secrets
  }


  // Get names from : http://pipeline.clcm.heliosalliance.net/asynchPeople/
  prod_users = [
      // CAP -- add the list of names who can check the node status in LB
  ]

  if ( env.BUILD_NUMBER == '1' ) {
    description = "Job initialisation"
    echo description
    currentBuild.description = description
    currentBuild.result = 'SUCCESS'
    return
  }

  stage('Processing parameters'){
    wrap([$class: 'AnsiColorBuildWrapper']){
      currentBuild.description = "${env.load_balancer} : ${env.pool} ⇨ ${env.status}"
      build_userid = get_build_user().getUserId()

      // Only allowing specific users to run the job
      wrap([$class: 'BuildUser']) {
        def user_id = env.BUILD_USER_ID
        if ( ! (user_id in prod_users) ){
          echo "${bold}${red}User ${build_userid} not allowed to run this job${reset}"
          error('')
        }
      }
    }
  }

  stage ('Test connectivity'){
    wrap([$class: 'AnsiColorBuildWrapper']){
      test_connectivity = sh (
        script:  '#!/bin/sh +x\n' + "curl --max-time 10 -k -u ${brocade_credentials} https://${env.load_balancer}${brocade_url_suffix} 2>&1 || true",
        returnStdout: true
      ).trim()

      if ( test_connectivity.contains('children') ) {
        echo "Connectivity to ${env.load_balancer} : OK"
      } else {
        if ( test_connectivity.contains('Failed connect') || test_connectivity.contains('Connection timed out')  ) {
          echo "${red}Timeout while trying to connect to ${env.load_balancer}${reset}"
          error('')
        } else if  ( test_connectivity.contains('User name or password was invalid') ) {
          echo "${red}Brocade user has to be created on ${env.load_balancer}${reset}"
          error('')
        } else {
          echo "${red}Unknown error on ${env.load_balancer} : ${test_connectivity}${reset}"
          error('')
        }
      }
    }
  }

  stage ('Check list of pools'){
    wrap([$class: 'AnsiColorBuildWrapper']){

      poolslist_curl = sh (
        script:  '#!/bin/sh +x\n' + "curl -s --fail -k -u ${brocade_credentials} https://${env.load_balancer}${brocade_url_suffix_pools}",
        returnStdout: true
      ).trim()

      poolslist_json = readJSON text: poolslist_curl

      if ( ! poolslist_json['children'].collect { pool == it['name'] }.contains(true) ) {
        echo "${red}Pool ${env.pool} not found on ${env.load_balancer}${reset}"
        error('')
      }
    }
  }


  stage ('Check pool status'){
    wrap([$class: 'AnsiColorBuildWrapper']){

      before_curl = sh (
        script:  '#!/bin/sh +x\n' + "curl -s --fail -k -u ${brocade_credentials} https://${env.load_balancer}${brocade_url_suffix_pools}${env.pool}/",
        returnStdout: true
      ).trim()

      before_json = readJSON text: before_curl

      echo "${bold}Pool ${env.pool} before update :${reset}"
      before_json['properties']['basic']['nodes_table'].each{
        echo "${bold}${it['node']} : ${it['state']}${reset}"
      }

    }
  }

  stage ('Change pool status '){
    wrap([$class: 'AnsiColorBuildWrapper']){

      number_of_nodes = before_json['properties']['basic']['nodes_table'].size

      echo "Number of nodes in the pool = ${number_of_nodes}"

      for (i = 0; i < number_of_nodes; i++) {
        before_json['properties']['basic']['nodes_table'][i]['state'] = env.status
      }

      state_json_nodes_table = JsonOutput.toJson(before_json['properties']['basic']['nodes_table'])

      update_command = "curl -s --fail -k -u ${brocade_credentials} https://${env.load_balancer}${brocade_url_suffix_pools}${env.pool}/ -X PUT -H 'Content-type: application/json' -d '{\"properties\": {\"basic\":{\"nodes_table\":${state_json_nodes_table} }}}'"

      update_pool_curl = sh (
        script:  '#!/bin/sh +x\n' + "${update_command}",
        returnStdout: true
      ).trim()

    }
  }

  stage ('Check pool status again'){
    wrap([$class: 'AnsiColorBuildWrapper']){

      after_curl = sh (
        script:  '#!/bin/sh +x\n' + "curl -s --fail -k -u ${brocade_credentials} https://${env.load_balancer}${brocade_url_suffix_pools}${env.pool}/",
        returnStdout: true
      ).trim()

      after_json = readJSON text: after_curl

      echo "${bold}Pool ${env.pool} after update :${reset}"
      after_json['properties']['basic']['nodes_table'].each{
        echo "${bold}${it['node']} : ${it['state']}${reset}"
        if ( it['state'] != env.status ) {
          echo "${red}Pool ${env.pool} in state ${it['state']} while we expect it to be ${env.state}${reset}"
          error('')
        }
      }
    }
  }
}
