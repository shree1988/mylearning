/**
 * Groovy Script for an Apigee Synchronization Job
 *
 * Syncs one environment's Apigee configuration usign another environment as
 * a baseline. Usually meant to synchronize UAT configuration to lower
 * environments.
 *
 * @author Sergio Bobillier C.
 *
 */

// Groovy class required to parse JSON objects
import groovy.json.*

// Source Control Information for each of the Apigee Organisations and
// Environments.

scm_data = [
  'digitaslbi-uat': [
    'repository': 'https://stash.lbi.co.uk/scm/heac/e2e.git',
    'renault-repository': 'https://stash.lbi.co.uk/scm/ren-heac/e2e.git',
    'path': 'deployment/src/main/apiproxy/digitaslbi-uat',
    'environments': ['hotfix-nissan', 'hotfix-renault', 'int-nna',
                     'stage-nissan', 'stage-renault',
                     'uat-renault', 'uat2-nissan']
  ],
  'digitaslbi-nonprod': [
    'repository': 'https://stash.lbi.co.uk/scm/hel/application.git',
    'path': 'helios-parent/helios-apigee/deployment/src/main/apiproxy/digitaslbi-nonprod',
    'environments': ['appsupport', 'dev', 'optimisation', 'qa', 'stream2-dev',
                     'stream2-qa', 'stream2-uat', 'stream5-dev', 'stream5-qa',
                     'stream5-uat', 'stream6-dev', 'stream6-qa', 'stream6-uat',
                     'stream8-dev', 'stream8-qa', 'stream8-uat', 'stream10-dev',
                     'stream10-qa', 'stream10-uat', 'stream12-dev',
                     'stream12-qa', 'stream12-uat', 'stream19-dev',
                     'stream19-qa', 'stream19-uat', 'stream20-dev',
                     'stream20-qa', 'stream20-uat', 'stream22-dev',
                     'stream22-qa', 'stream22-uat', 'stream23-dev',
                     'stream23-qa', 'stream23-uat', 'stream24-dev',
                     'stream24-qa', 'stream24-uat', 'stream25-dev',
                     'stream25-qa', 'stream25-uat', 'TI']
  ],
  'helios-renault-nonprod': [
    'repository': 'https://stash.lbi.co.uk/scm/ren-hel/application.git',
    'path': 'helios-parent/helios-apigee/deployment/src/main/apiproxy/helios-renault-nonprod',
    'environments': ['stream1-dev', 'stream1-qa', 'stream1-uat', 'stream13-dev',
                     'stream13-qa', 'stream13-uat', 'stream16-dev',
                     'stream16-qa', 'stream16-uat']
 ]
]

replacement_data = [
  'digitaslbi-uat': [
    'hotfix-nissan': [
      'folder-prefix': 'hotfix',
      'settings-env': 'hotfix-nissan',
      'app-name': 'HOTFIX V2',
      'client-name': 'HOTFIX'
    ],
    'hotfix-renault': [
      'folder-prefix': 'hotfix',
      'settings-env': 'hotfix-renault',
      'app-name': 'HOTFIX V2',
      'client-name': 'HOTFIX'
    ],
    'int-nna': [
      'folder-prefix': 'int-nna',
      'settings-env': 'int-nna-nissan',
      'app-name': 'INT - NNA V2',
      'client-name': 'INT-NNA'
    ],
    'stage-nissan': [
      'folder-prefix': 'stage',
      'settings-env': 'stage-nissan',
      'app-name': 'STAGE V2',
      'client-name': 'STAGE'
    ],
    'stage-renault': [
      'folder-prefix': 'stage',
      'settings-env': 'stage-renault',
      'app-name': 'STAGE V2',
      'client-name': 'STAGE'
    ],
    'uat-renault': [
      'folder-prefix': 'uat',
      'settings-env': 'uat-renault',
      'app-name': 'UAT',
      'client-name': 'UAT'
    ],
    'uat2-nissan': [
      'folder-prefix': 'uat2',
      'settings-env': 'uat2-nissan',
      'app-name': 'UAT2',
      'client-name': 'UAT2',
      'env-alias': 'use1nisuat-2'
    ]
  ]
]

uat_choices = scm_data['digitaslbi-uat']['environments'].join('\n')
low_choices = (scm_data['digitaslbi-nonprod']['environments'] + scm_data['helios-renault-nonprod']['environments']).join('\n')

properties([
  parameters([
    choice(name: 'source_org', description: 'Source Apigee Organisation', choices: 'digitaslbi-uat'),
    choice(name: 'source_env', description: 'Source Apigee Environment', choices: uat_choices),
    choice(name: 'target_org', description: 'Target Apigee Organisation', choices: 'digitaslbi-nonprod\nhelios-renault-nonprod'),
    choice(name: 'target_env', description: 'Target Apigee Environment', choices: low_choices),
    string(name: 'target_branch', description: 'Stash/git branch to cut the sync branch from', defaultValue: 'master'),
    string(name: 'tomcat_host', description: 'Tomcat host to use (leave blank to use the defalt for the target environment)', defaultValue: '')
  ])
])

//******** Configuration ********

// ANSI color codes
green='\u001B[32m'
yellow='\u001B[33m'
bold='\u001B[1m'
reset='\u001B[0m'

source_path = "source_repo/${scm_data[source_org]['path']}/${source_env}"
target_path = "target_repo/${scm_data[target_org]['path']}/${target_env}"

// These files will be checked out on the target repository at the end of the
// run. These are the files that exist on the target environment but not on
// the source.

to_checkout = []

// We need to be aware of the brand so that we can apply exceptions or
// replacements which are brand-dependent.

brand = 'nissan'

// Depending on the target environment the Developer Apps' names are upper or
// lower case we should try to keep whatever convention the target environment
// has to avoid causing issues on deployment.

uppercase_name = false

node {

  currentBuild.description = "${source_env} ⇨ ${target_env}"

  // Wipe the workspace to avoid having changes from other runs mixed in.
  deleteDir()

  stage('Clone repositories') {

    if(source_env.endsWith('-renault')) {
      source_repository = scm_data[source_org]['renault-repository']
      brand = 'renault'
    }
    else {
      source_repository = scm_data[source_org]['repository']
    }

    checkout([$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false,
      extensions: [[$class: 'CloneOption', depth: 0, honorRefspec: true, noTags: true, reference: ''],
      [$class: 'RelativeTargetDirectory', relativeTargetDir: 'source_repo']], submoduleCfg: [], userRemoteConfigs:
      [[credentialsId: '', refspec: '+refs/heads/master:refs/remotes/origin/master',
      url: source_repository]]])

    checkout([$class: 'GitSCM', branches: [[name: "*/${target_branch}"]], doGenerateSubmoduleConfigurations: false,
      extensions: [[$class: 'CloneOption', depth: 0, honorRefspec: true, noTags: true, reference: ''],
      [$class: 'RelativeTargetDirectory', relativeTargetDir: 'target_repo']], submoduleCfg: [], userRemoteConfigs:
      [[credentialsId: '',
      refspec: "+refs/heads/${target_branch}:refs/remotes/origin/${target_branch}",
      url: scm_data[target_org]['repository']]]])
  }

  stage('Check repositories') {
    if(!fileExists(source_path))
      error "The source organisation / environment: '${source_org}/${source_env}' does not exists."

    if(!fileExists(target_path))
      error "The target organisation / environment: '${target_org}/${target_env}' does not exists in the specified branch: '${target_branch}'"
  }

  stage('Gather required informatiom') {
    output = sh(
      script: """#!/bin/sh +x
        ls -1 '${target_path}'""",
      returnStdout: true
    )
    length = target_env.length()
    items = output.split('\n')

    sec_idp_config_list           = [:]
    os_nna_wso2_conf_list         = [:]
    payment_estimator_url_list    = [:]
    lm_nna_esb_leads_config_list  = [:]
    mock_attibutes_list           = [:]

    markets_list = []

    items.each { item ->
      if(item == 'products')
        return

      output = sh(
        script: """#!/bin/sh +x
          ls -1 '${target_path}/${item}'""",
        returnStdout: true
      )

      markets = output.split('\n')

      markets.each { market ->
        market_path = "${item}/${market}"

        path_to_find = "${target_path}/${market_path}"

        target_sec_idp_config = find_and_extract(path_to_find, 'sec_idp_config', false)
        if (target_sec_idp_config != null)
          target_sec_idp_config = target_sec_idp_config.replace('"', '\\"')
        sec_idp_config_list[path_to_find] = target_sec_idp_config

        target_os_nna_wso2_conf = find_and_extract(path_to_find, 'os_nna_wso2_conf', false)
        if (target_os_nna_wso2_conf != null)
          target_os_nna_wso2_conf = target_os_nna_wso2_conf.replace('"', '\\"')
        os_nna_wso2_conf_list[path_to_find] = target_os_nna_wso2_conf

        target_payment_estimator_url = find_and_extract(path_to_find, 'payment_estimator_url', false)
        payment_estimator_url_list[path_to_find] = target_payment_estimator_url

        target_lm_nna_esb_leads_config = find_and_extract(path_to_find, 'lm_nna-esb-leads_config', false)
        if (target_lm_nna_esb_leads_config != null)
          target_lm_nna_esb_leads_config = target_lm_nna_esb_leads_config.replace('"', '\\"')
        lm_nna_esb_leads_config_list[path_to_find] = target_lm_nna_esb_leads_config

        mocks = find_and_extract_all_ocurrences_of_a_key(path_to_find, "mock")
        mock_attibutes_list[path_to_find] = mocks

        if(item =~ /(?i)mocks/ || market =~ /(?i)mocks/) {
          to_checkout << market_path
        }
        else {
          markets_list << market_path
        }
      }
    }

    // Gather the information that will need to be restored once the
    // configuration is copiedover from the source environment.

    source_services_password = find_and_extract(source_path, 'services_password')
    target_services_password = find_and_extract(target_path, 'services_password')
    source_services_username = find_and_extract(source_path, 'services_username')
    target_services_username = find_and_extract(target_path, 'services_username')

    // If 'environment' is not found, we may be able to use elasticsearchEnv as
    // a fallback (not as reliable, but works).

    source_environment = find_and_extract(source_path, 'environment', false)

    if(source_environment == null)
      source_environment = find_and_extract(source_path, 'elasticsearchEnv')

    target_environment = find_and_extract(target_path, 'environment', false)

    if(target_environment == null)
      target_environment = find_and_extract(target_path, 'elasticsearchEnv')

    // Gether the S3 settings for the target environment (this only applies for
    // Nissan environments)

    if(brand == 'nissan') {
      s3_settings = find_and_extract(target_path, 'lm_hr_muleEndpointConfig')
      s3_settings_obj = readJSON text: s3_settings
      bucket_name = s3_settings_obj.bucketName
      access_key = s3_settings_obj.accessKey
      secret_key = s3_settings_obj.secretKey
    }

    output = sh(
      script: """#!/bin/sh +x
        find '${target_path}' -name 'name.props' -print0 | xargs -0 fgrep -m 1 'name=' | head -n 1""",
      returnStdout: true
    ).trim()

    def matches = (output =~ /name=(.*?)-/)

    if(matches.find()) {
      def name = matches[0][1]
      if(name == name.toUpperCase())
        uppercase_name = true
    }
  }

  stage('Create target branch') {
    branch_name = "apigee-sync-${source_env}-to-${target_env}-${env.BUILD_ID}"

    sh(
      script: """#!/bin/sh +x
        pushd target_repo
        git checkout -b ${branch_name}
        popd
        """
    )
  }

  stage('Delete current configuration') {
    sh("rm -rf '${target_path}'")
    sh("mkdir '${target_path}'")
  }

  stage("Copy over the source configuration") {
    items.each { item ->
      if(item == 'products') {
        sh("cp -r '${source_path}/${item}' '${target_path}/${item}'")
      }
      else {
        sh "mkdir '${target_path}/${item}'"
      }
    }

    markets_list.each { market ->
      status = sh (
        script: """#!/bin/sh +x
        cp -r '${source_path}/${market.replace(target_env, replacement_data[source_org][source_env]['folder-prefix'])}' '${target_path}/${market}'""",
        returnStatus: true
      )

      if(status != 0)
        to_checkout << market
    }
  }

  stage('Perform string replacement') {
    // Find all the settings.props files

    output = sh(
      script: """#!/bin/sh +x
        find '${target_path}' -name 'settings.props'""",
      returnStdout: true
    )

    files = output.split('\n')

    // Perform replacement

    files.each { file ->
      file_name = "${WORKSPACE}/${file}"
      contents = handle.text
      contents = contents.replace(replacement_data[source_org][source_env]['settings-env'], target_env)  // uat2-nissan -> stream13-qa
      writeFile file: file_name, text: contents
    }

    // Find all the name.props files

    output = sh(
      script: """#!/bin/bash +x
        find '${target_path}' -name 'name.props'""",
      returnStdout: true
    )

    files = output.split('\n')

    // Perform replacement

    files.each { file ->
      handle = new File("${WORKSPACE}/${file}")
      contents = handle.text
      contents = contents.replace(replacement_data[source_org][source_env]['settings-env'], target_env)  // uat2-nissan -> stream13-qa

      parts = target_env.split("-")

      source_app_name = "V2 ${replacement_data[source_org][source_env]['app-name']}"

      if(parts.length > 1) {
        target_app_name = "V2 ${parts[0].capitalize()} - ${parts[1].toUpperCase()}"
      }
      else {
        target_app_name = "V2 ${parts[0].toUpperCase()}"
      }

      if(uppercase_name) target_app_name = target_app_name.toUpperCase()
      contents = contents.replace(source_app_name, target_app_name)  // V2 UAT -> V2 Stream13 - QA

      source_app_name = "${replacement_data[source_org][source_env]['app-name']} V2"

      if(parts.length > 1) {
        target_app_name = "${parts[0].capitalize()} - ${parts[1].toUpperCase()} V2"
      }
      else {
        target_app_name = "${parts[0].toUpperCase()} V2"
      }

      if(uppercase_name) target_app_name = target_app_name.toUpperCase()
      contents = contents.replace(source_app_name, target_app_name)  // UAT V2 -> Stream13 - QA V2

      replacement = target_env.replace('-', '')
      if(uppercase_name) replacement = replacement.toUpperCase()
      contents = contents.replace("${replacement_data[source_org][source_env]['client-name']}-", "${replacement}-")  // UAT-DatsunLive-id_ID-AEM -> stream13qa-DatsunLive-id_ID-AEM

      contents = contents.replaceAll(/${replacement_data[source_org][source_env]['folder-prefix']}(.*?)@helios\.v2\.com/, target_env + '$1@helios.v2.com')  // uat.Client.renault@helios.v2.com -> stream13-qa.Client.renault@helios.v2.com
      handle.write(contents)
    }

    // Find all the attributes.json files

    output = sh(
      script: """#!/bin/sh +x
        find '${target_path}' -name 'attributes.json'""",
      returnStdout: true
    )

    files = output.split('\n')

    // Perform replacement

    files.each { file ->
      handle = new File("${WORKSPACE}/${file}")
      contents = handle.text

      replacement = target_env.replace('-', '')
      if(uppercase_name) replacement = replacement.toUpperCase()
      contents = contents.replace("**replace:${replacement_data[source_org][source_env]['app-name']}", "**replace:${replacement}")  // **replace:UAT-DaciaLive-en_IE-AEM -> **replace:stream1dev-DaciaLive-en_IE-AEM

      env_type = 'uat'
      target_app_name = target_env
      parts = target_env.split("-")

      if(parts.length > 1) {
        target_app_name = "${parts[0].capitalize()} - ${parts[1].toUpperCase()} -"
        env_url = "${parts[0].toLowerCase()}.${parts[1].toLowerCase()}"
        env_type = parts[1].toLowerCase()
      }
      else {
        target_app_name = "${parts[0].toUpperCase()} -"
        env_url = "${parts[0].toLowerCase()}"
        env_type = parts[0].toLowerCase()
      }

      if(uppercase_name) target_app_name = target_app_name.toUpperCase()
      source_app_name = "${replacement_data[source_org][source_env]['app-name']} -"
      contents = contents.replace(source_app_name, target_app_name)  // UAT - V2 - Dacia - Algeria - Arabic - AEM -> Stream13 - QA - V2 - Dacia - Algeria - Arabic - AEM

      contents = contents.replace("${source_org}-${source_env}", "${target_org}-${target_env}")  // digitaslbi-uat-uat-renault.apigee.net -> helios-renault-nonprod-stream13-qa.apigee.net
      contents = contents.replaceAll(/${replacement_data[source_org][source_env]['folder-prefix']}(.*?)@helios\.v2\.com/, target_env + '$1@helios.v2.com')  // uat.dacia@helios.v2.com -> stream13-qa.dacia@helios.v2.com

      replacement = tomcat_host ? tomcat_host : target_env.replace('-', '.')
      contents = contents.replaceAll(/https?:\/\/api(-.*?)?\..*?\.net/, "https://api.${replacement}.heliosalliance.net")  // https://api.stg.heliosrenault.net -> https://api.stream13.qa.heliosalliance.net

      contents = contents.replaceAll(/apigee.*?\.${replacement_data[source_org][source_env]['folder-prefix']}\.helios.*?\.net/, "${target_org}-${target_env}.apigee.net") // apigee-eu.uat.heliosrenault.net -> helios-renault-nonprod-stream13-uat.apigee.net
      contents = contents.replaceAll(/(https:\/\/\w{2}-\w{2}(\.(dark|ltr))?)\..*?(\.helios(nissan|infiniti|datsun|renault|dacia)\.net)/, '$1.' + env_url + '$4')  // https://en-in.dark.uat2.heliosdatsun.net -> https://en-in.dark.stream23.qa.heliosdatsun.net
      contents = contents.replaceAll(/(https:\/\/author.).*?\.net/, "https://author.${env_url}.heliosalliance.net")  // https://author.uat2.heliosdatsun.net -> https://author.stream13.qa.heliosdatsun.net
      contents = contents.replaceAll(/prod\.(.*?)\/tools/, 'pre-prod.$1/tools')  // http://uk.prod.nissan.eu/GB/en/tools/brochures.-Par-24819-brochureconfirmationxml.xml -> http://uk.pre-prod.nissan.eu/GB/en/tools/brochures.-Par-24819-brochureconfirmationxml.xml

      // For Nissan US markets, the elastic search index name must use apigee
      // environment name, not mule env name as prefix.

      if(brand == 'nissan' && (file =~ /(?i)united\s*states/).find()) {
        replacement = target_env  // nisuat_inventory_nissan_us_zh_vn -> stream13-qa_inventory_nissan_us_zh_vn
      }
      else {
        replacement = target_environment  // nisuat_inventory_nissan_us_zh_vn -> use1qa-stream13_inventory_nissan_us_zh_vn
      }

      contents = contents.replaceAll($/value"\s*:\s*"(.*?)_inventory_(.*?)"/$, "value\": \"${replacement}" + '_inventory_$2"')

      // If the target environment has an environment alias then replace that
      // one as well. Normally this shouldn't be necessary but....

      env_alias = replacement_data[source_org][source_env]['env-alias']
      if(env_alias) contents = contents.replace(env_alias, target_environment)

      // Restore the original attributes.

      contents = contents.replace(source_services_password, target_services_password)
      contents = contents.replace(source_services_username, target_services_username)
      contents = contents.replace(source_environment, target_environment)

      current_brand = guess_current_brand(file)

      target_email_address = "${target_env.toLowerCase()}.failedleads@test.heliosalliance.net"
      source_email_address = /(.*?)${replacement_data[source_org][source_env]['folder-prefix']}\.failedleads@test\.heliosalliance\.net/
      contents = contents.replaceAll(source_email_address, '$1' + target_email_address)  // nissan.uat.failedleads@test.heliosalliance.net -> nissan.stream13.qa.failedleads@test.heliosalliance.net

      target_email_address = "${current_brand}."  + target_email_address
      contents = contents.replace("${replacement_data[source_org][source_env]['folder-prefix']}@test.heliosalliance.net", target_email_address)  // uat@test.heliosalliance.net -> infiniti.qa.failedleads@test.heliosalliance.net
      contents = contents.replace('noreply@heliosalliance.net', target_email_address)  // noreply@heliosalliance.net -> infiniti.qa.failedleads@test.heliosalliance.net

      // S3 Settings (only for Nissan environments)

      if(brand == 'nissan') {
        source_string = $/bucketName\\"\s*:\s*\\".*?\\/$
        target_string = "bucketName\\\\\": \\\\\"${bucket_name}\\\\"
        contents = contents.replaceAll(source_string, target_string)

        source_string = $/accessKey\\"\s*:\s*\\".*?\\/$
        target_string = "accessKey\\\\\": \\\\\"${access_key}\\\\"
        contents = contents.replaceAll(source_string, target_string)

        source_string = $/secretKey\\"\s*:\s*\\".*?\\/$
        target_string = "secretKey\\\\\": \\\\\"${secret_key}\\\\"
        contents = contents.replaceAll(source_string, target_string)
      }

      // The following code parses escaped unicode characters on the input to
      // their corresponding characters, for example \u003d turns into =

      def matches = (contents =~ /\\u[\da-f]{4}/)  // Find all the escaped chars

      if(matches.find()) {
        for(i = 0; i < matches.size(); i++) {
          charcode = Integer.parseInt(matches[i].substring(2), 16)
          contents = contents.replace(matches[i], (String)(char)charcode)
        }
      }

      handle.write(contents)
    }

    files.each { file ->
      handle = new File("${WORKSPACE}/${file}")
      contents = handle.text

      source_sec_idp_config           = find_and_extract(file, 'sec_idp_config', false)
      source_os_nna_wso2_conf         = find_and_extract(file, 'os_nna_wso2_conf', false)
      source_payment_estimator_url    = find_and_extract(file, 'payment_estimator_url', false)
      source_lm_nna_esb_leads_config  = find_and_extract(file, 'lm_nna-esb-leads_config', false)

      file = file.replace("/attributes.json", "")

      if(sec_idp_config_list[file] != null){
        if(source_sec_idp_config != null){
          source_sec_idp_config = source_sec_idp_config.replace('"', '\\"')
          contents = contents.replace(source_sec_idp_config, sec_idp_config_list[file])
        }
      }

      if(os_nna_wso2_conf_list[file] != null){
        if(source_os_nna_wso2_conf != null){
          source_os_nna_wso2_conf = source_os_nna_wso2_conf.replace('"', '\\"')
          assert source_os_nna_wso2_conf
          contents = contents.replace(source_os_nna_wso2_conf, os_nna_wso2_conf_list[file])
        }
      }

      if(payment_estimator_url_list[file] != null){
        if(source_payment_estimator_url != null){
          contents = contents.replace(source_payment_estimator_url, payment_estimator_url_list[file])
        }
      }

      if(lm_nna_esb_leads_config_list[file] != null){
        if(source_lm_nna_esb_leads_config != null){
          source_lm_nna_esb_leads_config = source_lm_nna_esb_leads_config.replace('"', '\\"')
          contents = contents.replace(source_lm_nna_esb_leads_config, lm_nna_esb_leads_config_list[file])
        }
      }

      mock_attibutes_list[file].each { mocks ->
        mock_attribute = null
        mock_attribute = find_and_extract(file, mocks['name'], false)
        if (mock_attribute == null){
          replacement = '"attributes": ['
          replacement = replacement + "\n"
          replacement = replacement + "\t\t{\n"
          replacement = replacement + '\t\t"name": '
          replacement = replacement + '"' + mocks['name'] + '"'
          replacement = replacement + ',\n'
          replacement = replacement + '\t\t"value": '
          replacement = replacement + '"' + mocks['value'] + '"'
          replacement = replacement + '\n'
          replacement = replacement + '\t\t},'
          contents = contents.replace('"attributes": [', replacement)
        } else {
          contents = contents.replace(mock_attribute, mocks['value'])
        }

      }

      handle.write(contents)
    }

  }

  stage('Commit changes and push the branch') {

    // Before commit check-out the deleted files to restore them.

    dir(target_path) {
      to_checkout.each { item ->
        sh("""#!/bin/sh +x
          git checkout '${item}'""")
      }
    }

    sh(
      script: """#!/bin/sh +x
        set -e
        git config --global user.name "Helios Pipeline"
        git config --global user.email dev.ops@heliosalliance.net
        pushd target_repo
        git add .
        git commit -m 'Apigee configuration sync from ${source_env} to ${target_env}'
        git push origin ${branch_name}
        popd"""
    )
  }

  step([$class: 'WsCleanup'])
  deleteDir()
}

///////////////////////////// Utility Methods //////////////////////////////////

/** Finds the specified attribute within the attribute.json files in the given
 *  path and extracts its value. If the attribute is not found an error will be
 *  raised
 *
 *  @param from_path The file where the attribute should be looked up.
 *  @param attribute The attribute to look for.
 *  @param raise_error If true the function will raise an error if the specified
 *    attribute is not found in the given path. If false the function will
 *    return null without raising an error. Default is true.
 *  @return The value of the specified attribute.
 *
 */

def find_and_extract(from_path, attribute, raise_error = true) {
  output = sh(
    script: """#!/bin/sh +x
      find '${from_path}' -name 'attributes.json' -print0 | xargs -0 fgrep -l -m 1 '${attribute}' | head -n 1""",
    returnStdout: true
  ).trim()

  if(output == "") {
    if(raise_error)
      error "'${attribute}' was not found on '${from_path}'"

    return null
  }

  attribute_value = null

  handle = new File("${WORKSPACE}/${output}")
  json_object = readJSON text: handle.text
  json_object['attributes'].each { attr ->
    if(attr['name'] == attribute) {
      attribute_value = attr['value']
      return
    }
  }

  if(attribute_value == null)
    error "End of input reached but '${attribute}' was not found on '${from_path}'"

  return attribute_value
}

/** Finds the specified attribute within the attribute.json files in the given
 *  path and extracts all ocurrences with of this value *value*. If the attribute.
 *
 *  @param from_path The file where the attribute should be looked up.
 *  @param attribute The attribute to look for.
 *  @return The array with all matches of the given attribute.
 *
 */

def find_and_extract_all_ocurrences_of_a_key(from_path, attribute) {
  output = sh(
    script: """#!/bin/sh +x
      find '${from_path}' -name 'attributes.json' -print0 | xargs -0 fgrep -l -m 1 '${attribute}' | head -n 1""",
    returnStdout: true
  ).trim()

  if(output == "") return null

  response = []

  handle = new File("${WORKSPACE}/${output}")
  json_object = readJSON text: handle.text
  json_object['attributes'].each { attr ->
    if(attr['name'].contains(attribute)) {
      element = [:]
      element['name']   = attr['name']
      element['value']  = attr['value']
      response << element
    }
  }

  return response
}

/** Guess the brand of the current file using it's path.
 *
 *  @param from_file The path of the file.
 *  @return The brand of the current file.
 *
 */

def guess_current_brand(from_path) {
  current_brand = ''

  ['dacia', 'datsun', 'infiniti', 'nissan', 'renault'].each {brand ->
    if(from_path.contains(brand))
      current_brand = brand
  }

  return current_brand
}
