#!groovy

env.source = params.source
env.target = params.target

if ( env.source =~ /Prod/ || env.target =~ /Prod/ ) {
  error 'you are not allowed to use this environment'
}

properties([
    parameters([
      choice(choices:"use1nisuat-2\nuse1renuat\nuse1dev-stream1\nuse1qa-stream1\nuse1uat-stream1\nuse1dev-stream2\nuse1qa-stream2\nuse1uat-stream2\nuse1dev-stream3\nuse1qa-stream3\nuse1uat-stream3\nuse1dev-stream4\nuse1qa-stream4\nuse1uat-stream4\nuse1dev-stream5\nuse1qa-stream5\nuse1uat-stream5\nuse1dev-stream6\nuse1qa-stream6\nuse1uat-stream6\nuse1dev-stream7\nuse1qa-stream7\nuse1uat-stream7\nuse1dev-stream8\nuse1qa-stream8\nuse1uat-stream8\nuse1dev-stream9\nuse1qa-stream9\nuse1uat-stream9\nuse1dev-stream10\nuse1qa-stream10\nuse1uat-stream10\nuse1dev-stream11\nuse1qa-stream11\nuse1uat-stream11\nuse1dev-stream12\nuse1qa-stream12\nuse1uat-stream12\nuse1dev-stream13\nuse1qa-stream13\nuse1uat-stream13\nuse1dev-stream14\nuse1qa-stream14\nuse1uat-stream14\nuse1dev-stream15\nuse1qa-stream15\nuse1uat-stream15\nuse1dev-stream16\nuse1qa-stream16\nuse1uat-stream16\nuse1dev-stream17\nuse1qa-stream17\nuse1uat-stream17\nuse1dev-stream18\nuse1qa-stream18\nuse1uat-stream18\nuse1dev-stream19\nuse1qa-stream19\nuse1uat-stream19\nuse1dev-stream20\nuse1qa-stream20\nuse1uat-stream20\nuse1dev-stream21\nuse1qa-stream21\nuse1uat-stream21\nuse1dev-stream22\nuse1qa-stream22\nuse1uat-stream22\nuse1dev-stream22\nuse1qa-stream22\nuse1uat-stream22\nuse1dev-stream23\nuse1qa-stream23\nuse1uat-stream23\nuse1dev-stream24\nuse1qa-stream24\nuse1uat-stream24\nuse1dev-stream25\nuse1qa-stream25\nuse1uat-stream25\n", description: 'Select the stream name', name: 'source'),
      choice(choices: "use1dev-stream1\nuse1qa-stream1\nuse1uat-stream1\nuse1dev-stream2\nuse1qa-stream2\nuse1uat-stream2\nuse1dev-stream3\nuse1qa-stream3\nuse1uat-stream3\nuse1dev-stream4\nuse1qa-stream4\nuse1uat-stream4\nuse1dev-stream5\nuse1qa-stream5\nuse1uat-stream5\nuse1dev-stream6\nuse1qa-stream6\nuse1uat-stream6\nuse1dev-stream7\nuse1qa-stream7\nuse1uat-stream7\nuse1dev-stream8\nuse1qa-stream8\nuse1uat-stream8\nuse1dev-stream9\nuse1qa-stream9\nuse1uat-stream9\nuse1dev-stream10 \nuse1qa-stream10\nuse1uat-stream10\nuse1dev-stream11\nuse1qa-stream11\nuse1uat-stream11\nuse1dev-stream12\nuse1qa-stream12\nuse1uat-stream12\nuse1dev-stream13\nuse1qa-stream13\nuse1uat-stream13\nuse1dev-stream14\nuse1qa-stream14\nuse1uat-stream14\nuse1dev-stream15\nuse1qa-stream15\nuse1uat-stream15\nuse1dev-stream16\nuse1qa-stream16\nuse1uat-stream16\nuse1dev-stream17\nuse1qa-stream17\nuse1uat-stream17\nuse1dev-stream18\nuse1qa-stream18\nuse1uat-stream18\nuse1dev-stream19\nuse1qa-stream19\nuse1uat-stream19\nuse1dev-stream20\nuse1qa-stream20\nuse1uat-stream20\nuse1dev-stream21\nuse1qa-stream21\nuse1uat-stream21\nuse1dev-stream22\nuse1qa-stream22\nuse1uat-stream22\nuse1dev-stream22\nuse1qa-stream22\nuse1uat-stream22\nuse1dev-stream23\nuse1qa-stream23\nuse1uat-stream23\nuse1dev-stream24\nuse1qa-stream24\nuse1uat-stream24\nuse1dev-stream25\nuse1qa-stream25\nuse1uat-stream25\n", description: 'Select the stream name', name: 'target'),
      string(defaultValue: 'fr_FR', description: 'Provide the market details', name: 'Market', trim: false),
      choice(choices: "nissan\nrenault\ninfiniti\ndacia\ndatsun\n", description: 'Please select the brand', name: 'Brand'),
    ])
  ])

node {
  currentBuild.description = "ElasticSearch Migration: ${source} -> ${target}"
  deleteDir()

  // ANSI color codes
  green='\u001B[32m'
  red='\u001B[31m'
  bold='\u001B[1m'
  reset='\u001B[0m'

  env.language=params.Market.split('_')[0]
  env.country=params.Market.split('_')[1]
  env.scheme="https"

  if ( env.Brand == "renault" || env.Brand == "dacia") {
    env.ElasticSearch_Host="esearch.nonprod.heliosrenault.net"
    env.ElasticSearch_Port=32123
  }
  else {
    env.ElasticSearch_Host="search.nonprod.heliosalliance.net"
    env.ElasticSearch_Port=31896
  }

  stage('Checkout') {
    checkout changelog: false, poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']],
    doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'WipeWorkspace']], submoduleCfg: [],
    userRemoteConfigs: [[credentialsId: '', url: '']]]
  }

  stage('Install Bundles') {
  withEnv(["PATH=/var/lib/jenkins/.rbenv/shims:/var/lib/jenkins/.rbenv/bin:/var/lib/jenkins/.rbenv/plugins/ruby_build/bin:/usr/local/bin:/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/sbin"]) {
    wrap([$class: 'AnsiColorBuildWrapper']) {
      println "${bold}Install Bundles and Update Databag: ${green}Installing Chef bundles ${reset}"
      sh '''
        set +x
        cd helios-pipeline/scripts/indexcopier
        BUNDLE_GEMFILE=Gemfile bundle install --path /var/lib/jenkins/pipelines-bundle-path
        rbenv rehash
      '''
      }
    }
  }
  stage('ElasticSearch Migration') {
   withEnv(["PATH=/var/lib/jenkins/.rbenv/shims:/var/lib/jenkins/.rbenv/bin:/var/lib/jenkins/.rbenv/plugins/ruby_build/bin:/usr/local/bin:/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/sbin"]) {
     dir('helios-pipeline/scripts/indexcopier') {
     withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: '',
     usernameVariable: 'ElasticSearch_Username', passwordVariable: 'ElasticSearch_Password']]) {
       sh '''
         set +x
         bundle exec ruby indexcopier.rb --host ${ElasticSearch_Host} --port ${ElasticSearch_Port} --scheme ${scheme} --username ${ElasticSearch_Username} -p ${ElasticSearch_Password} --sourcePrefix ${source} --targetPrefix ${target} -b ${Brand} -c ${country} -l ${language}
       '''
       }
      }
    }
  }

  step([$class: 'WsCleanup'])
  deleteDir()
}
