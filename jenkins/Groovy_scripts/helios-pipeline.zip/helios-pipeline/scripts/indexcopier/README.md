ElasticSearch - Data copy

As part of the work to reduce cost from the Mule license, a data copy job was planned for ElasticSearch.

A Ruby script is available to copy an index with its settings, mapping types and data to a target index in the same ElasticSearch cluster (download here).

The folder structure is as follows:

Script folder structure
elasticsearch-indexcopier
+---indexcopier.rb
+---Gemfile
+---Gemfile.lock
+---lib
|   +---copiers
|   |   +---base_index_copier.rb
|   |   +---offers_index_copier.rb
|   |   +---vn_inventory_index_copier.rb
|   |   +---vo_inventory_index_copier.rb
|   +---utils
|   |   +---inventory
|   |   |   +---vn
|   |   |   |   +---vn_utils.rb
|   |   |   +---vo
|   |   |       +---vo_utils.rb
|   |   +---offers
|   |   |    +---offers_utils.rb
|   |   +---generic_utils.rb

Script invocation
  ruby indexcopier.rb --host localhost --port 9200 --scheme http --username esuser -p 123456 --sourcePrefix use1nisuat-2 --targetPrefix use1qa-stream1 -b nissan -c US -l en

For more details : https://confluence.lbi.co.uk/display/PH/ElasticSearch+-+Data+copy

https://jira.lbi.co.uk/browse/HDS-4731
