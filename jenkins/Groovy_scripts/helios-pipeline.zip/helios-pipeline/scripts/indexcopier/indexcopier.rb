require 'elasticsearch'
require 'elasticsearch/extensions/reindex'
require 'getoptlong'
require 'highline/import'
require 'timeout'

dir = './lib/copiers'
$LOAD_PATH.unshift(dir)
Dir[File.join(dir, '*.rb')].each {|file| require File.basename(file) }

opts = GetoptLong.new(
  [ '--help', '-h', GetoptLong::NO_ARGUMENT ],
  [ '--host', GetoptLong::OPTIONAL_ARGUMENT, ],
  [ '--port', GetoptLong::OPTIONAL_ARGUMENT ],
  [ '--scheme', GetoptLong::OPTIONAL_ARGUMENT ],
  [ '--username', '-u', GetoptLong::REQUIRED_ARGUMENT ],
  [ '--password', '-p', GetoptLong::OPTIONAL_ARGUMENT ],
  [ '--sourcePrefix', GetoptLong::REQUIRED_ARGUMENT ],
  [ '--sourceSuffix', GetoptLong::REQUIRED_ARGUMENT ],
  [ '--targetPrefix', GetoptLong::REQUIRED_ARGUMENT ],
  [ '--targetSuffix', GetoptLong::REQUIRED_ARGUMENT ],
  [ '--brand', '-b', GetoptLong::REQUIRED_ARGUMENT ],
  [ '--country', '-c', GetoptLong::REQUIRED_ARGUMENT ],
  [ '--language', '-l', GetoptLong::REQUIRED_ARGUMENT ]
)

if ARGV.length !=0
	helpCall = false
	host = "localhost"
	port = 9200
  scheme = "http"
	username = nil
	password = nil
	sourcePrefix = nil
  sourceSuffix = ""
	targetPrefix = nil
  targetSuffix = ""
	brand = nil
	country = nil
	language = nil
	halt = false

	opts.each do |opt, arg|
		case opt
			when '--help'
				puts <<-EOF

    indexcopier [arguments]

    -h, --help:
    	Show help

    --host [host]:
    	ElasticSearch host. Default to localhost.

    --port [port]:
    	ElasticSearch port. Default to 9200.

    --scheme [scheme]:
    	URI scheme. Defaults to http.

    -u, --username 'username':
    	ElasticSearch cluster basic auth username

    -p, --password 'password':
    	ElasticSearch cluster basic auth password

    --sourcePrefix 'prefix':
    	Source index name prefix e.g. use1qa-stream1, use1uat-stream1

    --sourceSuffix 'suffix':
    	Source index name suffix e.g. dark, live

    --targetPrefix 'prefix':
    	Destination index name prefix e.g. use1qa-stream1, use1uat-stream1

    --targetSuffix 'suffix':
    	Destination index name suffix e.g. dark, live

    -b, --brand 'brand':
    	Brand for which the data is being copied

    -c, --country 'country':
    	2 letter country code (ISO 3166-1 alpha-2) e.g. FR, US, CO, IT, DE

    -l, --language 'language':
    	2 letter language code (ISO 639-1) e.g. fr, en, es, it, de

EOF
				helpCall = true
			when '--host'
				if arg != ''
					host = arg
				end
			when '--port'
				if arg != ''
					port = arg.to_i
				end
      when '--scheme'
        if arg != ''
          scheme = arg
        end
			when '--username'
				username = arg
			when '--sourcePrefix'
				sourcePrefix = arg.downcase
      when '--sourceSuffix'
        if arg != ''
          sourceSuffix = arg.downcase
        end
			when '--targetPrefix'
				targetPrefix = arg.downcase
      when '--targetSuffix'
        if arg != ''
          targetSuffix = arg.downcase
        end
			when '--brand'
				brand = arg.downcase
			when '--country'
				country = arg.downcase
			when '--language'
				language = arg.downcase
			when '--password'
				if arg == ''
					begin
						password = Timeout::timeout(5, klass = RuntimeError) {
							ask("Enter the ES basic auth password: ") { |q| q.echo = false }
						}
					rescue
						puts "The ES basic auth password was not received in 30 seconds. Halting the program."
						halt = true
					end
				else
					password = arg
				end
		end
	end

	if not helpCall and not halt
		if not (username.nil? or password.nil? or sourcePrefix.nil? or targetPrefix.nil? or brand.nil? or country.nil? or language.nil?)

			#Create ES client

			esClient = Elasticsearch::Client.new hosts: [ { host: host, port: port, user: username, password: password, scheme: scheme } ], transport_options: { ssl: { verify: false } }

      BaseIndexCopier.repository.each do |indexCopier|
        instance = indexCopier.new esClient
        instance.copyData(brand, country, language, sourcePrefix, sourceSuffix, targetPrefix, targetSuffix)
      end

			exit 0
		else
			puts "Missing arguments (try --help)"
			exit 1
		end
	elsif helpCall
		exit 0
	elsif halt
		exit 1
	end
else
	puts "Missing arguments (try --help)"
	exit 1
end
