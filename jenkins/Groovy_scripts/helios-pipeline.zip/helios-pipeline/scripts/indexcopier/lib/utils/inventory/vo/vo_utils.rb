module IndexCopier
  module Utils
    module Inventory
      module VO

        def generateAliasName(brand, country, language, prefix = "local", suffix = "")
          baseName = "#{prefix}_inventory_#{brand}_#{country}_#{language}_vo"
          if not suffix.empty?
            baseName += "_#{suffix}"
          end
          baseName
        end

      end
    end
  end
end
