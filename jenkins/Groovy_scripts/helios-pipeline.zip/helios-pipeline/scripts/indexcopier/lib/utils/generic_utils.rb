require 'date'

module IndexCopier
  module Utils
    def generateIndexName(aliasName)
      aliasName + "_" + DateTime.now.strftime(format = '%Y_%m_%d_%H_%M_%S')
    end
  end
end
