require_relative 'base_index_copier'
require_relative '../utils/offers/offers_utils'

class OffersIndexCopier < BaseIndexCopier
  include IndexCopier::Utils::Offers
end
