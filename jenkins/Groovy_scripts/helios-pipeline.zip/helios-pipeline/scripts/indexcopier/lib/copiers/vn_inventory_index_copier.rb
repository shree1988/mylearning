require_relative 'base_index_copier'
require_relative '../utils/inventory/vn/vn_utils'

class VNInventoryIndexCopier < BaseIndexCopier
  include IndexCopier::Utils::Inventory::VN
end
