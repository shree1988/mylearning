require_relative '../utils/generic_utils.rb'

class BaseIndexCopier
  include IndexCopier::Utils

  def initialize(client)
    @client = client
  end

  def self.repository
    @repository ||= []
  end

  def self.inherited(klass)
    repository << klass
  end

  def getIndexNameFromAlias(aliasName)
    aliases = @client.cat.aliases name: aliasName, format: 'json'
    if aliases.any?
      return aliases[0]['index']
    else
      return nil
    end
  end

  def getIndexSettings(indexName)
  	indexData = @client.indices.get_settings index: indexName
  	return indexData[indexName]
  end

  def getIndexMappingData(indexName)
  	indexMappingData = @client.indices.get_mapping index: indexName
  	indexMappingBody = indexMappingData[indexName]['mappings']
  	indexMappingType = indexMappingBody.keys.first
  	return { type: indexMappingType, body: indexMappingBody }
  end

  def copyData(brand, country, language, sourcePrefix, sourceSuffix, targetPrefix, targetSuffix)
    puts "Preparing indices, settings, and mapping types for the data copy..."
    #Build source and target aliases names
    sourceAliasName = generateAliasName(brand, country, language, sourcePrefix, sourceSuffix)
    targetAliasName = generateAliasName(brand, country, language, targetPrefix, targetSuffix)
    #Build target index name
    targetIndexName = generateIndexName(targetAliasName)
    #Get source index associated to source alias
    sourceIndexName = getIndexNameFromAlias(sourceAliasName)

    if sourceIndexName.nil?
      puts "No index for alias #{sourceAliasName} was found. No data will be copied."
    else
      sourceIndexSettings = getIndexSettings(sourceIndexName)
      sourceIndexMappingData = getIndexMappingData(sourceIndexName)

      #Copy source index to target index
      puts "Data copy from #{sourceIndexName} to #{targetIndexName} has started."
      copyIndex(sourceIndexName, sourceIndexSettings, sourceIndexMappingData, targetIndexName)
      puts "Data copy from #{sourceIndexName} to #{targetIndexName} has finished."

      assignAliasToIndex(targetAliasName, targetIndexName)
      puts "#{targetAliasName} assigned to index #{targetIndexName}."
    end
  end

  def copyIndex(sourceIndexName, sourceIndexSettings, sourceIndexMappingData, targetIndexName)
  	@client.indices.create index: targetIndexName, body: sourceIndexSettings
  	@client.indices.put_mapping index: targetIndexName, type: sourceIndexMappingData[:type], body: sourceIndexMappingData[:body]
  	@client.reindex source: { index: sourceIndexName }, target: { index: targetIndexName }, refresh: true
  end

  def assignAliasToIndex(aliasName, indexName)
  	aliases = @client.cat.aliases name: aliasName, format: 'json'
  	if aliases.any?
  		aliases.each do |i|
  			@client.indices.delete_alias index: i["index"], name: aliasName
  		end
  	end
  	@client.indices.put_alias index: indexName, name: aliasName
  end

end
