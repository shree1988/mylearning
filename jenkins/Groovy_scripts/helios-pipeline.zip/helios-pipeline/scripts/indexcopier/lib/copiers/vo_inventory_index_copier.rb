require_relative 'base_index_copier'
require_relative '../utils/inventory/vo/vo_utils'

class VOInventoryIndexCopier < BaseIndexCopier
  include IndexCopier::Utils::Inventory::VO
end
