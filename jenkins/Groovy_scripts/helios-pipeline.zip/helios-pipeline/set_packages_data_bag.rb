appname = ARGV[2]
environment = ARGV[3]
version = ARGV[4]
build = ARGV[5]

puts "Setting databags in Chef Server for #{appname} #{version} #{build} on #{environment}"

### Set databag for Author and Publisher
if appname == "author" || appname == "publish"
  data_bag = data_bag_item(environment, appname)

  data_bag['packages'].each do |package|
	  if package['build_number'] != build
		  puts "#{appname} / #{package['artifactId']} build changed from #{package['build_number']} to #{build}"
	  end
	  package['build_number'] = build
	  if package['version'] != version
		  puts "#{appname} / #{package['artifactId']} version changed from #{package['version']} to #{version}"
	  end
	  package['version'] = version
  end
  data_bag.save
### Set databag for Mule and Tomcat
elsif appname == "mule-esb" || appname == "helios-api"
  apis = data_bag_item(environment, appname)

  if appname == "mule-esb"
    applications = "mule_applications"
  elsif appname == "helios-api"
    applications = "tomcat_applications"
  end

  apis[applications].each do |app|
  	app['snapshot'] = version
    app['build_number'] = build
  end
  apis.save

elsif appname == "helios-kvm" || appname == "helios-is-api"
  data_bag = data_bag_item(environment, appname)

  data_bag['tomcat_applications'].each do |package|
    if package['build_number'] != build
      puts "#{appname} / #{package['artifactId']} build changed from #{package['build_number']} to #{build}"
    end
    package['build_number'] = build
    if package['snapshot'] != version
      puts "#{appname} / #{package['artifactId']} version changed from #{package['snapshot']} to #{version}"
    end
    package['snapshot'] = version
  end
  data_bag.save

end
exit 0
