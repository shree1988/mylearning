#!groovy

env.Branch_Name = params.Branch_Name
env.Apigee_Env_Name = params.Apigee_Env_Name
env.Org_Type = params.Org_Type

node {

  // ANSI color codes
  green='\u001B[32m'
  red='\u001B[31m'
  bold='\u001B[1m'
  reset='\u001B[0m'

  properties([ parameters([
    choice(name: 'Branch_Name', choices: env.Branch_Name, description: 'Stack Name e.g: master'),
    choice(name: 'Apigee_Env_Name', choices: env.Apigee_Env_Name, description: 'Stack Name e.g: renault'),
    choice(name: 'Org_Type', choices: env.Org_Type, description: 'Stack Name e.g: digitaslbi')
    ]),
    pipelineTriggers([pollSCM('H/5 * * * *')])
  ])

  stage('Checkout') {
    checkout([$class: 'GitSCM', branches: [[name: '*/${Branch_Name}']],
    doGenerateSubmoduleConfigurations: false,
    extensions: [[$class: 'PathRestriction', excludedRegions: '', includedRegions: "deployment/src/main/apiproxy/${Org_Type}/${Apigee_Env_Name}/.*"], [$class: 'CloneOption', depth: 2, noTags: true, reference: '', shallow: true, timeout: 30]],
    submoduleCfg: [],
    userRemoteConfigs: [[credentialsId: '', url: '']]
    ])
  }

  stage('Zipping the config folders') {
        sh '''
          set +x
          cd deployment/src/main/apiproxy/${Org_Type}/
          echo "Zipping the config folder for the environment ${Apigee_Env_Name} and the branch name is ${Branch_Name}"
          zip -r ${WORKSPACE}/${Apigee_Env_Name}.zip ${Apigee_Env_Name}
        '''
   }
   stage('Upload to S3') {
      wrap([$class: 'AnsiColorBuildWrapper']) {
      withCredentials([[$class: 'AmazonWebServicesCredentialsBinding', accessKeyVariable: 'AWS_ACCESS_KEY_ID',
      credentialsId: "", secretKeyVariable: 'AWS_SECRET_ACCESS_KEY']]) {
        withAWS(region:'us-east-1') {
          def createS3 = s3Upload(file:"${WORKSPACE}/${env.Apigee_Env_Name}.zip", bucket:'s3-renault-prod-isconfig',
          path:"${env.Apigee_Env_Name}.zip")
        }
      }
    }
  }
  stage('Delete the config zip') {
      wrap([$class: 'AnsiColorBuildWrapper']) {
      sh '''
        set +x
        echo "Deleting the ${Apigee_Env_Name}.zip from workspace"
        rm -rf ${Apigee_Env_Name}.zip
        exitcode=$?
        if [ "$exitcode" -ne "0" ] ; then
          echo "${Apigee_Env_Name}.zip is not deleted properly. Please contact DevOps!"
          exit 1
        fi
      '''
    }
  }
}
