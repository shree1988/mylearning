#!groovy

env.Version_ID = params.Version_ID
env.Build_ID = params.Build_ID
env.Chef_ENV = params.Chef_ENV
env.App_Name = params.App_Name

node {
  currentBuild.description = "${Version_ID}-${Build_ID} ⇨ ${Chef_ENV}-${App_Name}"

  // Wipe the workspace so we are building completely clean
  deleteDir()

  // ANSI color codes
  env.Green='\u001B[32m'
  env.Red='\u001B[31m'
  env.Bold='\u001B[1m'
  env.Reset='\u001B[0m'

  if ( !(params.Version_ID) || !(params.Build_ID) || !(params.Chef_ENV) || !(params.App_Name) ) {
    wrap([$class: 'AnsiColorBuildWrapper']) {
      println "${red}Please specify all the parameters!${reset}"
      error()
    }
  }

  properties([
    parameters([
      string(name: 'Version_ID', defaultValue: env.Version_ID, description: 'Package version ID e.g: 18.0.0-SNAPSHOT'),
      string(name: 'Build_ID', defaultValue: env.Build_ID, description: 'Package build ID e.g: 1'),
      choice(name: 'Chef_ENV', choices: env.Chef_ENV, description: 'Stack Name e.g: nonprod-kvm/prod-kvm'),
      choice(name: 'App_Name', choices: "KVM-UI\nIS-API\n", description: 'Application Name e.g: KVM-UI (KVM UI Application) IS-API ( Integration setting API)')
    ])
  ])

  // Check if build exist in Nexus
  stage('Check Build on Nexus') {

    if ( env.Chef_ENV =~ /nonprod-kvm/ ) {
      env.Env_Repo = 'is-config-nonprod'
    }
    else {
      env.Env_Repo = 'is-config-prod'
    }
    wrap([$class: 'AnsiColorBuildWrapper']) {
      println "${bold}Check Build on Nexus: ${green}Checking the Nexus for build ${Version_ID}-${BUILD_ID} ${reset}"
      sh '''
        set +x
        if [[ ${App_Name} == "KVM-UI" ]]; then
          if ! [[ `wget -S --spider "https://nexus.helios-aws.com/service/local/artifact/maven/redirect?r=${Env_Repo}&g=com.digitaslbi.helios&a=kvm-management-ui&v=build-${BUILD_ID}-${Version_ID}&p=war" 2>&1 | grep 'HTTP/1.1 200 OK'` ]]; then
            echo "${Red} --- The ${Version_ID} #${BUILD_ID} helios-id-aem doesn't exist on the Nexus ${Env_Repo} --- ${Reset}"
            echo "${bold} --- Repo URL:${Reset} https://nexus.helios-aws.com/service/local/artifact/maven/redirect?r=${Env_Repo}&g=com.digitaslbi.helios&a=kvm-management-ui&v=build-${BUILD_ID}-${Version_ID}&p=war"
            exit 1
          fi
        elif [[ ${App_Name} == "IS-API" ]]; then
          if ! [[ `wget -S --spider "https://nexus.helios-aws.com/service/local/artifact/maven/redirect?r=${Env_Repo}&g=com.digitaslbi.helios&a=integration-settings-management-api&v=build-${BUILD_ID}-${Version_ID}&p=war" 2>&1 | grep 'HTTP/1.1 200 OK'` ]]; then
            echo "${Red} --- The ${Version_ID} #${BUILD_ID} helios-mule-accessories doesn't exist on the Nexus ${Env_Repo} --- ${Reset}"
            echo "${bold} --- Repo URL:${Reset} https://nexus.helios-aws.com/service/local/artifact/maven/redirect?r=${Env_Repo}&g=com.digitaslbi.helios&a=integration-settings-management-api&v=build-${BUILD_ID}-${Version_ID}&p=war"
            exit 1
          fi
        fi
      '''
    }
  }

  // KVM-UI|IS-API
  env.Chef_Node_Search = 'chef_environment:' + env.Chef_ENV + ' AND name:*'

  stage('Checkout') {
    wrap([$class: 'AnsiColorBuildWrapper']) {
      println "${bold}Checkout: ${green}Checkout the configuration repository ${reset}"
      // Checkout configuration repository
      checkout changelog: false, poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']],
      doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'WipeWorkspace']], submoduleCfg: [],
      userRemoteConfigs: [[credentialsId: '', url: '']]]
    }
  }

  stage('Install Bundles and Update Databag') {
    withEnv(["PATH=/var/lib/jenkins/.rbenv/shims:/var/lib/jenkins/.rbenv/bin:/var/lib/jenkins/.rbenv/plugins/ruby_build/bin:/usr/local/bin:/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/sbin"]) {
      wrap([$class: 'AnsiColorBuildWrapper']) {
        println "${bold}Install Bundles and Update Databag: ${green}Installing Chef bundles ${reset}"
        sh '''
          set +x
          cd chef-server
          BUNDLE_GEMFILE=Gemfile_for_knife_pipeline bundle install --path /var/lib/jenkins/pipelines-bundle-path
          rbenv rehash
        '''

        // Push databag changes to chef server
        println "${bold}Install Bundles and Update Databag: ${green}Updating the Chef server ${Chef_ENV} Databag with build ${Version_ID}-${BUILD_ID} ${reset}"
        sh '''
          set +x
          cd chef-server
            if [[ ${App_Name} == "KVM-UI" ]]; then
              BUNDLE_GEMFILE=Gemfile_for_knife_pipeline bundle exec knife exec ../helios-pipeline/set_packages_data_bag.rb helios-kvm ${Chef_ENV} ${Version_ID} ${BUILD_ID} || exit 1
            fi
            if [[ ${App_Name} == "IS-API" ]]; then
              BUNDLE_GEMFILE=Gemfile_for_knife_pipeline bundle exec knife exec ../helios-pipeline/set_packages_data_bag.rb helios-is-api ${Chef_ENV} ${Version_ID} ${BUILD_ID} || exit 1
            fi
        '''

        // Commit and Push "version_id and build_id" change to databag in git configuration repo
        println "${bold}Install Bundles and Update Databag: ${green}Downloading the ${Chef_ENV} Databags changes from Chef server ${reset}"
        sh '''
          set +x
          cd chef
            if [[ ${App_Name} == "KVM-UI" ]]; then
              BUNDLE_GEMFILE=../chef-server/Gemfile_for_knife_pipeline bundle exec knife download data_bags/${Chef_ENV}/helios-kvm.json --chef-repo-path .
            fi
            if [[ ${App_Name} == "IS-API" ]]; then
              BUNDLE_GEMFILE=../chef-server/Gemfile_for_knife_pipeline bundle exec knife download data_bags/${Chef_ENV}/helios-is-api.json --chef-repo-path .
            fi
        '''

        println "${bold}Install Bundles and Update Databag: ${green}Commit and Push Databags changes to configuration repository ${reset}"
        withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: '',
        usernameVariable: 'GIT_USERNAME', passwordVariable: 'GIT_PASSWORD']]) {
          sh '''
            set +x
            git checkout master
            cd chef
            echo 'Git status is :'
            git status --porcelain
            if [[ `git status --porcelain` ]]; then
              echo 'Pushing data bags changes to master'
              git remote add central https://${GIT_USERNAME}:${GIT_PASSWORD}@gitlab.helios-aws.com/helios/ops/configuration.git
              git config --global user.name "Helios Pipeline"
              git config --global user.email dev.ops@heliosalliance.net
                if [[ ${App_Name} == "KVM-UI" ]]; then
                  git add data_bags/${Chef_ENV}/helios-kvm.json
                fi
                if [[ ${App_Name} == "IS-API" ]]; then
                  git add data_bags/${Chef_ENV}/helios-is-api.json

                fi
              git commit -m "Version bump to ${Version_ID} build ${BUILD_ID} on ${Chef_ENV}"
              git pull
              git push origin master
            fi
          '''
        }
      }
    }
  }
  stage("Deploying ${App_Name} to ${Chef_ENV}") {
    withEnv(["PATH=/var/lib/jenkins/.rbenv/shims:/var/lib/jenkins/.rbenv/bin:/var/lib/jenkins/.rbenv/plugins/ruby_build/bin:/usr/local/bin:/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/sbin"]) {
      dir('chef-server') {
        wrap([$class: 'AnsiColorBuildWrapper']) {
          // running converge (chef-client) on node through pushy job
          if ( App_Name == "KVM-UI") {
            println "${bold}Deploying to ${Chef_ENV}-${App_Name}: ${green}Deploying build ${Version_ID}-${BUILD_ID} on ${Chef_ENV} ${reset}"
            sh '#!/bin/sh +x\n' + 'BUNDLE_GEMFILE=Gemfile_for_knife_pipeline bundle exec knife job start chef-client -s "${Chef_Node_Search}"'

          }
          if ( App_Name == "IS-API") {
            println "${bold}Deploying to ${Chef_ENV}-${App_Name}: ${green}Deploying build ${Version_ID}-${BUILD_ID} on ${Chef_ENV} ${reset}"
            sh '#!/bin/sh +x\n' + 'BUNDLE_GEMFILE=Gemfile_for_knife_pipeline bundle exec knife job start chef-client -s "${Chef_Node_Search}"'
          }
        }
      }
    }
  }
}
