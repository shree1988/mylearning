#!groovy

if ( params.Workstream_Environment == null || params.Workstream_Name == null) {
  error 'Please specify all the parameters'
}

node {
  // Wipe the workspace so we are building completely clean
  deleteDir()

  // ANSI color codes
  green='\u001B[32m'
  red='\u001B[31m'
  bold='\u001B[1m'
  reset='\u001B[0m'

  currentBuild.description = "${Workstream_Environment}-${Workstream_Name}"

  // Create services user
  stage('Creating Service User') {
    wrap([$class: 'AnsiColorBuildWrapper']) {
      withCredentials([[$class: 'AmazonWebServicesCredentialsBinding', accessKeyVariable: 'AWS_ACCESS_KEY_ID',
      credentialsId: '', secretKeyVariable: 'AWS_SECRET_ACCESS_KEY']]) {

        def check_user = sh(
          script: '#!/bin/sh +x\n aws iam get-user --user-name helios-${Workstream_Environment}-${Workstream_Name}-services > /dev/null 2>&1',
          returnStatus: true)
          if ( check_user != 0 ) {
            def create_user = sh(
              script: '#!/bin/sh +x\n aws iam create-user --user-name helios-${Workstream_Environment}-${Workstream_Name}-services > /dev/null 2>&1',
              returnStatus: true)
              if ( create_user != 0 ) {
                error "Creating Service User: Unable to create user: helios-${Workstream_Environment}-${Workstream_Name}-services"
              }
            println "${bold}Creating Service User: ${green}helios-${Workstream_Environment}-${Workstream_Name}-services has been created${reset}"
          } else {
            println "${bold}Creating Service User: ${green}User with name helios-${Workstream_Environment}-${Workstream_Name}-services already exists${reset}"
          }

        def create_keys = sh(
          script: '#!/bin/sh +x\n' + "aws iam create-access-key --user-name helios-${Workstream_Environment}-${Workstream_Name}-services --output text 2>/dev/null | awk '{print \$2\"-\"\$4}'",
          returnStdout: true).trim()
          if ( create_keys != '' ) {
            println "${bold}Creating Service User: ${green}AWS Access/Secret keys has been created${reset}"
          } else {
            error 'Creating Service User: Unable to create Access-Secret Keys!'
          }
      }
    }
  }

  stage('Checkout AWS Repo') {
    // Checkout AWS repository
    checkout changelog: false, poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']],
    doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'WipeWorkspace'],
    [$class: 'RelativeTargetDirectory', relativeTargetDir: 'aws-repo']], submoduleCfg: [],
    userRemoteConfigs: [[credentialsId: '', url: '']]]
  }

  // Set-up SQS/S3
  stage('Creating S3 Buckets') {
    wrap([$class: 'AnsiColorBuildWrapper']) {
      withCredentials([[$class: 'AmazonWebServicesCredentialsBinding', accessKeyVariable: 'AWS_ACCESS_KEY_ID',
      credentialsId: '', secretKeyVariable: 'AWS_SECRET_ACCESS_KEY']]) {
        withAWS(region:'us-east-1') {
          println "${bold}Creating S3 Buckets: ${green}Updating/Creating CloudFormation stack ${Workstream_Environment}-${Workstream_Name}-S3${reset}"

          def outputs = cfnUpdate(stack:"${Workstream_Environment}-${Workstream_Name}-S3", file:'aws-repo/S3/cfn-Helios-S3-IntegrationBuckets.yaml',
          params:["BillingJIRA=${Billing_Jira}", "BillingNotes=${Billing_Notes}", "Company=${Billing_Company}",
          "CreatedBy=${CreatedBy}", "Environment=${Workstream_Environment}", "EnvironmentType=${Environment_Type}",
          "Workstream=${Workstream_Name}"],
          pollInterval:1000)
          println "${bold}Creating S3 Buckets: ${green}CloudFormation stack ${Workstream_Environment}-${Workstream_Name}-S3 has been created${reset}"
        }
      }
    }
  }

  // Set-up SQS/S3
  stage('Creating SQS Queues') {
    wrap([$class: 'AnsiColorBuildWrapper']) {
      withCredentials([[$class: 'AmazonWebServicesCredentialsBinding', accessKeyVariable: 'AWS_ACCESS_KEY_ID',
      credentialsId: '', secretKeyVariable: 'AWS_SECRET_ACCESS_KEY']]) {
        withAWS(region:'us-east-1') {
          println "${bold}Creating SQS Queues: ${green}Updating/Creating CloudFormation stack ${Workstream_Environment}-${Workstream_Name}-SQS${reset}"

          def outputs = cfnUpdate(stack:"${Workstream_Environment}-${Workstream_Name}-SQS", file:'aws-repo/SQS/cfn-Helios-SQS-QueuesAndPolcies.template',
          params:["CreatePolicies=False", "EnvironmentType=stream",
          "Environment=${Workstream_Environment}", "Workstream=${Workstream_Name}"],
          pollInterval:1000)
          println "${bold}Creating SQS Queues: ${green}CloudFormation stack ${Workstream_Environment}-${Workstream_Name}-SQS has been created${reset}"
        }
      }
    }
  }

}
