//
// Creating/Uploading AEM content packages
//
import java.text.SimpleDateFormat
properties([
  parameters([
    string (name: 'source_environment', defaultValue: 'use1rentrn', description: 'Get the content from which environment?'),
    text (name: 'target_environment', defaultValue: 'use1dev1-bae', description: 'Which environments?\nOne line for each environment'),
    text (name: 'folders', defaultValue: '/content/dacia_master', description: 'Which folders?\nOne line for each folder'),
    text (name: 'excludes', defaultValue: '', description: 'Which folders to exclude?\nOne line for each folder')
   ])
])

node{

  // Wipe the workspace so we are building completely clean
  deleteDir()

  //******** Configuration ********
  // ANSI color codes
  green='\u001B[32m'
  red='\u001B[31m'
  bold='\u001B[1m'
  reset='\u001B[0m'
  // AEM package 'Group', in order to find the content packages in /crx/packmgr
  package_group='content_migration'
  // Default port of AEM Authors
  server_port='4502'
  // All Authors will use that user to create/upload packages
  aem_username='admin'
  // If we can't find the AEM password for 'admin' in our Chef environment, we're using that password
  default_aem_password='admin'
  // AWS S3 bucket in which the AEM package we created will be stored
  bucket='s3-TestContentMigration-bucket'
  // name of the 'Jenkins Credentials' which allow read/write access to our S3 bucket
  aws_credentials='TestContentMigration'
  // Path to the AEM admin passwords in the Chef environments
  password_chef_path='override_attributes.aem.password'
  // Chef search string, in order to find the single AEM Author for a specific environment
  author_search='AND ( role:*aem-author* OR role:aem-stack-tarmk* ) NOT role:aem-author-dispatcher*'
  // List of users allowed to pull content from production
  // Get names from : http://pipeline.clcm.heliosalliance.net/asynchPeople/
  prod_users = [
      'omiladi','abhatt','dmanuj','psrikant'
  ]
  // Any request for a folder starting by that prefix will be checked
  restricted_folder = '/content/dam'
  // dam path level
  dam_level = 5
  // AEM admin password if in Vault
  aem_password_in_vault = 'inVault'

  if ( env.BUILD_NUMBER == '1' ) {
    description = "Job initialisation"
    echo description
    currentBuild.description = description
    currentBuild.result = 'SUCCESS'
    return
  }

  stage('Processing parameters'){
    wrap([$class: 'AnsiColorBuildWrapper']){


      // To block access to production Chef environments
      currentBuild.description = "${source_environment} ⇨ ${params.target_environment}\n${folders}"


      wrap([$class: 'BuildUser']) {
        build_userid = env.BUILD_USER_ID
        build_username = env.BUILD_USER
      }

      if ( params.source_environment =~ /prod/ ) {
        if ( ! ( build_userid in prod_users ) ) {
          echo "${bold}${red}User ${build_userid} not allowed to pull content from production${reset}"
          error('')
        } else {
          echo "User ${build_userid} allowed to pull content from production"
        }
      }

      if ( params.target_environment =~ /prod/ ) {
        echo "${bold}${red}Not uploading content to production for now${reset}"
        error('')
      }
      // No need to package nothing at all
      if ( params.folders.trim() == '') {
        echo "${bold}${red}At least one content folder needed${reset}"
        error('')
      }

      // Calling Groovy methods to find the IP and password for the source/target environments
      source_author_ip = get_author_ip(params.source_environment)
      source_aem_password = get_aem_password(params.source_environment)

      // AEM package name & AEM package filters setup
      // Each 'exclude' is excluded to each folder
      // Package name is be generated for example like : 260_use1qa_contentmysiteblog.zip
      package_name = "${env.BUILD_ID}_${params.source_environment}"
      filter=''
      params.folders.split("\n").each { folder ->
        echo "Folder : ${folder}"
        // Below logic checks if path starts with "/content/dam" and if it's less than 5 levels then build will gets failed
        // If the "/content/dam" path level is grater than ${dam_level} then ${folder} filter is allowed to build
        if ( folder.startsWith(restricted_folder) ) {
          size = folder.split("/")
          folderSize = size.length;
          if ( folderSize > dam_level ) {
            echo "${bold} contains ${folder} is allowed"
          }
          else {
            echo "${bold} contains ${folder} is forbidden"
            error('')
          }
        }
        if ( params.excludes.trim() != '' ) {
          filter += "{'root':'${folder}','rules':["
          params.excludes.trim().split("\n").each { exclude ->
            echo "Exclude : ${exclude}"
            filter += "{'modifier' : 'exclude', 'pattern' : '$exclude'},"
          }
          filter = filter.replaceAll(",\$", "");
        } else {
          filter += "{'root':'${folder}','rules':["
        }
        filter += ']},'
        package_name += "_${folder.replace('/','').replace('_','')}"
      }
      filter = filter.replaceAll(",\$", "");
      echo "Filter : ${filter}"
      def dateFormat = new SimpleDateFormat("yyyyMMdd-HHmm")
      def date = new Date()
      if ( package_name.length() > 100 ) {
        package_name = package_name.substring(0,100) + "_${dateFormat.format(date)}"
      } else {
        package_name = package_name + "_${dateFormat.format(date)}"
      }
      echo "Package name : ${package_name}"
      // AEM package description includes the name of the creator, the Jenkins URL, the source/target environments, and list of content folders, and exclusions if there's any
      if ( params.excludes != '' ){
        description_excluding = "\nExcluding : \n${params.excludes}"
      } else {
        description_excluding = ''
      }
      description = "Build by : ${build_username}\nFrom : ${params.source_environment}\nTo : ${params.target_environment}\nAt : ${dateFormat.format(date)}\nVia : ${env.JENKINS_URL}job/${JOB_NAME}/${env.BUILD_ID}\nWith :\n${params.folders}${description_excluding}"
      echo "Package description : ${description}"

    }
  }

  // Creating the AEM package using a curl command, on the 'target_environment' Author
  stage ('Creating AEM package'){
    create_output = sh (
      script: '#!/bin/sh +x\n' + "curl -u ${aem_username}:${source_aem_password} -X POST http://${source_author_ip}:${server_port}/crx/packmgr/service/.json/etc/packages/${package_group}/${package_name}?cmd=create -d packageName=${package_name} -d groupName=${package_group}",
      returnStdout: true
    ).trim()
    process_curl_output(create_output)
  }

  // Adding AEM package filters via curl, one filter per folder we want to package
  stage('Updating AEM package filters'){
    update_output = sh (
      script: '#!/bin/sh +x\n' + "curl -u ${aem_username}:${source_aem_password} -X POST http://${source_author_ip}:${server_port}/crx/packmgr/update.jsp \
  -F path=/etc/packages/${package_group}/${package_name}.zip\
  -F packageName=${package_name} \
  -F groupName=${package_group}\
  -F \"_charset_=UTF-8\" \
  -F description='$description' \
  -F filter=\"[${filter}]\" ",
      returnStdout: true
    ).trim()
    process_curl_output(update_output)
  }

  // Building the package via curl, this step is the slowest
  stage ('Building AEM package'){
    building_output = sh (
    script:  '#!/bin/sh +x\n' + "curl -u ${aem_username}:${source_aem_password} -X POST http://${source_author_ip}:${server_port}/crx/packmgr/service/.json/etc/packages/${package_group}/${package_name}.zip?cmd=build",
      returnStdout: true
    ).trim()
    process_curl_output(building_output)
  }

  // Downloading the AEM package locally in Jenkins, watch out for disk space
  // This step is required to be able to upload the package to the 'target_environment' Author
  stage ('Downloading AEM package'){
    sh '#!/bin/sh +x\n' + "curl -u ${aem_username}:${source_aem_password} http://${source_author_ip}:${server_port}/etc/packages/${package_group}/${package_name}.zip > ${package_name}.zip"
  }

  // the AEM package is uploaded but NOT installed in each of the 'target_environment' Authors
  stage ('Uploading AEM package to target environment'){
    params.target_environment.split("\n").each { target_environment ->
      target_author_ip = get_author_ip(target_environment)
      target_aem_password = get_aem_password(target_environment)
      upload_output = sh (
        script: '#!/bin/sh +x\n' + "curl -u ${aem_username}:${target_aem_password} -F package=@${package_name}.zip -F install=false -F force=true --fail http://${target_author_ip}:${server_port}/crx/packmgr/service/.json/?cmd=upload",
        returnStdout: true
      ).trim()
      process_curl_output(upload_output)
    }
  }

  // // Uploading to S3 our previously downloaded package
  // stage ('Uploading AEM package to S3'){
  //   withCredentials([[$class: 'AmazonWebServicesCredentialsBinding', credentialsId: aws_credentials, accessKeyVariable: 'AWS_ACCESS_KEY_ID', secretKeyVariable: 'AWS_SECRET_ACCESS_KEY']]) {
  //     sh '#!/bin/sh +x\n' + "aws s3 cp ${package_name}.zip s3://${bucket}/${package_name}.zip"
  //     wrap([$class: 'AnsiColorBuildWrapper']) {
  //         echo "${bold}Package uploaded to S3 at : ${green}s3://${bucket}/${package_name}.zip ${reset}"
  //     }
  //   }
  // }

  // If we don't want to upload the AEM package to the 'target_environment', and only upload it to S3, we can 'stream' the curl download to the aws command, without requiring disk space on Jenkins
  // stage ('Downloading AEM package + Uploading AEM package to S3'){
  //   withCredentials([[$class: 'AmazonWebServicesCredentialsBinding', credentialsId: 'TestContentMigration', accessKeyVariable: 'AWS_ACCESS_KEY_ID', secretKeyVariable: 'AWS_SECRET_ACCESS_KEY']]) {
  //     sh "curl -u ${aem_username}:${aem_password} http://${source_author_ip}:${server_port}/etc/packages/${package_group}/${package_name}.zip | aws s3 cp - s3://${bucket}/${package_name}.zip"
  //   }
  // }

  step([$class: 'WsCleanup'])
  deleteDir()
}


// Methods

def process_curl_output(json_object){
  curl_output_slurped = readJSON text: json_object
  if ( curl_output_slurped.success ) {
    wrap([$class: 'AnsiColorBuildWrapper']) {
      echo "${bold}AEM curl command successful : ${green}${curl_output_slurped.msg}${reset}"
    }
  } else {
    echo "${bold}AEM curl command failed : ${red}${curl_output_slurped.msg}${reset}"
    error('')
  }
}

def get_author_ip(environment){
  author_ip = sh (
    script: '#!/bin/sh +x\n' + "knife search 'chef_environment:${environment} ${author_search}' -F json -a ipaddress|grep ipaddress|sed 's/.*ipaddress\": \"//'|sed 's/\"//'",
    returnStdout: true
  ).trim()
  if ( author_ip == '' ){
    echo "${bold}${red}AEM Author IP for ${environment} can't be found${reset}"
    error('')
  } else if ( ! author_ip.matches("\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}") ) {
    echo "${bold}AEM Author IP for ${environment} is incorrect : ${red}${author_ip}${reset}"
    error('')
  } else {
    echo "${bold}AEM Author IP for ${environment} : ${green}${author_ip}${reset}"
    author_ip
  }
}

def get_aem_password(environment){
  aem_credentials = sh (
    script: '#!/bin/sh +x\n' + "knife data bag show ${environment} aem_credentials -F json",
    returnStdout: true
  ).trim()

  json_object = readJSON text: aem_credentials
  aem_password = json_object.admin.password

  if ( aem_password == 'null' ) {
    // Use the default password if we can't find any password
    echo "No AEM Author password found for ${environment}, setting it to $default_aem_password"
    aem_password_xxx = aem_password = default_aem_password
  } else if ( aem_password == aem_password_in_vault ) {
    echo "${bold}${red}AEM password ${aem_password_in_vault} not supported yet${reset}"
    error('')
  } else {
    // Show only the beginning of the non-default admin password
    show_chars_amount = 2
    aem_password_xxx = aem_password.substring(0,show_chars_amount)
    for (i = 0; i <= (aem_password.length()-show_chars_amount) ; i++) {
       aem_password_xxx += 'X'
    }
    // Stupid Jenkins blocking '.times'
    // (aem_password.length()-show_chars_amount).times {
    //   aem_password_xxx += 'X'
    // }
  }

  aem_password
}
