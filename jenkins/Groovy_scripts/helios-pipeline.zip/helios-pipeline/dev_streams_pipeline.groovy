#!groovy

env.Version_ID = params.Version_ID
env.Build_ID = params.Build_ID
env.Stack_Name = params.Stack_Name
env.App_Name = params.App_Name

if ( env.Stack_Name =~ /Prod/ ) {
  error 'you are not allowed to use this environment'
}

node {
  currentBuild.description = "${App_Name} ⇨ ${Stack_Name}"

  // Wipe the workspace so we are building completely clean
  deleteDir()

  // ANSI color codes
  green='\u001B[32m'
  red='\u001B[31m'
  bold='\u001B[1m'
  reset='\u001B[0m'

  if ( !(params.Version_ID) || !(params.Build_ID) || !(params.Stack_Name) || !(params.App_Name) ) {
    wrap([$class: 'AnsiColorBuildWrapper']) {
      println "${red}Please specify all the parameters!${reset}"
      error()
    }
  }

  properties([
    parameters([
      string(name: 'Version_ID', defaultValue: env.Version_ID, description: 'Package version ID e.g: 17.1.0-SNAPSHOT'),
      string(name: 'Build_ID', defaultValue: env.Build_ID, description: 'Package build ID e.g: 1'),
      choice(name: 'Stack_Name', choices: env.Stack_Name, description: 'Stack Name e.g: stream1'),
      choice(name: 'App_Name', choices: "All\nAEM\nAPI\n", description: 'Application Name e.g: AEM (Author and Publisher) API (Mule and Tomcat)')
    ])
  ])

  // Check if build exist in Nexus
  stage('Check Build on Nexus') {

    if ( "$JOB_NAME" =~ /Stream1-Dev/ ) {
      env.Env_Repo = 'stream1-dev'
    }
    else if ("$JOB_NAME" =~ /Stream23-Dev/ ){
            env.Env_Repo = 'stream23-dev'
    }
    else if ("$JOB_NAME" =~ /Stream10-Dev/ ){
            env.Env_Repo = 'stream10-dev'
    }
    else if ("$JOB_NAME" =~ /Stream13-Dev/ ){
            env.Env_Repo = 'stream13-apigeemigration'
    }
    else {
      env.Env_Repo = Stack_Name
    }

    wrap([$class: 'AnsiColorBuildWrapper']) {
      println "${bold}Check Build on Nexus: ${green}Checking the Nexus for build ${Version_ID}-${BUILD_ID} ${reset}"
      sh '''
        set +x
        if [[ ${App_Name} == "All" || ${App_Name} == "AEM" ]]; then
          if ! [[ `wget -S --spider "https://nexus.helios-aws.com/service/local/artifact/maven/redirect?r=${Env_Repo}&g=com.digitaslbi.helios&a=helios-id-aem&v=build-${BUILD_ID}-${Version_ID}&p=zip" 2>&1 | grep 'HTTP/1.1 200 OK'` ]]; then
            echo "\u001B[31m --- The ${Version_ID} #${BUILD_ID} doesn't exist in Nexus --- \u001B[0m"
            exit 1
          elif ! [[ `wget -S --spider "https://nexus.helios-aws.com/service/local/artifact/maven/redirect?r=${Env_Repo}&g=com.digitaslbi.helios&a=helios-website&v=build-${BUILD_ID}-${Version_ID}&p=zip" 2>&1 | grep 'HTTP/1.1 200 OK'` ]]; then
            echo "\u001B[31m --- The ${Version_ID} #${BUILD_ID} doesn't exist in Nexus --- \u001B[0m"
            exit 1
          fi
        fi
        if [[ ${App_Name} == "All" || ${App_Name} == "API" ]]; then
          if ! [[ `wget -S --spider "https://nexus.helios-aws.com/service/local/artifact/maven/redirect?r=${Env_Repo}&g=com.digitaslbi.helios&a=helios-mule-accessories&v=build-${BUILD_ID}-${Version_ID}&p=zip" 2>&1 | grep 'HTTP/1.1 200 OK'` ]]; then
            echo "\u001B[31m --- The ${Version_ID} #${BUILD_ID} doesn't exist in Nexus --- \u001B[0m"
            exit 1
          elif ! [[ `wget -S --spider "https://nexus.helios-aws.com/service/local/artifact/maven/redirect?r=${Env_Repo}&g=com.digitaslbi.helios&a=helios-mule-specs&v=build-${BUILD_ID}-${Version_ID}&p=zip" 2>&1 | grep 'HTTP/1.1 200 OK'` ]]; then
            echo "\u001B[31m --- The ${Version_ID} #${BUILD_ID} doesn't exist in Nexus --- \u001B[0m"
            exit 1
          elif ! [[ `wget -S --spider "https://nexus.helios-aws.com/service/local/artifact/maven/redirect?r=${Env_Repo}&g=com.digitaslbi.helios&a=helios-api-authorisation&v=build-${BUILD_ID}-${Version_ID}&p=war" 2>&1 | grep 'HTTP/1.1 200 OK'` ]]; then
            echo "\u001B[31m --- The ${Version_ID} #${BUILD_ID} doesn't exist in Nexus --- \u001B[0m"
            exit 1
          elif ! [[ `wget -S --spider "https://nexus.helios-aws.com/service/local/artifact/maven/redirect?r=${Env_Repo}&g=com.digitaslbi.helios&a=helios-api-bundle&v=build-${BUILD_ID}-${Version_ID}&p=war" 2>&1 | grep 'HTTP/1.1 200 OK'` ]]; then
            echo "\u001B[31m --- The ${Version_ID} #${BUILD_ID} doesn't exist in Nexus --- \u001B[0m"
            exit 1
          fi
        fi
      '''
    }
  }

  // AEM-Stack|API-Stack
  env.Dev_Chef_Node_Search = 'chef_environment:' + 'use1dev*' + env.Stack_Name + ' AND name:*' + env.Stack_Name + '*'
  env.Qa_Chef_Node_Search = 'chef_environment:' + 'use1qa*' + env.Stack_Name + ' AND name:*' + env.Stack_Name + '*'
  env.Uat_Chef_Node_Search = 'chef_environment:' + 'use1uat*' + env.Stack_Name + ' AND name:*' + env.Stack_Name + '*'

  stage('Checkout') {
    wrap([$class: 'AnsiColorBuildWrapper']) {
      println "${bold}Checkout: ${green}Checkout the configuration repository ${reset}"
      // Checkout configuration repository
      checkout changelog: false, poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']],
      doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'WipeWorkspace']], submoduleCfg: [],
      userRemoteConfigs: [[credentialsId: '', url: '']]]
    }
  }

  stage('Install Bundles and Update Databag') {
    withEnv(["PATH=/var/lib/jenkins/.rbenv/shims:/var/lib/jenkins/.rbenv/bin:/var/lib/jenkins/.rbenv/plugins/ruby_build/bin:/usr/local/bin:/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/sbin"]) {
      wrap([$class: 'AnsiColorBuildWrapper']) {
        println "${bold}Install Bundles and Update Databag: ${green}Installing Chef bundles ${reset}"
        sh '''
          set +x
          cd chef-server
          BUNDLE_GEMFILE=Gemfile_for_knife_pipeline bundle install --path /var/lib/jenkins/pipelines-bundle-path
          rbenv rehash
        '''

        // Push databag changes to chef server
        println "${bold}Install Bundles and Update Databag: ${green}Updating the Chef server ${Stack_Name} Databag with build ${Version_ID}-${BUILD_ID} ${reset}"
        sh '''
          set +x
          cd chef-server
          envs=( "use1dev" )
          for env in "${envs[@]}"; do
            if [[ ${App_Name} == "All" || ${App_Name} == "AEM" ]]; then
              BUNDLE_GEMFILE=Gemfile_for_knife_pipeline bundle exec knife exec ../helios-pipeline/set_packages_data_bag.rb author $env-${Stack_Name} ${Version_ID} ${BUILD_ID} || exit 1
              BUNDLE_GEMFILE=Gemfile_for_knife_pipeline bundle exec knife exec ../helios-pipeline/set_packages_data_bag.rb publish $env-${Stack_Name} ${Version_ID} ${BUILD_ID} || exit 1
            fi
            if [[ ${App_Name} == "All" || ${App_Name} == "API" ]]; then
              BUNDLE_GEMFILE=Gemfile_for_knife_pipeline bundle exec knife exec ../helios-pipeline/set_packages_data_bag.rb helios-api $env-${Stack_Name} ${Version_ID} ${BUILD_ID} || exit 1
              BUNDLE_GEMFILE=Gemfile_for_knife_pipeline bundle exec knife exec ../helios-pipeline/set_packages_data_bag.rb mule-esb $env-${Stack_Name} ${Version_ID} ${BUILD_ID} || exit 1
            fi
          done
        '''

        // Commit and Push "version_id and build_id" change to databag in git configuration repo
        println "${bold}Install Bundles and Update Databag: ${green}Downloading the ${Stack_Name} Databags changes from Chef server ${reset}"
        sh '''
          set +x
          cd chef
          envs=( "use1dev" )
          for env in "${envs[@]}"; do
            if [[ ${App_Name} == "All" || ${App_Name} == "AEM" ]]; then
              BUNDLE_GEMFILE=../chef-server/Gemfile_for_knife_pipeline bundle exec knife download data_bags/$env-${Stack_Name}/author.json --chef-repo-path .
              BUNDLE_GEMFILE=../chef-server/Gemfile_for_knife_pipeline bundle exec knife download data_bags/$env-${Stack_Name}/publish.json --chef-repo-path .
            fi
            if [[ ${App_Name} == "All" || ${App_Name} == "API" ]]; then
              BUNDLE_GEMFILE=../chef-server/Gemfile_for_knife_pipeline bundle exec knife download data_bags/$env-${Stack_Name}/helios-api.json --chef-repo-path .
              BUNDLE_GEMFILE=../chef-server/Gemfile_for_knife_pipeline bundle exec knife download data_bags/$env-${Stack_Name}/mule-esb.json --chef-repo-path .
            fi
          done
        '''

        println "${bold}Install Bundles and Update Databag: ${green}Commit and Push Databags changes to configuration repository ${reset}"
        withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: '',
        usernameVariable: 'GIT_USERNAME', passwordVariable: 'GIT_PASSWORD']]) {
          sh '''
            set +x
            git checkout master
            cd chef
            echo 'Git status is :'
            git status --porcelain
            if [[ `git status --porcelain` ]]; then
              echo 'Pushing data bags changes to master'
              git remote add central https://${GIT_USERNAME}:${GIT_PASSWORD}@gitlab.helios-aws.com/helios/ops/configuration.git
              git config --global user.name "Helios Pipeline"
              git config --global user.email dev.ops@heliosalliance.net
              envs=( "use1dev" )
              for env in "${envs[@]}"; do
                if [[ ${App_Name} == "All" || ${App_Name} == "AEM" ]]; then
                  git add data_bags/$env-${Stack_Name}/author.json
                  git add data_bags/$env-${Stack_Name}/publish.json
                fi
                if [[ ${App_Name} == "All" || ${App_Name} == "API" ]]; then
                  git add data_bags/$env-${Stack_Name}/helios-api.json
                  git add data_bags/$env-${Stack_Name}/mule-esb.json
                fi
              done
              git commit -m "Version bump to ${Version_ID} build ${BUILD_ID} on ${Stack_Name} DEV"
              git pull
              git push origin master
            fi
          '''
        }
      }
    }
  }

  stage('Deploying to Dev-Stream') {
    withEnv(["PATH=/var/lib/jenkins/.rbenv/shims:/var/lib/jenkins/.rbenv/bin:/var/lib/jenkins/.rbenv/plugins/ruby_build/bin:/usr/local/bin:/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/sbin"]) {
      dir('chef-server') {
        wrap([$class: 'AnsiColorBuildWrapper']) {
          // running converge (chef-client) on node through pushy job
          if ( App_Name == "All" || App_Name == "AEM") {
            println "${bold}Deploying to Dev-Stream: ${green}Deploying build ${Version_ID}-${BUILD_ID} on AEM Author and Publisher${reset}"
            sh '#!/bin/sh +x\n' + 'BUNDLE_GEMFILE=Gemfile_for_knife_pipeline bundle exec knife job start chef-client -s "${Dev_Chef_Node_Search}"'

            println "${bold}Deploying to Dev-Stream: ${green}Clearing cache on the Publisher${reset}"
            sh '#!/bin/sh +x\n' + 'BUNDLE_GEMFILE=Gemfile_for_knife_pipeline bundle exec knife job start dispatcher_cache_clearing -s "${Dev_Chef_Node_Search}"'
          }

          if ( App_Name == "All" || App_Name == "API") {
            println "${bold}Deploying to Dev-Stream: ${green}Deploying build ${Version_ID}-${BUILD_ID} on Tomcat API and Mule${reset}"
            sh '#!/bin/sh +x\n' + 'BUNDLE_GEMFILE=Gemfile_for_knife_pipeline bundle exec knife job start chef-client-helios-api -s "${Dev_Chef_Node_Search}"'
          }
        }
      }
    }
  }

  stage('Test: Dev-Stream') {
    withEnv(["PATH=/var/lib/jenkins/.rbenv/shims:/var/lib/jenkins/.rbenv/bin:/var/lib/jenkins/.rbenv/plugins/ruby_build/bin:/usr/local/bin:/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/sbin"]) {
      wrap([$class: 'AnsiColorBuildWrapper']) {
        withCredentials([file(credentialsId: '', variable: 'SECRET_FILE'),
        string(credentialsId: '', variable: 'SECRET_USER')]) {
          sh '''
            set +x

            pass=$(knife data bag show -F json use1dev-${Stack_Name} aem_credentials 2>/dev/null | jq .admin.password | tr -d '"')
            if [ ! "$pass" ];then
              pass="admin"
            fi

            nodename=$(knife ssh -a ipaddress -i ${SECRET_FILE} -x ${SECRET_USER} "${Dev_Chef_Node_Search}" "hostname")
            echo "\u001B[1m\nTest: Dev-Stream: \u001B[32m NodeName-$nodename\u001B[0m"

            #### Testing Author
            if [[ ${App_Name} == "All" || ${App_Name} == "AEM" ]]; then
              echo "\u001B[1m\nTest: Dev-Stream:\u001B[32m Checking bundles to get version ${Version_ID}-${BUILD_ID} on Author\u001B[0m"

              bundles=( "abres" "admin" "api-model" "tooling" "web" "webrender" )
              for bundle in "${bundles[@]}"; do
                output=$(knife ssh -a ipaddress -i ${SECRET_FILE} -x ${SECRET_USER} "${Dev_Chef_Node_Search}" "curl -s -u admin:$pass http://localhost:4502/system/console/bundles/com.digitaslbi.helios.$bundle" | sed -n 's/.*\\(\\"Bnd-LastModified.*\\"\\),\\"Created-By.*/\\1/p')

                if ! [[ $output =~ "BuildId: ${BUILD_ID}" && $output =~ "Bundle-Version: ${Version_ID}" ]]; then
                  echo "\u001B[31m --- The Snapshot doesn't match with Version and Build ID on Author --- \u001B[0m"
                  #exit 1
                else
                  echo "\u001B[32m --- The com.digitaslbi.helios.$bundle ${Version_ID} - ${BUILD_ID} bundle on Author has been deployed --- \u001B[0m"
                fi
              done
            fi

            #### Testing Publisher
            if [[ ${App_Name} == "All" || ${App_Name} == "AEM" ]]; then
              echo "\u001B[1m\nTest: Dev-Stream:\u001B[32m Checking bundles to get version ${Version_ID}-${BUILD_ID} on Publisher\u001B[0m"

              bundles=( "abres" "admin" "api-model" "tooling" "web" "webrender" )
              for bundle in "${bundles[@]}"; do
                output=$(knife ssh -a ipaddress -i ${SECRET_FILE} -x ${SECRET_USER} "${Dev_Chef_Node_Search}" "curl -s -u admin:$pass http://localhost:4503/system/console/bundles/com.digitaslbi.helios.$bundle" | sed -n 's/.*\\(\\"Bnd-LastModified.*\\"\\),\\"Created-By.*/\\1/p')

                if ! [[ $output =~ "BuildId: ${BUILD_ID}" && $output =~ "Bundle-Version: ${Version_ID}" ]]; then
                  echo "\u001B[31m --- The Snapshot doesn't match with Version and Build ID on Publisher --- \u001B[0m"
                  #exit 1
                else
                  echo "\u001B[32m --- The com.digitaslbi.helios.$bundle ${Version_ID} - ${BUILD_ID} bundle on Publisher has been deployed --- \u001B[0m"
                fi
              done
            fi

            #### Testing Helios-API
            if [[ ${App_Name} == "All" || ${App_Name} == "API" ]]; then
              echo "\u001B[1m\nTest: Dev-Stream:\u001B[32m Checking version ${Version_ID}-${BUILD_ID} on Helios-API\u001B[0m"
              nodenames=$(knife ssh -a ipaddress -i ${SECRET_FILE} -x ${SECRET_USER} "${Dev_Chef_Node_Search}" "hostname")

              while read nodename; do
                nodename=$(echo $nodename | tr -d '\r' | awk '{print $2}')
                data_bag_items=$(knife exec helios-pipeline/get_databag_items.rb use1dev-${Stack_Name} helios-api "name")
                while read itemname; do
                  if ! [[ $itemname == "helios-api-offers-dma" ]]; then
                    healthcheck=$(knife ssh -a ipaddress -i ${SECRET_FILE} -x ${SECRET_USER} "name:$nodename" "curl -s http://localhost:8080/$itemname/healthcheck && echo")
                    if ! [[ $healthcheck =~ ${Version_ID}.build-${BUILD_ID} ]]; then
                      echo "\u001B[31m --- $itemname: The Build doesn't match with Version and Build ID --- \u001B[0m"
                      #### exit 1
                    else
                      echo "\u001B[32m --- $itemname: The package ${Version_ID} - ${BUILD_ID} has been deployed --- \u001B[0m"
                    fi
                  fi
                done <<< "$data_bag_items"
              done <<< "$nodenames"
            fi

            #### Testing Mule
            if [[ ${App_Name} == "All" || ${App_Name} == "API" ]]; then
              nodename=$(knife ssh -a ipaddress -i ${SECRET_FILE} -x ${SECRET_USER} "${Dev_Chef_Node_Search}" "hostname")
              data_bag_items=$(knife exec helios-pipeline/get_databag_items.rb use1dev-${Stack_Name} mule-esb "name")

              echo "\u001B[1m\nTest: Dev-Stream:\u001B[32m Checking version ${Version_ID}-${BUILD_ID} on Mule\u001B[0m"

              while read itemname; do
                output=$(knife ssh -a ipaddress -i ${SECRET_FILE} -x ${SECRET_USER} "${Dev_Chef_Node_Search}" "grep -r '${Version_ID}.build-${BUILD_ID}' /opt/mule/apps/$itemname" | cut -d = -f2)

                if ! [[ $output =~ ^${Version_ID}.build-${BUILD_ID} ]]; then
                  echo "\u001B[31m --- $itemname: The Build doesn't match with Version and Build ID --- \u001B[0m"
                  #### exit 1
                else
                  echo "\u001B[32m --- $itemname: The package ${Version_ID} - ${BUILD_ID} has deployed --- \u001B[0m"
                fi
              done <<< "$data_bag_items"
            fi
          '''
        }
      }
    }
  }

  step([$class: 'WsCleanup'])
  deleteDir()
}
