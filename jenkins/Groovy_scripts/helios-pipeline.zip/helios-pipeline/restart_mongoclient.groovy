#!groovy

node {
  currentBuild.description = "${Stream_Number}-${Env_Type}"
  deleteDir()

  properties([ parameters([choice(choices: "stream1\nstream2\nstream3\nstream4\nstream5\nstream6\nstream7\nstream8\nstream9\nstream10\nstream11\nstream12\nstream13\nstream14\nstream15\nstream16\nstream17\nstream18\nstream19\nstream20\nstream21\nstream22\nstream23\nstream24\nstream25",
  description: 'Select the stream name', name: 'Stream_Number'),
  choice(choices: "QA\nDev\nUAT\n", description: 'Select the environment', name: 'Env_Type')])
  ])

  env.QA_Stream_Name = 'chef_environment:' + 'use1qa*' + env.Stream_Number + ' AND name:*' + env.Stream_Number + '*'
  env.Dev_Stream_Name = 'chef_environment:' + 'use1dev*' + env.Stream_Number + ' AND name:*' + env.Stream_Number + '*'
  env.UAT_Stream_Name = 'chef_environment:' + 'use1uat*' + env.Stream_Number + ' AND name:*' + env.Stream_Number + '*'

  stage('Checkout') {
    checkout changelog: false, poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']],
    doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'WipeWorkspace']], submoduleCfg: [],
    userRemoteConfigs: [[credentialsId: '', url: '']]]
  }

  stage('Install Bundles') {
    withEnv(["PATH=/var/lib/jenkins/.rbenv/shims:/var/lib/jenkins/.rbenv/bin:/var/lib/jenkins/.rbenv/plugins/ruby_build/bin:/usr/local/bin:/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/sbin"]) {
      sh '''
        set +x
        cd chef-server
        BUNDLE_GEMFILE=Gemfile_for_knife_pipeline bundle install --path /var/lib/jenkins/pipelines-bundle-path
        rbenv rehash
      '''
    }
  }

  stage('restart mongo client') {
    withEnv(["PATH=/var/lib/jenkins/.rbenv/shims:/var/lib/jenkins/.rbenv/bin:/var/lib/jenkins/.rbenv/plugins/ruby_build/bin:/usr/local/bin:/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/sbin"]) {
      dir('chef-server') {
        sh '''
          set +x
          echo "JOB_NAME from env: ${Stream_Number}"
          if [ "${Env_Type}" == 'Dev' ]; then
            BUNDLE_GEMFILE=Gemfile_for_knife_pipeline bundle exec knife job start restart-mongoclient -s ${Dev_Stream_Name}
            exitcode=$?
          elif [ "${Env_Type}" == 'QA' ]; then
            BUNDLE_GEMFILE=Gemfile_for_knife_pipeline bundle exec knife job start restart-mongoclient -s ${QA_Stream_Name}
            exitcode=$?
          elif [ "${Env_Type}" == 'UAT' ]; then
            BUNDLE_GEMFILE=Gemfile_for_knife_pipeline bundle exec knife job start restart-mongoclient -s ${UAT_Stream_Name}
            exitcode=$?
          fi
          if [ "$exitcode" -ne "0" ] ; then
            echo "Cannot restart mongo client on ${Stream_Number}, please reachout to DevOps"
            exit 1
          fi
        '''
       }
     }
   }

   step([$class: 'WsCleanup'])
   deleteDir()
}
