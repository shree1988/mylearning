#!groovy

node {
  currentBuild.description = "${Stream_Number}"
  deleteDir()

  properties([ parameters([choice(choices: "use1dev1-bae\nuse1dev2-bae\nuse1dev3-bae\nuse1int-bae\nuse1qa-bae\nuse1int-hf\nuse1qa-hf\n",  description: 'Select the stream name', name: 'Stream_Number')])
  ])

  env.TARGET_Stream_Name = 'chef_environment:'+ env.Stream_Number

  stage('Checkout') {
    checkout changelog: false, poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']],
    doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'WipeWorkspace']], submoduleCfg: [],
    userRemoteConfigs: [[credentialsId: '97c54a1a-01f7-44f1-88b8-b88740cd3d1a', url: 'https://gitlab.helios-aws.com/helios/ops/configuration.git']]]
  }

  stage('Install Bundles') {
    withEnv(["PATH=/var/lib/jenkins/.rbenv/shims:/var/lib/jenkins/.rbenv/bin:/var/lib/jenkins/.rbenv/plugins/ruby_build/bin:/usr/local/bin:/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/sbin"]) {
      sh '''
        set +x
        cd chef-server
        BUNDLE_GEMFILE=Gemfile_for_knife_pipeline bundle install --path /var/lib/jenkins/pipelines-bundle-path
        rbenv rehash
      '''
    }
  }

  stage('clear the dispatcher cache') {
    withEnv(["PATH=/var/lib/jenkins/.rbenv/shims:/var/lib/jenkins/.rbenv/bin:/var/lib/jenkins/.rbenv/plugins/ruby_build/bin:/usr/local/bin:/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/sbin"]) {
      dir('chef-server') {
        sh '''
          set +x
          echo "JOB_NAME from env: ${Stream_Number}"
          BUNDLE_GEMFILE=Gemfile_for_knife_pipeline bundle exec knife job start dispatcher_cache_clearing -s ${TARGET_Stream_Name}
          exitcode=$?
          if [ "$exitcode" -ne "0" ] ; then
            echo "Issue with clearing cache on ${Stream_Number}, please reachout to DevOps"
            exit 1
          fi
        '''
       }
     }
   }

   step([$class: 'WsCleanup'])
   deleteDir()
}
