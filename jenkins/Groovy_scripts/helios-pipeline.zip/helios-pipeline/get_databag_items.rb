environment = ARGV[2]
databag_category = ARGV[3]
item = ARGV[4]

if databag_category == 'helios-api'
  categories = 'tomcat_applications'
elsif databag_category == 'mule-esb'
  categories = 'mule_applications'
else
  categories = databag_category
end

chef = data_bag_item(environment, databag_category)

chef[categories].each do |category|
  puts category[item]
end

exit 0
