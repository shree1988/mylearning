#!groovy

env.Version_ID = params.Version_ID
env.Build_ID = params.Build_ID
env.Stack_Name = params.Stack_Name

if ( env.Stack_Name =~ /Prod/ ) {
  error 'you are not allowed to use this environment'
}

if ( params.Version_ID != null || params.Build_ID != null || params.Stack_Name != null ) {

  properties([
    parameters([
      string(name: 'Version_ID', defaultValue: env.Version_ID, description: 'Package version ID e.g: 17.1.0-SNAPSHOT'),
      string(name: 'Build_ID', defaultValue: env.Build_ID, description: 'Package build ID e.g: 1'),
      choice(name: 'Stack_Name', choices: env.Stack_Name, description: 'Stack Name e.g: stream1')
    ])
  ])

  node {
    // Wipe the workspace so we are building completely clean
    deleteDir()

    // Check if build exist in Nexus
    stage('Check Build on Nexus') {
      wrap([$class: 'AnsiColorBuildWrapper']) {
        sh '''
          #set +x
          if ! [[ `wget -S --spider "https://nexus.helios-aws.com/service/local/artifact/maven/redirect?r=${Stack_Name}-dev&g=com.digitaslbi.helios&a=helios-id-aem&v=build-${BUILD_ID}-${Version_ID}&p=zip" 2>&1 | grep 'HTTP/1.1 200 OK'` ]]; then
            echo "\u001B[31m --- The ${Version_ID} #${BUILD_ID} doesn't exist in Nexus --- \u001B[0m"
            exit 1
          elif ! [[ `wget -S --spider "https://nexus.helios-aws.com/service/local/artifact/maven/redirect?r=${Stack_Name}-dev&g=com.digitaslbi.helios&a=helios-website&v=build-${BUILD_ID}-${Version_ID}&p=zip" 2>&1 | grep 'HTTP/1.1 200 OK'` ]]; then
            echo "\u001B[31m --- The ${Version_ID} #${BUILD_ID} doesn't exist in Nexus --- \u001B[0m"
            exit 1
          elif ! [[ `wget -S --spider "https://nexus.helios-aws.com/service/local/artifact/maven/redirect?r=${Stack_Name}-dev&g=com.digitaslbi.helios&a=helios-mule-accessories&v=build-${BUILD_ID}-${Version_ID}&p=zip" 2>&1 | grep 'HTTP/1.1 200 OK'` ]]; then
            echo "\u001B[31m --- The ${Version_ID} #${BUILD_ID} doesn't exist in Nexus --- \u001B[0m"
            exit 1
          elif ! [[ `wget -S --spider "https://nexus.helios-aws.com/service/local/artifact/maven/redirect?r=${Stack_Name}-dev&g=com.digitaslbi.helios&a=helios-mule-specs&v=build-${BUILD_ID}-${Version_ID}&p=zip" 2>&1 | grep 'HTTP/1.1 200 OK'` ]]; then
            echo "\u001B[31m --- The ${Version_ID} #${BUILD_ID} doesn't exist in Nexus --- \u001B[0m"
            exit 1
          elif ! [[ `wget -S --spider "https://nexus.helios-aws.com/service/local/artifact/maven/redirect?r=${Stack_Name}-dev&g=com.digitaslbi.helios&a=helios-api-authorisation&v=build-${BUILD_ID}-${Version_ID}&p=war" 2>&1 | grep 'HTTP/1.1 200 OK'` ]]; then
            echo "\u001B[31m --- The ${Version_ID} #${BUILD_ID} doesn't exist in Nexus --- \u001B[0m"
            exit 1
          elif ! [[ `wget -S --spider "https://nexus.helios-aws.com/service/local/artifact/maven/redirect?r=${Stack_Name}-dev&g=com.digitaslbi.helios&a=helios-api-bundle&v=build-${BUILD_ID}-${Version_ID}&p=war" 2>&1 | grep 'HTTP/1.1 200 OK'` ]]; then
            echo "\u001B[31m --- The ${Version_ID} #${BUILD_ID} doesn't exist in Nexus --- \u001B[0m"
            exit 1
          fi
        '''
      }
    }

    // AEM-Stack|API-Stack
    env.Dev_Chef_Node_Search = 'chef_environment:' + 'use1dev*' + env.Stack_Name + ' AND name:*' + env.Stack_Name + '*'
    env.Qa_Chef_Node_Search = 'chef_environment:' + 'use1qa*' + env.Stack_Name + ' AND name:*' + env.Stack_Name + '*'
    env.Uat_Chef_Node_Search = 'chef_environment:' + 'use1uat*' + env.Stack_Name + ' AND name:*' + env.Stack_Name + '*'

    stage('Checkout') {
      // Checkout configuration repository
      checkout changelog: false, poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']],
      doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'WipeWorkspace']], submoduleCfg: [],
      userRemoteConfigs: [[credentialsId: '', url: '']]]
    }

    stage('Install Bundles and Update Databag') {
      withEnv(["PATH=/var/lib/jenkins/.rbenv/shims:/var/lib/jenkins/.rbenv/bin:/var/lib/jenkins/.rbenv/plugins/ruby_build/bin:/usr/local/bin:/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/sbin"]) {
        sh '''
          #set +x
          cd chef-server
          BUNDLE_GEMFILE=Gemfile_for_knife_pipeline bundle install --path /var/lib/jenkins/pipelines-bundle-path
          rbenv rehash
        '''

        // Push databag changes to chef server
        sh '''
        #set +x
          cd chef-server
          envs=( "use1dev" )
          for env in "${envs[@]}"; do
            BUNDLE_GEMFILE=Gemfile_for_knife_pipeline bundle exec knife exec ../helios-pipeline/set_packages_data_bag.rb author $env-${Stack_Name} ${Version_ID} ${BUILD_ID} || exit 1
            BUNDLE_GEMFILE=Gemfile_for_knife_pipeline bundle exec knife exec ../helios-pipeline/set_packages_data_bag.rb publish $env-${Stack_Name} ${Version_ID} ${BUILD_ID} || exit 1
            BUNDLE_GEMFILE=Gemfile_for_knife_pipeline bundle exec knife exec ../helios-pipeline/set_packages_data_bag.rb helios-api $env-${Stack_Name} ${Version_ID} ${BUILD_ID} || exit 1
            BUNDLE_GEMFILE=Gemfile_for_knife_pipeline bundle exec knife exec ../helios-pipeline/set_packages_data_bag.rb mule-esb $env-${Stack_Name} ${Version_ID} ${BUILD_ID} || exit 1
          done
        '''

        // Commit and Push "version_id and build_id" change to databag in git configuration repo
        sh '''
          #set +x
          cd chef
          envs=( "use1dev" )
          for env in "${envs[@]}"; do
            BUNDLE_GEMFILE=../chef-server/Gemfile_for_knife_pipeline bundle exec knife download data_bags/$env-${Stack_Name}/author.json --chef-repo-path .
            BUNDLE_GEMFILE=../chef-server/Gemfile_for_knife_pipeline bundle exec knife download data_bags/$env-${Stack_Name}/publish.json --chef-repo-path .
            BUNDLE_GEMFILE=../chef-server/Gemfile_for_knife_pipeline bundle exec knife download data_bags/$env-${Stack_Name}/helios-api.json --chef-repo-path .
            BUNDLE_GEMFILE=../chef-server/Gemfile_for_knife_pipeline bundle exec knife download data_bags/$env-${Stack_Name}/mule-esb.json --chef-repo-path .
          done
        '''

        withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: '',
        usernameVariable: 'GIT_USERNAME', passwordVariable: 'GIT_PASSWORD']]) {
          sh '''
            #set +x
            git checkout master
            cd chef
            echo 'Git status is :'
            git status --porcelain
            if [[ `git status --porcelain` ]]; then
              echo 'Pushing data bags changes to master'
              git remote add central https://${GIT_USERNAME}:${GIT_PASSWORD}@gitlab.helios-aws.com/helios/ops/configuration.git
              git config --global user.name "Helios Pipeline"
              git config --global user.email dev.ops@heliosalliance.net
              envs=( "use1dev" )
              for env in "${envs[@]}"; do
                git add data_bags/$env-${Stack_Name}/author.json
                git add data_bags/$env-${Stack_Name}/publish.json
                git add data_bags/$env-${Stack_Name}/helios-api.json
                git add data_bags/$env-${Stack_Name}/mule-esb.json
              done
              git commit -m "Version bump to ${Version_ID} build ${BUILD_ID} on ${Stack_Name} DEV"
              git pull
              git push origin master
            fi
          '''
        }
      }
    }

    stage('Deploying to Dev-Stream') {
      withEnv(["PATH=/var/lib/jenkins/.rbenv/shims:/var/lib/jenkins/.rbenv/bin:/var/lib/jenkins/.rbenv/plugins/ruby_build/bin:/usr/local/bin:/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/sbin"]) {
        dir('chef-server') {
          // running converge (chef-client) on node through pushy job
          sh '''
            #set +x
            BUNDLE_GEMFILE=Gemfile_for_knife_pipeline bundle exec knife job start chef-client -s "${Dev_Chef_Node_Search}"
            exitcode1=$?

            BUNDLE_GEMFILE=Gemfile_for_knife_pipeline bundle exec knife job start chef-client-helios-api -s "${Dev_Chef_Node_Search}"
            exitcode2=$?

            if [[ "$exitcode1" -ne "0" || "$exitcode2" -ne "0" ]] ; then
              echo "Issue with converging the node, please check the logs uploaded"
              exit 1
            fi

            BUNDLE_GEMFILE=Gemfile_for_knife_pipeline bundle exec knife job start dispatcher_cache_clearing -s "${Dev_Chef_Node_Search}"
            exitcode=$?

            if [ "$exitcode" -ne "0" ] ; then
              echo "Issue with clearing cache on ${Stack_Name}, please check the logs uploaded"
              exit 1
            fi
          '''
        }
      }
    }

    stage('Test: Dev-Stream') {
      withEnv(["PATH=/var/lib/jenkins/.rbenv/shims:/var/lib/jenkins/.rbenv/bin:/var/lib/jenkins/.rbenv/plugins/ruby_build/bin:/usr/local/bin:/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/sbin"]) {
        wrap([$class: 'AnsiColorBuildWrapper']) {
          withCredentials([file(credentialsId: '', variable: 'SECRET_FILE'),
          string(credentialsId: '', variable: 'SECRET_USER')]) {
            sh '''
              ##set +x

              nodename=$(knife ssh -a ipaddress -i ${SECRET_FILE} -x ${SECRET_USER} "${Dev_Chef_Node_Search}" "hostname")
              echo "\u001B[31m\nNodeName-$nodename\u001B[0m"

              #### Testing Publishers
              echo "\u001B[31m\nTesting Publisher:\u001B[0m"
              bundles=( "abres" "admin" "api-model" "tooling" "web" "webrender" )
              for bundle in "${bundles[@]}"; do
                output=$(knife ssh -a ipaddress -i ${SECRET_FILE} -x ${SECRET_USER} "${Dev_Chef_Node_Search}" "curl -s -u admin:admin http://localhost:4502/system/console/bundles/com.digitaslbi.helios.$bundle" | sed -n 's/.*\\(\\"Bnd-LastModified.*\\"\\),\\"Created-By.*/\\1/p')

                ### This one need more test
                aembundlever=$(echo ${Version_ID} | sed -E -e 's/-SNAPSHOT/.SNAPSHOT/g')

                if ! [[ $output =~ "BuildId: ${BUILD_ID}" && $output =~ "Bundle-Version: ${aembundlever}" ]]; then
                  echo "\u001B[31m --- The Snapshot doesn't match with Version and Build ID on Author --- \u001B[0m"
                  #exit 1
                else
                  echo "\u001B[32m --- The com.digitaslbi.helios.$bundle ${Version_ID} - ${BUILD_ID} bundle on Author has been deployed --- \u001B[0m"
                fi
              done

              #### Testing Author
              echo "\u001B[31m\nTesting Author:\u001B[0m"

              bundles=( "abres" "admin" "api-model" "tooling" "web" "webrender" )
              for bundle in "${bundles[@]}"; do
                output=$(knife ssh -a ipaddress -i ${SECRET_FILE} -x ${SECRET_USER} "${Dev_Chef_Node_Search}" "curl -s -u admin:admin http://localhost:4503/system/console/bundles/com.digitaslbi.helios.$bundle" | sed -n 's/.*\\(\\"Bnd-LastModified.*\\"\\),\\"Created-By.*/\\1/p')

                ### This one need more test
                aembundlever=$(echo ${Version_ID} | sed -E -e 's/-SNAPSHOT/.SNAPSHOT/g')

                if ! [[ $output =~ "BuildId: ${BUILD_ID}" && $output =~ "Bundle-Version: ${aembundlever}" ]]; then
                  echo "\u001B[31m --- The Snapshot doesn't match with Version and Build ID on Publisher --- \u001B[0m"
                  #exit 1
                else
                  echo "\u001B[32m --- The com.digitaslbi.helios.$bundle ${Version_ID} - ${BUILD_ID} bundle on Publisher has been deployed --- \u001B[0m"
                fi
              done

              #### Testing Helios-API
              echo "\u001B[31m\nTesting Helios-API:\u001B[0m"
              nodenames=$(knife ssh -a ipaddress -i ${SECRET_FILE} -x ${SECRET_USER} "${Dev_Chef_Node_Search}" "hostname")

              while read nodename; do
                nodename=$(echo $nodename | tr -d '\r' | awk '{print $2}')
                data_bag_items=$(knife exec helios-pipeline/get_databag_items.rb use1dev-${Stack_Name} helios-api "name")
                while read itemname; do
                  if ! [[ $itemname == "helios-api-offers-dma" ]]; then
                    healthcheck=$(knife ssh -a ipaddress -i ${SECRET_FILE} -x ${SECRET_USER} "name:$nodename" "curl -s http://localhost:8080/$itemname/healthcheck && echo")
                    if ! [[ $healthcheck =~ ${Version_ID}.build-${BUILD_ID} ]]; then
                      echo "\u001B[31m --- $itemname: The Build doesn't match with Version and Build ID --- \u001B[0m"
                      echo "\u001B[31m --- The current Version and Build ID is: $healthcheck --- \u001B[0m"
                      #### exit 1
                    else
                      echo "\u001B[32m --- $itemname: The package ${Version_ID} - ${BUILD_ID} has been deployed --- \u001B[0m"
                    fi
                  fi
                done <<< "$data_bag_items"
              done <<< "$nodenames"

              #### Testing Mule
              echo "\u001B[31m\nTesting Mule:\u001B[0m"
              output=$(knife ssh -a ipaddress -i ${SECRET_FILE} -x ${SECRET_USER} "${Dev_Chef_Node_Search}" "head -1 /opt/mule/apps/helios-mule-specs/classes/helios-mule-specs.properties" | cut -d = -f2)
              nodename=$(knife ssh -a ipaddress -i ${SECRET_FILE} -x ${SECRET_USER} "${Dev_Chef_Node_Search}" "hostname")

              if ! [[ $output =~ ^${Version_ID}.build-${BUILD_ID} ]]; then
                echo "\u001B[31m --- The Build doesn't match with Version and Build ID --- \u001B[0m"
                echo "\u001B[31m --- The current Version and Build ID is: $output --- \u001B[0m"
                #### exit 1
              else
                echo "\u001B[32m --- The package ${Version_ID} - ${BUILD_ID} has been deployed --- \u001B[0m"
              fi
            '''
          }
        }
      }
    }

    step([$class: 'WsCleanup'])
    deleteDir()
  }
} else {
  // This project is parameterized
  stage('Create and Configure Pipeline') {
    def userInput = input(
      id: 'userInput', message: 'Please configure this job first!!', parameters: [
        [$class: 'TextParameterDefinition', name: 'VersionID', defaultValue: '', description: 'Package version ID e.g: 17.1.0-SNAPSHOT'],
        [$class: 'TextParameterDefinition', name: 'BuildID', defaultValue: '', description: 'Package build ID e.g: 1'],
        [$class: 'TextParameterDefinition', name: 'StackName', defaultValue: '', description: 'Stack Name e.g: stream1']
    ])

    properties([
      parameters([
        string(name: 'Version_ID', defaultValue: (userInput['VersionID']), description: 'Package version ID e.g: 17.1.0-SNAPSHOT'),
        string(name: 'Build_ID', defaultValue: (userInput['BuildID']), description: 'Package build ID e.g: 1'),
        choice(name: 'Stack_Name', choices: (userInput['StackName']), description: 'Stack Name e.g: stream1')
      ])
    ])

    echo "Pipeline has created, please configure build parameters"
  }
}
