#!groovy

env.Chef_ENV = params.Chef_ENV

if ( params.UserID != null || params.First_Name != null || params.Last_Name != null || params.Email_ID != null || params.Chef_ENV != null ) {

  properties([
    parameters([
	  string(name: 'UserID', defaultValue: env.UserID, description: 'Please enter the username as first.lastname e.g: aditya.chowhan'),
      string(name: 'First_Name', defaultValue: env.First_Name, description: 'Please enter the first name'),
	  string(name: 'Last_Name', defaultValue: env.Last_Name, description: 'Please enter the Last name'),
	  string(name: 'Email_ID', defaultValue: env.Email_ID, description: 'Please enter the email ID eg: username@<company>.com'),
	  choice(name: 'GroupID', choices: env.GroupID, description: 'Kindly select the group to which the access is needed e.g: authors-uat'),
      choice(name: 'Chef_ENV', choices: env.Chef_ENV, description: 'Which environment should be deploy. It should be our chef environment e.g: use1nisuat')
    ])
  ])

  node {

    // Wipe the workspace so we are building completely clean
    deleteDir()

    env.Chef_Node_Search = 'chef_environment:' + env.Chef_ENV + ' AND role:*aem-author* NOT role:aem-author-dispatcher*'

    stage('User Creation') {
    withEnv(["PATH=/var/lib/jenkins/.rbenv/shims:/var/lib/jenkins/.rbenv/bin:/var/lib/jenkins/.rbenv/plugins/ruby_build/bin:/usr/local/bin:/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/sbin"]) {
      wrap([$class: 'AnsiColorBuildWrapper']) {
        withCredentials([file(credentialsId: '', variable: 'SECRET_FILE'),
        string(credentialsId: '341a1310-b85a-4bdf-9e7f-1609533ccf6d', variable: 'SECRET_USER')]) {
          sh '''
            set +x
            knife ssh -a ipaddress -i ${SECRET_FILE} -x ${SECRET_USER} "${Chef_Node_Search}" "curl -k -u admin:admin -FcreateUser=${UserID} -FgivenName=${First_Name} -FfamilyName=${Last_Name} -Femail=${Email_ID} -FauthorizableId=${UserID} -Frep:password=password@123 -Fmembership=${GroupID} -Fmembership=everyone http://localhost:4502/libs/granite/security/post/authorizables"
  	        output=$(knife ssh -a ipaddress -i ${SECRET_FILE} -x ${SECRET_USER} "${Chef_Node_Search}" "curl -vv -Is -u ${UserID}:password@123 http://localhost:4502/libs/granite/security/post/authorizables -L | grep HTTP/ | awk '{ print $3 }'")
            echo " the test $output"
            ### This one for checking if the user is created correctly
            if ! [[ $output =~ "OK" ]]; then
              echo "\u001B[31m --- There is issue to create the user .... --- \u001B[0m"
              ### exit 1
            else
              echo "\u001B[32m --- The user: ${UserID} has created --- \u001B[0m"
            fi
          '''
        }
      }
		}
	}
  }
} else {
  // This project is parameterized
  stage('Create and Configure Pipeline') {
    def userInput = input(
      id: 'userInput', message: 'Please configure this job first!!', parameters: [
        [$class: 'TextParameterDefinition', name: 'ChefEnv', defaultValue: '', description: 'Environment, It should be our chef environment e.g: use1nisuat']
    ])

    properties([
      parameters([
        choice(name: 'Chef_ENV', choices: (userInput['ChefEnv']), description: 'Which environment should be deploy. It should be our chef environment e.g: use1nisuat')
      ])
    ])

    echo "Pipeline has created, please configure build parameters"
  }
}
