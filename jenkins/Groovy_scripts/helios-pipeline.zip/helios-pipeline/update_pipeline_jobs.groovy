#!groovy

if ( params.Running == "Yes" ) {

  node {
    stage('Checkout') {
      // Checkout configuration repository
      checkout changelog: false, poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']],
      doGenerateSubmoduleConfigurations: false, submoduleCfg: [],
      userRemoteConfigs: [[credentialsId: '', url: '']]]
    }

    stage('Install Bundles') {
      withEnv(["PATH=/var/lib/jenkins/.rbenv/shims:/var/lib/jenkins/.rbenv/bin:/var/lib/jenkins/.rbenv/plugins/ruby_build/bin:/usr/local/bin:/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/sbin"]) {
        sh '''
          set +x
          cd chef-server
          BUNDLE_GEMFILE=Gemfile_for_knife_pipeline bundle install --path /var/lib/jenkins/pipelines-bundle-path
          rbenv rehash
        '''
      }
    }

    stage('Updating Jobs') {
     withEnv(["PATH=/var/lib/jenkins/.rbenv/shims:/var/lib/jenkins/.rbenv/bin:/var/lib/jenkins/.rbenv/plugins/ruby_build/bin:/usr/local/bin:/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/sbin"]) {
       // Removing the jobs which doesn't exist in databag
       // withCredentials([usernamePassword(credentialsId: '', passwordVariable: 'JENKINS_PASS', usernameVariable: 'JENKINS_USER')]) {
       //   sh '''
       //     set +x
       //     current_jobs=$(java -jar /var/cache/jenkins/war/WEB-INF/jenkins-cli.jar -s http://localhost:8080 -auth ${JENKINS_USER}:${JENKINS_PASS} list-jobs all)
       //     data_bag_items=$(knife exec helios-pipeline/get_databag_items.rb pipeline pipelines "name")
       //
       //     diff=$(echo ${data_bag_items[@]} ${current_jobs[@]} | tr ' ' '\n' | sort | uniq -u)
       //
       //     while read jobname; do
       //       if ! [[ $jobname == "Update_Pipeline_Jobs" || $jobname =~ "Scheduled" ]]; then
       //         echo "Removing jobname: $jobname"
       //         java -jar /var/cache/jenkins/war/WEB-INF/jenkins-cli.jar -s http://localhost:8080 -auth ${JENKINS_USER}:${JENKINS_PASS} delete-job $jobname >>/dev/null
       //       fi
       //     done <<< "$diff"
       //   '''
       // }

       // running converge (chef_client_update_pipeline_jobs: chef-client -o "recipe[helios-pipeline::seed_jobs]" ) on node through pushy job
       dir('chef-server') {
         sh '''
           set +x
           BUNDLE_GEMFILE=Gemfile_for_knife_pipeline bundle exec knife job start chef_client_update_pipeline_jobs -s "chef_environment:clcmuse1 AND recipes:*helios-pipeline*"
           exitcode=$?

           if [ "$exitcode" -ne "0" ] ; then
             echo "Issue with running the job on node!"
             exit 1
           fi
         '''
       }
     }
    }
  }
} else {
  echo " ############### You Don’t Always Have To Say Yes ###############"
}
