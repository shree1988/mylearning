#!groovy
//
// Backing-up AEM Users
//
// This Groovy Script has been created using the documentation provided in this
// Confluence page: https://confluence.lbi.co.uk/display/PH/Backing+up+Users+and+Groups+on+UAT
//

properties([
  parameters([
    string (name: 'environment', defaultValue: 'use1nisuat', description: 'The environment whose users should be backed-up'),
   ])
])

node{

  // Wipe the workspace so we are building completely clean
  deleteDir()

  wrap([$class: 'BuildUser']) {
    build_user = env.BUILD_USER
  }

  //******** Configuration ********

  // ANSI color codes
  green='\u001B[32m'
  bold='\u001B[1m'
  reset='\u001B[0m'

  // AEM package 'Group', in order to find the content packages in /crx/packmgr
  package_group='backup_users'

  // Default port of AEM Authors
  server_port='4502'

  // All Authors will use that user to create/upload packages
  aem_username='admin'

  // If we can't find the AEM password for 'admin' in our Chef environment,
  // we're using this password
  default_aem_password='admin'

  // AWS S3 bucket in which the AEM package we created will be stored
  bucket='s3-helios-aem-users-back-ups'

  // name of the 'Jenkins Credentials' which allow read/write access to our S3
  // bucket.
  aws_credentials='aem-users-back-up-job'

  // Path to the AEM admin passwords in the Chef environments
  password_chef_path='override_attributes.aem.password'

  // Chef search string, in order to find the single AEM Author for a specific
  // environment
  author_search='AND ( role:*aem-author* OR role:aem-stack-tarmk* ) NOT role:aem-author-dispatcher*'

  stage('Processing parameters'){
    wrap([$class: 'AnsiColorBuildWrapper']){

      // To block access to production Chef environments
      currentBuild.description = environment
      if ( params.environment =~ /prod/ ) {
        error "This job is not ready for production yet"
      }

      // Calling Groovy methods to find the IP and password for the environment.
      author_ip = get_author_ip(params.environment)
      aem_password = get_aem_password(params.environment)

      // AEM package name & AEM package filters setup

      // Package name is generated as specified on the Confluence Documentation
      // For example: "Nissan UAT-2 Credentials 20170926"

      // Discard the first four characters of the environment, these correspond
      // to the AWS region, i.e. use1, euw1, apn1, etc.
      def env_name = params.environment.substring(4)

      // We check if this is a brand-specific environment

      def matches = (env_name =~ /(nis|ren)(.*)/)

      if(matches) {
        if(matches[0][1] == 'nis') {
          package_name = 'Nissan'
        }
        else {
          package_name = 'Renault'
        }

        package_name += " ${matches[0][2].toUpperCase()}"
      }
      else {
        // This one is probably a Stream environment.
        // For example: use1qa-stream2
        parts = env_name.tokenize('-')

        if(parts.size() >= 2){
          package_name = "${parts[1].capitalize()} "
        }
        else {
          package_name = ''
        }

        package_name += parts[0].toUpperCase()
      }

      current_date = new Date().format('yyyyMMdd')
      package_name += " Credentials ${current_date}"
      escaped_package_name = package_name.replace(" ", "%20")
      echo "Package name: ${package_name}"

      // Filters set-up according to the Confluence Documentation

      echo "before"

      filter = "{'root': '/home/users', 'rules': ["
        filter += "{'modifier': 'exclude', 'pattern': '/home/users/.*/.tokens'},"
        filter += "{'modifier': 'exclude', 'pattern': '/home/users/a/admin'},"
        filter += "{'modifier': 'exclude', 'pattern': '/home/users/r/replication-receiver'}"
      filter += "]},"
      filter += "{'root': '/home/groups', 'rules': []},"
      filter += "{'root': '/rep:policy', 'rules': []}"

      // AEM package description includes the name of the creator, the Jenkins
      // URL and the environment.

      description = "Users back-up for ${params.environment} ${build_user}\nBuilt by: \nVia: ${env.JENKINS_URL}job/${JOB_NAME}/${env.BUILD_ID}"
      echo "Package description: ${description}"
    }
  }

  // Creating the AEM package using a curl command, on the environment's Author.
  stage ('Creating AEM package'){
    create_output = sh (
      script: '#!/bin/sh +x\n' + "curl -u ${aem_username}:${aem_password} -X POST \"http://${author_ip}:${server_port}/crx/packmgr/service/.json/etc/packages/${package_group}/${escaped_package_name}?cmd=create\" -d \"packageName=${package_name}\" -d groupName=${package_group}",
      returnStdout: true
    ).trim()
    process_curl_output(create_output)
  }

  // Adding AEM package filters via curl.
  stage('Updating AEM package filters'){
    update_output = sh (
      script: '#!/bin/sh +x\n' + "curl -u ${aem_username}:${aem_password} -X POST http://${author_ip}:${server_port}/crx/packmgr/update.jsp \
  -F \"path=/etc/packages/${package_group}/${package_name}.zip\"\
  -F \"packageName=${package_name}\"\
  -F groupName=${package_group}\
  -F \"_charset_=UTF-8\" \
  -F description='$description' \
  -F filter=\"[${filter}]\" \
  -F acHandling=Overwrite",
      returnStdout: true
    ).trim()
    process_curl_output(update_output)
  }

  // Building the package via curl, this step is the slowest
  stage ('Building AEM package'){
    building_output = sh (
      script:  '#!/bin/sh +x\n' + "curl -u ${aem_username}:${aem_password} -X POST \"http://${author_ip}:${server_port}/crx/packmgr/service/.json/etc/packages/${package_group}/${escaped_package_name}.zip?cmd=build\"",
      returnStdout: true
    ).trim()
    process_curl_output(building_output)
  }

  // Pipe the package directly to S3 (no disk space required + very fast)
  stage ('Downloading AEM package + Uploading AEM package to S3'){
    withCredentials([[$class: 'AmazonWebServicesCredentialsBinding', credentialsId: aws_credentials, accessKeyVariable: 'AWS_ACCESS_KEY_ID', secretKeyVariable: 'AWS_SECRET_ACCESS_KEY']]) {
      s3_destination = "s3://${bucket}/${package_name}.zip"
      sh '#!/bin/sh +x\n' + "curl -u ${aem_username}:${aem_password} \"http://${author_ip}:${server_port}/etc/packages/${package_group}/${escaped_package_name}.zip\" | aws s3 cp - \"${s3_destination}\""
    }
  }
}

// Methods
@NonCPS
def process_curl_output(json_object){
  curl_output_slurped = readJSON text: json_object
  if ( curl_output_slurped.success ) {
    wrap([$class: 'AnsiColorBuildWrapper']) {
      echo "${bold}AEM curl command successful : ${green}${curl_output_slurped.msg}${reset}"
    }
  } else {
    error "AEM curl command failed : ${curl_output_slurped.msg}"
  }
}

def get_author_ip(environment){
  author_ip = sh (
    script: '#!/bin/sh +x\n' + "knife search 'chef_environment:${environment} ${author_search}' -F json -a ipaddress|grep ipaddress|sed 's/.*ipaddress\": \"//'|sed 's/\"//'",
    returnStdout: true
  ).trim()
  if ( author_ip == '' ){
    error "AEM Author IP for ${environment} can't be found"
  } else if ( ! author_ip.matches("\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}") ) {
    error "AEM Author IP for ${environment} is incorrect : ${author_ip}"
  } else {
    echo "${bold}AEM Author IP for ${environment} : ${green}$author_ip ${reset}"
    author_ip
  }
}

def get_aem_password(environment){
  data_bag = sh (
    script: '#!/bin/sh +x\n' + "knife data bag show ${environment} aem_credentials -F json",
    returnStdout: true
  ).trim()

  json_object = readJSON text: data_bag
  aem_password = json_object.admin.password

  if ( aem_password == 'null' ) {
    echo "No AEM Author password found for ${environment}, setting it to $default_aem_password"
    aem_password = default_aem_password
  }

  wrap([$class: 'AnsiColorBuildWrapper']) {
    echo "${bold}AEM Author password for ${environment} : ${green}$aem_password $reset"
  }
  aem_password
}
