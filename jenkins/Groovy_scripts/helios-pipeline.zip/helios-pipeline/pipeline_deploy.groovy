#!groovy

env.Version_ID = params.Version_ID
env.Build_ID = params.Build_ID
env.Chef_ENV = params.Chef_ENV
env.App_Name = params.App_Name

if ( env.Chef_ENV =~ /Prod/ ) {
  error 'you are not allowed to use this environment'
}

if ( params.Version_ID != null || params.Build_ID != null || params.Chef_ENV != null || params.App_Name != null ) {

  properties([
    parameters([
      string(name: 'Version_ID', defaultValue: env.Version_ID, description: 'Please specify package version ID e.g: 17.1.0-SNAPSHOT'),
      string(name: 'Build_ID', defaultValue: env.Build_ID, description: 'Please specify package build ID e.g: 1'),
      choice(name: 'Chef_ENV', choices: env.Chef_ENV, description: 'Which environment should be deploy. It should be our chef environment e.g: use1nisuat'),
      choice(name: 'App_Name', choices: env.App_Name, description: 'Please select the app which need to be deploy')
    ])
  ])

  node {
    currentBuild.description = "${Version_ID}-${BUILD_ID} ⇨ ${Chef_ENV}"

    // Wipe the workspace so we are building completely clean
    deleteDir()

    // ANSI color codes
    green='\u001B[32m'
    red='\u001B[31m'
    bold='\u001B[1m'
    reset='\u001B[0m'

    // Check if build exist in Nexus
    stage('Check Build on Nexus') {

      if ( env.Chef_ENV =~ /load$/ ) {
        env.Env_Repo = 'Ongoing_Performance'
      } else if ( env.Chef_ENV =~ /use1nisuat-stream23nna/ ) {
        env.Env_Repo = 'stream23-uat'
      } else if ( env.Chef_ENV =~ /use1nisuat-upgrade/ ) {
        env.Env_Repo = 'uat-upgrade'
      }
      else {
        env.Env_Repo = 'public'
      }

      wrap([$class: 'AnsiColorBuildWrapper']) {
        println "${bold}Check Build on Nexus: ${green}Checking the Nexus for build ${Version_ID}-${BUILD_ID} ${reset}"
        sh '''
          set +x
          if [[ "${App_Name}" == "Author" || ${App_Name} == "Publisher" ]] && ! [[ `wget -S --spider --http-user=configurationmanagement --http-password=TNaF204XeQu08g8 "https://nexus-cm.helios-aws.com/service/local/artifact/maven/redirect?r=${Env_Repo}&g=com.digitaslbi.helios&a=helios-id-aem&v=build-${BUILD_ID}-${Version_ID}&p=zip" 2>&1 | grep 'HTTP/1.1 200 OK'` ]]; then
            echo "\u001B[31m --- The ${Version_ID} #${BUILD_ID} doesn't exist in Nexus --- \u001B[0m"
            exit 1
          elif [[ "${App_Name}" == "Author" || ${App_Name} == "Publisher" ]] && ! [[ `wget -S --spider --http-user=configurationmanagement --http-password=TNaF204XeQu08g8 "https://nexus-cm.helios-aws.com/service/local/artifact/maven/redirect?r=${Env_Repo}&g=com.digitaslbi.helios&a=helios-website&v=build-${BUILD_ID}-${Version_ID}&p=zip" 2>&1 | grep 'HTTP/1.1 200 OK'` ]]; then
            echo "\u001B[31m --- The ${Version_ID} #${BUILD_ID} doesn't exist in Nexus --- \u001B[0m"
            exit 1
          elif [[ "${App_Name}" == "Mule" ]] && ! [[ `wget -S --spider --http-user=configurationmanagement --http-password=TNaF204XeQu08g8 "https://nexus-cm.helios-aws.com/service/local/artifact/maven/redirect?r=${Env_Repo}&g=com.digitaslbi.helios&a=helios-mule-accessories&v=build-${BUILD_ID}-${Version_ID}&p=zip" 2>&1 | grep 'HTTP/1.1 200 OK'` ]]; then
            echo "\u001B[31m --- The ${Version_ID} #${BUILD_ID} doesn't exist in Nexus --- \u001B[0m"
            exit 1
          elif [[ "${App_Name}" == "Mule" ]] && ! [[ `wget -S --spider --http-user=configurationmanagement --http-password=TNaF204XeQu08g8 "https://nexus-cm.helios-aws.com/service/local/artifact/maven/redirect?r=${Env_Repo}&g=com.digitaslbi.helios&a=helios-mule-specs&v=build-${BUILD_ID}-${Version_ID}&p=zip" 2>&1 | grep 'HTTP/1.1 200 OK'` ]]; then
            echo "\u001B[31m --- The ${Version_ID} #${BUILD_ID} doesn't exist in Nexus --- \u001B[0m"
            exit 1
          elif [[ "${App_Name}" == "Helios-API" ]] && ! [[ `wget -S --spider --http-user=configurationmanagement --http-password=TNaF204XeQu08g8 "https://nexus-cm.helios-aws.com/service/local/artifact/maven/redirect?r=${Env_Repo}&g=com.digitaslbi.helios&a=helios-api-authorisation&v=build-${BUILD_ID}-${Version_ID}&p=war" 2>&1 | grep 'HTTP/1.1 200 OK'` ]]; then
            echo "\u001B[31m --- The ${Version_ID} #${BUILD_ID} doesn't exist in Nexus --- \u001B[0m"
            exit 1
          elif [[ "${App_Name}" == "Helios-API" ]] && ! [[ `wget -S --spider --http-user=configurationmanagement --http-password=TNaF204XeQu08g8 "https://nexus-cm.helios-aws.com/service/local/artifact/maven/redirect?r=${Env_Repo}&g=com.digitaslbi.helios&a=helios-api-bundle&v=build-${BUILD_ID}-${Version_ID}&p=war" 2>&1 | grep 'HTTP/1.1 200 OK'` ]]; then
            echo "\u001B[31m --- The ${Version_ID} #${BUILD_ID} doesn't exist in Nexus --- \u001B[0m"
            exit 1
          fi
        '''
      }
    }

    // AEM-Stack|Author|Helios-API|Mule|Publisher
    if ( env.App_Name == 'Author' ) {
      env.Data_Bag = 'author'
      env.Chef_Node_Search = 'chef_environment:' + env.Chef_ENV + ' AND role:*aem-author* NOT role:aem-author-dispatcher*'
    } else if ( env.App_Name == 'Helios-API' ) {
      env.Data_Bag = 'helios-api'
      env.Chef_Node_Search = 'chef_environment:' + env.Chef_ENV + ' AND name:*services*'
    } else if ( env.App_Name == 'Mule' ) {
      env.Data_Bag = 'mule-esb'
      env.Chef_Node_Search = 'chef_environment:' + env.Chef_ENV + ' AND recipes:*esb*'
    } else if ( env.App_Name == 'Publisher' ) {
      env.Data_Bag = 'publish'
      env.Chef_Node_Search = 'chef_environment:' + env.Chef_ENV + ' AND role:*aem-publish*'
    }

    stage('Checkout') {
      wrap([$class: 'AnsiColorBuildWrapper']) {
        println "${bold}Checkout: ${green}Checkout the configuration repository ${reset}"
        // Checkout configuration repository
        checkout changelog: false, poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']],
        doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'WipeWorkspace']], submoduleCfg: [],
        userRemoteConfigs: [[credentialsId: '	97c54a1a-01f7-44f1-88b8-b88740cd3d1a', url: 'https://gitlab.helios-aws.com/helios/ops/configuration.git']]]
      }
    }

    stage('Install Bundles and Update Databag') {
      withEnv(["PATH=/var/lib/jenkins/.rbenv/shims:/var/lib/jenkins/.rbenv/bin:/var/lib/jenkins/.rbenv/plugins/ruby_build/bin:/usr/local/bin:/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/sbin"]) {
        wrap([$class: 'AnsiColorBuildWrapper']) {
          println "${bold}Install Bundles and Update Databag: ${green}Installing Chef bundles ${reset}"
          sh '''
            set +x
            cd chef-server
            BUNDLE_GEMFILE=Gemfile_for_knife_pipeline bundle install --path /var/lib/jenkins/pipelines-bundle-path
            rbenv rehash
          '''

          // Push databag changes to chef server
          println "${bold}Install Bundles and Update Databag: ${green}Updating the Chef server ${Chef_ENV} Databag with build ${Version_ID}-${BUILD_ID} ${reset}"
          sh '''
            set +x
            cd chef-server
            BUNDLE_GEMFILE=Gemfile_for_knife_pipeline bundle exec knife exec ../helios-pipeline/set_packages_data_bag.rb ${Data_Bag} ${Chef_ENV} ${Version_ID} ${BUILD_ID} || exit 1
          '''

          // Commit and Push "version_id and build_id" change to databag in git configuration repo
          println "${bold}Install Bundles and Update Databag: ${green}Downloading the ${Chef_ENV} Databags changes from Chef server ${reset}"
          sh '''
            set +x
            cd chef
            BUNDLE_GEMFILE=../chef-server/Gemfile_for_knife_pipeline bundle exec knife download data_bags/${Chef_ENV}/${Data_Bag}.json --chef-repo-path .
          '''

          println "${bold}Install Bundles and Update Databag: ${green}Commit and Push Databags changes to configuration repository ${reset}"
          withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: '97c54a1a-01f7-44f1-88b8-b88740cd3d1a',
          usernameVariable: 'GIT_USERNAME', passwordVariable: 'GIT_PASSWORD']]) {
            sh '''
              set +x
              git checkout master
              cd chef
              echo 'Git status is :'
              git status --porcelain
              if [[ `git status --porcelain` ]]; then
                echo 'Pushing data bags changes to master'
                git remote add central https://${GIT_USERNAME}:${GIT_PASSWORD}@gitlab.helios-aws.com/helios/ops/configuration.git
                git config --global user.name "Helios Pipeline"
                git config --global user.email dev.ops@heliosalliance.net
                git add data_bags/${Chef_ENV}/${Data_Bag}.json
                git commit -m "Version bump to ${Version_ID} build ${BUILD_ID} on ${Chef_ENV} ${App_Name}"
                git pull
                git push origin master
              fi
            '''
          }
        }
      }
    }

    stage('Deploying Code') {
      withEnv(["PATH=/var/lib/jenkins/.rbenv/shims:/var/lib/jenkins/.rbenv/bin:/var/lib/jenkins/.rbenv/plugins/ruby_build/bin:/usr/local/bin:/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/sbin"]) {
        dir('chef-server') {
          wrap([$class: 'AnsiColorBuildWrapper']) {

            // running converge (chef-client) on node through pushy job
            println "${bold}Deploying Code: ${green}Deploying build ${Version_ID}-${BUILD_ID} on ${App_Name} ${reset}"
            sh '#!/bin/sh +x\n' + 'BUNDLE_GEMFILE=Gemfile_for_knife_pipeline bundle exec knife job start chef-client -s "${Chef_Node_Search}"'


            // Deleting dispatcher cache on Publishers
            if ( env.App_Name == 'Publisher' ) {
              println "${bold}Deploying Code: ${green}Clearing cache on the Publisher${reset}"
              sh '#!/bin/sh +x\n' + 'BUNDLE_GEMFILE=Gemfile_for_knife_pipeline bundle exec knife job start dispatcher_cache_clearing -s "${Chef_Node_Search}"'
            }

            // restarting mule on node through pushy job
            if ( env.App_Name == 'Mule' ) {
              println "${bold}Deploying Code: ${green}Restarting Mule service${reset}"
              sh '#!/bin/sh +x\n' + 'BUNDLE_GEMFILE=Gemfile_for_knife_pipeline bundle exec knife job start stop-mule -s "${Chef_Node_Search}"'
              sh '#!/bin/sh +x\n' + 'BUNDLE_GEMFILE=Gemfile_for_knife_pipeline bundle exec knife job start start-mule -s "${Chef_Node_Search}"'
            }
          }
        }
      }
    }

    stage('Smoke Test') {
      withEnv(["PATH=/var/lib/jenkins/.rbenv/shims:/var/lib/jenkins/.rbenv/bin:/var/lib/jenkins/.rbenv/plugins/ruby_build/bin:/usr/local/bin:/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/sbin"]) {
        withCredentials([file(credentialsId: '	d1098693-4514-4e42-b52f-cb97075d3a10', variable: 'SECRET_FILE'),
        string(credentialsId: '	d2931848-5fbb-4a2a-adee-232ebc4524f5', variable: 'SECRET_USER')]) {
          if ( env.App_Name == 'Author' ) {
            wrap([$class: 'AnsiColorBuildWrapper']) {
              sh '''
                set +x
                pass=$(knife data bag show -F json ${Chef_ENV} aem_credentials 2>/dev/null | jq .admin.password | tr -d '"')
                nodename=$(knife ssh -a ipaddress -i ${SECRET_FILE} -x ${SECRET_USER} "${Chef_Node_Search}" "hostname")

                echo "\u001B[1m\nSmoke Test:\u001B[32m NodeName: $nodename\u001B[0m"
                echo "\u001B[1m\nSmoke Test:\u001B[32m Checking bundles for version ${Version_ID}-${BUILD_ID} on Author\u001B[0m"

                bundles=( "abres" "admin" "api-model" "tooling" "web" "webrender" )
                for bundle in "${bundles[@]}"; do
                  output=$(knife ssh -a ipaddress -i ${SECRET_FILE} -x ${SECRET_USER} "${Chef_Node_Search}" "curl -s -u admin:$pass http://localhost:4502/system/console/bundles/com.digitaslbi.helios.$bundle" | sed -n 's/.*\\(\\"Bnd-LastModified.*\\"\\),\\"Created-By.*/\\1/p')

                  if ! [[ $output =~ "BuildId: ${BUILD_ID}" && $output =~ "Bundle-Version: ${Version_ID}" ]]; then
                    echo "\u001B[31m --- The Snapshot doesn't match with Version and Build ID --- \u001B[0m"
                    ### exit 1
                  else
                    echo "\u001B[32m --- The com.digitaslbi.helios.$bundle ${Version_ID} - ${BUILD_ID} bundle has deployed --- \u001B[0m"
                  fi
                done
              '''
            }
          }

          if ( env.App_Name == 'Publisher' ) {
            wrap([$class: 'AnsiColorBuildWrapper']) {
              sh '''
                set +x
                pass=$(knife data bag show -F json ${Chef_ENV} aem_credentials 2>/dev/null | jq .admin.password | tr -d '"')
                nodenames=$(knife ssh -a ipaddress -i ${SECRET_FILE} -x ${SECRET_USER} "${Chef_Node_Search}" "hostname")

                echo "\u001B[1m\nSmoke Test:\u001B[32m Checking bundles for version ${Version_ID}-${BUILD_ID} on Publishers\u001B[0m"

                while read nodename; do
                  echo "\u001B[1m\nSmoke Test:\u001B[32m NodeName: $nodename\u001B[0m"

                  bundles=( "abres" "admin" "api-model" "tooling" "web" "webrender" )
                  for bundle in "${bundles[@]}"; do
                    output=$(knife ssh -a ipaddress -i ${SECRET_FILE} -x ${SECRET_USER} "${Chef_Node_Search}" "curl -s -u admin:$pass http://localhost:4503/system/console/bundles/com.digitaslbi.helios.$bundle | sed -n 's/.*\\(\\"Bnd-LastModified.*\\"\\),\\"Created-By.*/\\1/p'")

                    if ! [[ $output =~ "BuildId: ${BUILD_ID}" && $output =~ "Bundle-Version: ${Version_ID}" ]]; then
                      echo "\u001B[31m --- The Snapshot doesn't match with Version and Build ID --- \u001B[0m"
                      #### exit 1
                    else
                      echo "\u001B[32m --- The com.digitaslbi.helios.$bundle ${Version_ID} - ${BUILD_ID} bundle has deployed --- \u001B[0m"
                    fi
                  done
                done <<< "$nodenames"
              '''
            }
          }

          if ( env.App_Name == 'Helios-API' ) {
            wrap([$class: 'AnsiColorBuildWrapper']) {
              sh '''
                set +x
                nodenames=$(knife ssh -a ipaddress -i ${SECRET_FILE} -x ${SECRET_USER} "${Chef_Node_Search}" "hostname")

                echo "\u001B[1m\nSmoke Test:\u001B[32m Checking Apps for version ${Version_ID}-${BUILD_ID} on API Tomcat\u001B[0m"

                while read nodename; do
                  echo "\u001B[1m\nSmoke Test:\u001B[32m NodeName: $nodename\u001B[0m" | tr -d '\r'

                  nodename=$(echo $nodename | tr -d '\r' | awk '{print $2}')
                  data_bag_items=$(knife exec helios-pipeline/get_databag_items.rb ${Chef_ENV} ${Data_Bag} "name")
                  while read itemname; do
                    if ! [[ $itemname == "helios-api-offers-dma" ]]; then
                      healthcheck=$(knife ssh -a ipaddress -i ${SECRET_FILE} -x ${SECRET_USER} "name:$nodename" "curl -s http://localhost:8080/$itemname/healthcheck && echo")
                      if ! [[ $healthcheck =~ ${Version_ID}.build-${BUILD_ID} ]]; then
                        echo "\u001B[31m --- $itemname: The Build doesn't match with Version and Build ID --- \u001B[0m"
                        #### exit 1
                      else
                        echo "\u001B[32m --- $itemname: The package ${Version_ID} - ${BUILD_ID} has deployed --- \u001B[0m"
                      fi
                    fi
                  done <<< "$data_bag_items"
                done <<< "$nodenames"
              '''
            }
          }

          if ( env.App_Name == 'Mule' ) {
            wrap([$class: 'AnsiColorBuildWrapper']) {
              sh '''
                set +x
                nodename=$(knife ssh -a ipaddress -i ${SECRET_FILE} -x ${SECRET_USER} "${Chef_Node_Search}" "hostname")
                data_bag_items=$(knife exec helios-pipeline/get_databag_items.rb ${Chef_ENV} ${Data_Bag} "name")

                echo "\u001B[1m\nSmoke Test:\u001B[32m Checking Apps for version ${Version_ID}-${BUILD_ID} on Mule \u001B[0m"

                echo "\u001B[1m\nSmoke Test:\u001B[32m Node Name: $nodename\u001B[0m"
                while read itemname; do
                  output=$(knife ssh -a ipaddress -i ${SECRET_FILE} -x ${SECRET_USER} "${Chef_Node_Search}" "grep -r '${Version_ID}.build-${BUILD_ID}' /opt/mule/apps/$itemname" | cut -d = -f2)
                  if ! [[ $output =~ ^${Version_ID}.build-${BUILD_ID} ]]; then
                    echo "\u001B[31m --- $itemname: The Build doesn't match with Version and Build ID --- \u001B[0m"
                    #### exit 1
                  else
                    echo "\u001B[32m --- $itemname: The package ${Version_ID} - ${BUILD_ID} has deployed --- \u001B[0m"
                  fi
                done <<< "$data_bag_items"
              '''
            }
          }
        }
      }
    }

    // for test
    step([$class: 'WsCleanup'])
    deleteDir()
  }
} else {
  // This project is parameterized
  stage('Create and Configure Pipeline') {
    def userInput = input(
      id: 'userInput', message: 'Please configure this job first!!', parameters: [
        [$class: 'TextParameterDefinition', name: 'VersionID', defaultValue: '', description: 'Please specify package version ID e.g: 17.1.0-SNAPSHOT'],
        [$class: 'TextParameterDefinition', name: 'BuildID', defaultValue: '', description: 'Please specify package build ID e.g: 1'],
        [$class: 'TextParameterDefinition', name: 'ChefEnv', defaultValue: '', description: 'Environment, It should be our chef environment e.g: use1nisuat'],
        [$class: 'ChoiceParameterDefinition', name: 'AppName', choices: "AEM-Stack\nAuthor\nHelios-API\nMule\nPublisher\n", description: 'Please select the app which need to be deploy']
    ])

    properties([
      parameters([
        string(name: 'Version_ID', defaultValue: (userInput['VersionID']), description: 'Please specify package version ID e.g: 17.1.0-SNAPSHOT'),
        string(name: 'Build_ID', defaultValue: (userInput['BuildID']), description: 'Please specify package build ID e.g: 1'),
        choice(name: 'Chef_ENV', choices: (userInput['ChefEnv']), description: 'Which environment should be deploy. It should be our chef environment e.g: use1nisuat'),
        choice(name: 'App_Name', choices: (userInput['AppName']), description: 'Please select the app which need to be deploy')
      ])
    ])

    echo "Pipeline has created, please configure build parameters"
  }
}
