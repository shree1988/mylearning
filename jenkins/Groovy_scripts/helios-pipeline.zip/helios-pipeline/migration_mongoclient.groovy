#!groovy

env.Source = params.Source
env.Destination = params.Destination

node {
  currentBuild.description = "Migration: ${Source} -> ${Destination}"
  deleteDir()

  // ANSI color codes
  green='\u001B[32m'
  red='\u001B[31m'
  bold='\u001B[1m'
  reset='\u001B[0m'


  prod_users = [
    //  'omiladi','abhatt'
  ]

  wrap([$class: 'BuildUser']) {
    build_userid = env.BUILD_USER_ID
    build_username = env.BUILD_USER
  }

  if ( env.Source =~ /prod/ ) {
    if ( ! ( build_userid in prod_users ) ) {
      echo "${bold}${red}User ${build_userid} not allowed to pull content from production${reset}"
      error('')
    } else {
      echo "User ${build_userid} allowed to pull content from production"
    }
  }

  if ( env.Destination =~ /prod/ ) {
    echo "${bold}${red}Not uploading content to production for now${reset}"
    error('')
  }

  if (env.Source =~ /bae/ || env.Source =~ /hf/) {
    env.Chef_Source_search = 'chef_environment:' + env.Source
  } else {
      env.Chef_Source_search =  'chef_environment:' + env.Source + ' AND role:mongodb3_api_replicanode'
  }

  if (env.Destination =~ /bae/ || env.Destination =~ /hf/) {
    env.Chef_Destination_search = 'chef_environment:' + env.Destination
  } else {
      env.Chef_Destination_search =  'chef_environment:' + env.Destination + ' AND role:mongodb3_api_replicanode'
  }


  stage('Checkout') {
    checkout changelog: false, poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']],
    doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'WipeWorkspace']], submoduleCfg: [],
    userRemoteConfigs: [[credentialsId: '97c54a1a-01f7-44f1-88b8-b88740cd3d1a', url: 'https://gitlab.helios-aws.com/helios/ops/configuration.git']]]
  }

  stage('Install Bundles') {
    withEnv(["PATH=/var/lib/jenkins/.rbenv/shims:/var/lib/jenkins/.rbenv/bin:/var/lib/jenkins/.rbenv/plugins/ruby_build/bin:/usr/local/bin:/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/sbin"]) {
      sh '''
        set +x
        cd chef-server
        BUNDLE_GEMFILE=Gemfile_for_knife_pipeline bundle install --path /var/lib/jenkins/pipelines-bundle-path
        rbenv rehash
      '''
    }
  }


   stage('Dump helios DB'){
     env.Source_ip = get_primary_ip(env.Chef_Source_search)
     println "Source IP : ${Source_ip}"
     withEnv(["PATH=/var/lib/jenkins/.rbenv/shims:/var/lib/jenkins/.rbenv/bin:/var/lib/jenkins/.rbenv/plugins/ruby_build/bin:/usr/local/bin:/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/sbin"]) {
       withCredentials([file(credentialsId: '	d1098693-4514-4e42-b52f-cb97075d3a10', variable: 'SECRET_FILE'),
       string(credentialsId: '	d2931848-5fbb-4a2a-adee-232ebc4524f5', variable: 'SECRET_USER')]) {
         wrap([$class: 'AnsiColorBuildWrapper']) {
           sh '''
              set +x
              ###Dump
              ssh -i ${SECRET_FILE} ${SECRET_USER}@${Source_ip} 'mkdir /tmp/mongodump-$(date +%Y%m%d) && mongodump --db helios --out /tmp/mongodump-$(date +%Y%m%d) && tar -czf /tmp/mongodump-$(date +%Y%m%d).tar.gz /tmp/mongodump-$(date +%Y%m%d) && rm -rf /tmp/mongodump-$(date +%Y%m%d)'
              scp -i ${SECRET_FILE} ${SECRET_USER}@${Source_ip}:/tmp/mongodump-$(date +%Y%m%d).tar.gz ./mongodump.tar.gz
           '''
         }
       }
     }
   }

   stage('Restore helios DB'){
     env.Dest_ip = get_primary_ip(env.Chef_Destination_search)
     println "Source IP : ${Source_ip}"
     withEnv(["PATH=/var/lib/jenkins/.rbenv/shims:/var/lib/jenkins/.rbenv/bin:/var/lib/jenkins/.rbenv/plugins/ruby_build/bin:/usr/local/bin:/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/sbin"]) {
       withCredentials([file(credentialsId: '	d1098693-4514-4e42-b52f-cb97075d3a10', variable: 'SECRET_FILE'),
       string(credentialsId: '	d2931848-5fbb-4a2a-adee-232ebc4524f5', variable: 'SECRET_USER')]) {
         wrap([$class: 'AnsiColorBuildWrapper']) {
           sh '''
              set +x
              ###Restor
              scp -i ${SECRET_FILE}  ./mongodump.tar.gz ${SECRET_USER}@${Dest_ip}:/tmp/mongodump-$(date +%Y%m%d).tar.gz
              ssh -i ${SECRET_FILE} ${SECRET_USER}@${Dest_ip} 'cd / && tar -xvf /tmp/mongodump-$(date +%Y%m%d).tar.gz && cd /tmp/mongodump-$(date +%Y%m%d) && mongorestore -d helios helios'
           '''
         }
       }
     }
   }



  step([$class: 'WsCleanup'])
  deleteDir()
}

// Methods
def get_primary_ip(chef_query){
  withEnv(["PATH=/var/lib/jenkins/.rbenv/shims:/var/lib/jenkins/.rbenv/bin:/var/lib/jenkins/.rbenv/plugins/ruby_build/bin:/usr/local/bin:/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/sbin"]) {
    withCredentials([file(credentialsId: '	d1098693-4514-4e42-b52f-cb97075d3a10', variable: 'SECRET_FILE'),
    string(credentialsId: '	d2931848-5fbb-4a2a-adee-232ebc4524f5', variable: 'SECRET_USER')]) {
      wrap([$class: 'AnsiColorBuildWrapper']) {
        env.Chef_Query=chef_query
        primary_ip = sh (
            script: '''
            set +x
            nodenames=$(knife ssh -a ipaddress -i ${SECRET_FILE} -x ${SECRET_USER} "${Chef_Query}" "hostname")
            if (( $(grep -c . <<<"$nodenames") > 1 )); then
              randomnode=$(echo $nodenames | tail -1 | tr -d '\r' |cut -d " " -f2)
              primarynode=$(knife ssh -i ${SECRET_FILE} -x ${SECRET_USER} -a ipaddress "name:$randomnode" "mongo --eval 'rs.status().members.find(r=>r.state===1).name' " | tail -1 | cut -d: -f 1 | cut -d: -f 1)
              primaryname=$(echo $primarynode | cut -d ' ' -f 2)
              primary_ip=$(knife ssh -i ${SECRET_FILE} -x ${SECRET_USER} -a ipaddress "name:$randomnode" "getent hosts $primaryname" | cut -d " " -f 2)
            else
              primary_ip=$(echo $nodenames | cut -d " " -f 1)
            fi
            echo $primary_ip
            ''',
            returnStdout: true
          ).trim()
        primary_ip
      }
    }
  }
}
