#!groovy

env.Chef_ENV = params.Chef_ENV

if ( env.Chef_ENV =~ /Prod/ ) {
  error 'you are not allowed to use this environment'
}

if ( params.Chef_ENV != null ) {

  properties([
    parameters([
      choice(name: 'Chef_ENV', choices: env.Chef_ENV, description: 'Which environment should be deploy. It should be our chef environment e.g: use1nisuat'),
    ])
  ])

  node {

    stage('Checkout') {
      // Checkout configuration repository
      checkout changelog: false, poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']],
      doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'WipeWorkspace']], submoduleCfg: [],
      userRemoteConfigs: [[credentialsId: '', url: '']]]
    }

    stage('Install Bundles') {
      withEnv(["PATH=/var/lib/jenkins/.rbenv/shims:/var/lib/jenkins/.rbenv/bin:/var/lib/jenkins/.rbenv/plugins/ruby_build/bin:/usr/local/bin:/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/sbin"]) {
        sh '''
          set +x
          cd chef-server
          BUNDLE_GEMFILE=Gemfile_for_knife_pipeline bundle install --path /var/lib/jenkins/pipelines-bundle-path
          rbenv rehash
        '''
      }
    }

    env.Chef_Node_Search = 'chef_environment:' + env.Chef_ENV + ' AND role:*aem-publish*'

    stage('Deploy Dispatcher') {
      withEnv(["PATH=/var/lib/jenkins/.rbenv/shims:/var/lib/jenkins/.rbenv/bin:/var/lib/jenkins/.rbenv/plugins/ruby_build/bin:/usr/local/bin:/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/sbin"]) {
        dir('chef-server') {
          // running converge (chef_client_aem_dispatcher) on node through pushy job
          sh '''
            set +x
            BUNDLE_GEMFILE=Gemfile_for_knife_pipeline bundle exec knife job start chef_client_aem_dispatcher -s "${Chef_Node_Search}"
            exitcode=$?

            if [ "$exitcode" -ne "0" ] ; then
              echo "Issue with converging dispatcher on nodes!"
              exit 1
            fi
          '''
        }
      }
    }

    stage('Restart Apache') {
      withEnv(["PATH=/var/lib/jenkins/.rbenv/shims:/var/lib/jenkins/.rbenv/bin:/var/lib/jenkins/.rbenv/plugins/ruby_build/bin:/usr/local/bin:/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/sbin"]) {
        dir('chef-server') {
          // running converge (httpd_graceful) on node through pushy job
          sh '''
            set +x
            BUNDLE_GEMFILE=Gemfile_for_knife_pipeline bundle exec knife job start httpd_graceful -s "${Chef_Node_Search}"
            exitcode=$?

            if [ "$exitcode" -ne "0" ] ; then
              echo "Issue with gracefully restart Apache!"
              exit 1
            fi
          '''
        }
      }
    }

    step([$class: 'WsCleanup'])
    deleteDir()
  }
} else {
  // This project is parameterized
  stage('Create and Configure Pipeline') {
    def userInput = input(
      id: 'userInput', message: 'Please configure this job first!!', parameters: [
        [$class: 'TextParameterDefinition', name: 'ChefEnv', defaultValue: '', description: 'Environment, It should be our chef environment e.g: use1nisuat']
    ])

    properties([
      parameters([
        choice(name: 'Chef_ENV', choices: (userInput['ChefEnv']), description: 'Which environment should be deploy. It should be our chef environment e.g: use1nisuat')
      ])
    ])

    echo "Pipeline has created, please configure build parameters"
  }
}
