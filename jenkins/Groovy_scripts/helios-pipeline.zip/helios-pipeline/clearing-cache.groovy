#!groovy

env.Chef_ENV = params.Chef_ENV



if ( params.Chef_ENV != null ) {

  properties([
    parameters([
      choice(name: 'Chef_ENV', choices: env.Chef_ENV, description: 'Which environment should be deploy. It should be our chef environment e.g: use1nisuat'),
    ])
  ])

  node {

    def prod_users = [
        'omiladi','abhatt'
    ]

    wrap([$class: 'BuildUser']) {
      def user_id = env.BUILD_USER_ID
      build_user = env.BUILD_USER
      build_user_email = env.BUILD_USER_EMAIL
      if ( !(user_id in prod_users) && env.Chef_ENV =~ /prod/){
        wrap([$class: 'AnsiColorBuildWrapper']) {
          println "${red}You are not authorized to run this job!${reset}"
          error()
        }
      }
    }

    stage('Checkout') {
      // Checkout configuration repository
      checkout changelog: false, poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']],
      doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'WipeWorkspace']], submoduleCfg: [],
      userRemoteConfigs: [[credentialsId: '97c54a1a-01f7-44f1-88b8-b88740cd3d1a', url: 'https://gitlab.helios-aws.com/helios/ops/configuration.git']]]
    }

    stage('Install Bundles and Update Databag') {
      withEnv(["PATH=/var/lib/jenkins/.rbenv/shims:/var/lib/jenkins/.rbenv/bin:/var/lib/jenkins/.rbenv/plugins/ruby_build/bin:/usr/local/bin:/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/sbin"]) {
        sh '''
          set +x
          cd chef-server
          BUNDLE_GEMFILE=Gemfile_for_knife_pipeline bundle install --path /var/lib/jenkins/pipelines-bundle-path
          rbenv rehash
        '''
      }
    }

    env.Chef_Node_Search = 'chef_environment:' + env.Chef_ENV + ' AND role:*aem-publish*'

    stage('Clearing Cache') {
      withEnv(["PATH=/var/lib/jenkins/.rbenv/shims:/var/lib/jenkins/.rbenv/bin:/var/lib/jenkins/.rbenv/plugins/ruby_build/bin:/usr/local/bin:/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/sbin"]) {
        dir('chef-server') {
          // running converge (dispatcher_cache_clearing) on node through pushy job
          sh '''
            set +x
            BUNDLE_GEMFILE=Gemfile_for_knife_pipeline bundle exec knife job start dispatcher_cache_clearing -s "${Chef_Node_Search}"
            exitcode=$?

            if [ "$exitcode" -ne "0" ] ; then
              echo "Issue with clearing cache on nodes!"
              exit 1
            fi
          '''
        }
      }
    }

    step([$class: 'WsCleanup'])
    deleteDir()
  }
} else {
  // This project is parameterized
  stage('Create and Configure Pipeline') {
    def userInput = input(
      id: 'userInput', message: 'Please configure this job first!!', parameters: [
        [$class: 'TextParameterDefinition', name: 'ChefEnv', defaultValue: '', description: 'Environment, It should be our chef environment e.g: use1nisuat']
    ])

    properties([
      parameters([
        choice(name: 'Chef_ENV', choices: (userInput['ChefEnv']), description: 'Which environment should be deploy. It should be our chef environment e.g: use1nisuat')
      ])
    ])

    echo "Pipeline has created, please configure build parameters"
  }
}
